<?php

  // SECTION ORDERING

  $wp_customize->add_panel( $ParentPanel );

  $Parent_Ordering_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_ordering_section', array(
    'title' => __( 'Section Ordering Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_Ordering_Section );

  $wp_customize->add_section('cyber_security_services_pro_section_ordering_settings',array(
    'title' => __('Section Ordering Settings','cyber-security-services-pro'),
    'description'=> __('Section Ordering.','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_ordering_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_section_ordering_settings_repeater', array(
    'default' => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Repeater_Custom_Control( $wp_customize, 'cyber_security_services_pro_section_ordering_settings_repeater',
    array(
    'label' => __( 'Section Reordering','cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_section_ordering_settings',
    'button_labels' => array(
      'add' => __( 'Add Row','cyber-security-services-pro' ), 
  ))));

  // SECTION SPACING

  $wp_customize->add_panel( $Parent_Ordering_Section );

  $wp_customize->add_section('cyber_security_services_pro_section_spacing_settings',array(
    'title' => __('Section Spacing Settings','cyber-security-services-pro'),
    'description'=> __('Section Spacing Settings.','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_ordering_section',
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_slider_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_slider_top',array(
    'label' => __('Slider Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_about_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_about_top',array(
    'label' => __('About Us Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_our_services_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_our_services_top',array(
    'label' => __('Our Services Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_choose_us_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_choose_us_top',array(
    'label' => __('Choose Us Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_pricing_plan_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_pricing_plan_top',array(
    'label' => __('Pricing Plan Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_our_video_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_our_video_top',array(
    'label' => __('Our Video Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_latest_news_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_latest_news_top',array(
    'label' => __('Latest News Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_achievement_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_achievement_top',array(
    'label' => __('Achievement Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_spacing_sponsors_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_sponsors_top',array(
    'label' => __('Companies Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));

$wp_customize->add_setting('cyber_security_services_pro_spacing_our_experts_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_our_experts_top',array(
    'label' => __('Our Experts Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));
  
  $wp_customize->add_setting('cyber_security_services_pro_spacing_new_project_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_new_project_top',array(
    'label' => __('Pricing Plan Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));
  

  $wp_customize->add_setting('cyber_security_services_pro_spacing_testimonials_top',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_spacing_testimonials_top',array(
    'label' => __('Testimonial Spacing Top','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_section_spacing_settings',
    'type'    => 'number'
  ));
  

  // SLIDER

  $wp_customize->add_panel( $ParentPanel );

  $Parent_Slider_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_slider_section', array(
    'title' => __( 'Slider Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_Slider_Section );

  $wp_customize->add_section( 'cyber_security_services_pro_slider_section', array(
    'title' => __( 'Slider Settings', 'cyber-security-services-pro' ),
    'description' => __('Add slider images here.','cyber-security-services-pro'),
    'priority'  => null,
    'panel' => 'cyber_security_services_pro_parent_slider_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_enabledisable',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_enabledisable',array(
    'label' => esc_html__( 'Show or Hide Slider', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_slider_section'
  )));
  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_slider_enabledisable', array(
    'selector' => '.slider-box',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_slider_enabledisable',
  ));

  $wp_customize->add_setting('cyber_security_services_pro_slide_number',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_slide_number',array(
    'label' => __('Number of slides to show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_section',
    'type'    => 'number'
  ));
  $count =  get_theme_mod('cyber_security_services_pro_slide_number');
  
  for($i=1; $i<=$count; $i++ ) {

    $wp_customize->add_setting( 'cyber_security_services_pro_slider_section_settings'.$i, array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_section_settings'.$i,
      array(
      'label' => __('Slider Settings ','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section'
    )));

    $wp_customize->add_setting('cyber_security_services_pro_slide_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_slide_image'.$i,array(
      'label' => __('Slider Image ','cyber-security-services-pro').$i.__(' (1020x904)','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_slider_section',
      'settings' => 'cyber_security_services_pro_slide_image'.$i
    )));

   $wp_customize->add_setting('cyber_security_services_pro_slide_small_heading'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_small_heading'.$i,array(
      'label' => __('Slide Small Heading','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_small_heading'.$i,
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_slide_heading'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_heading'.$i,array(
      'label' => __('Slide Heading','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_heading'.$i,
      'type'  => 'text'
    ));
    
    $wp_customize->add_setting('cyber_security_services_pro_slide_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_text'.$i,array(
      'label' => __('Slide Text','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_text'.$i,
      'type'  => 'textarea'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_slide_start_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_start_btn'.$i,array(
      'label' => __('Slide Start Button','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_start_btn'.$i,
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_slide_start_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_start_btn_url'.$i,array(
      'label' => __('Slide Start Button Url','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_start_btn_url'.$i,
      'type'  => 'url'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_slide_quote_btn'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_quote_btn'.$i,array(
      'label' => __('Slide Quote Button','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_quote_btn'.$i,
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_slide_quote_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_slide_quote_btn_url'.$i,array(
      'label' => __('Slide Quote Button Url','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_slider_section',
      'setting' => 'cyber_security_services_pro_slide_quote_btn_url'.$i,
      'type'  => 'url'
    ));

    
    
  }
  // $wp_customize->add_setting( 'cyber_security_services_pro_slider_dots',   array(
  //   'default' => 1,
  //   'transport' => 'refresh',
  //   'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  // ));

  // $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_dots', array(
  //   'label' => esc_html__( 'Show/Hide Slider dots', 'cyber-security-services-pro' ),
  //   'section' => 'cyber_security_services_pro_slider_section'
  // )));
$wp_customize->add_setting('cyber_security_services_pro_slide_delay',array(
    'default' => '1000',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_slide_delay',array(
    'label' => __('Slide Delay','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_section',
    'description' => __('interval is in milliseconds. 1000 = 1 second -> so 1000 * 10 = 10 seconds', 'cyber-security-services-pro'),
    'type'    => 'number'
  ));
  
  // $wp_customize->add_setting( 'cyber_security_services_pro_slider_arrows',   array(
  //   'default' => 1,
  //   'transport' => 'refresh',
  //   'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  // ));

  // $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_arrows', array(
  //   'label' => esc_html__( 'Show/Hide Slider Nav', 'cyber-security-services-pro' ),
  //   'section' => 'cyber_security_services_pro_slider_section'
  // )));

  // SLIDER COLOR SETTINGS

  $wp_customize->add_panel( $Parent_Slider_Section );

  $wp_customize->add_section( 'cyber_security_services_pro_slider_color_section', array(
    'title' => __( 'Slider Color Settings', 'cyber-security-services-pro' ),
    'description' => __('Add slider color settings here.','cyber-security-services-pro'),
    'priority'  => null,
    'panel' => 'cyber_security_services_pro_parent_slider_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_color_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_color_settings',array(
    'label' => __('Slider Color Settings ','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_bgcolor', array(
    'label' => __('Slider Background Color', 'cyber-security-services-pro'),
    'description' => __('Either add background color or background image, if you add both background color will be top most priority', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_bgcolor',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_opacity',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_opacity',array(
    'label' => __('Slider Background Opacity','cyber-security-services-pro'),
    'description' => __('Add the opacity in between (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'type'    => 'text'
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_small_head_font', array(
    'section'  => 'cyber_security_services_pro_slider_color_section',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_small_head_bgcolor',
  ))); 

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_title_color', array(
    'label' => __('Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_title_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_title_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_title_font', array(
    'section'  => 'cyber_security_services_pro_slider_color_section',
    'label'    => __( 'Title Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_text_color', array(
    'label' => __('Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_text_font', array(
    'section'  => 'cyber_security_services_pro_slider_color_section',
    'label'    => __( 'Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_btncolor_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_slider_btncolor_settings',array(
    'label' => __('Slider Button Settings ','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_quotebtn_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_quotebtn_text_color', array(
    'label' => __('Quote Button Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_quotebtn_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_quotebtn_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_quotebtn_text_font', array(
    'section'  => 'cyber_security_services_pro_slider_color_section',
    'label'    => __( 'Quote Button Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_quotebtn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_quotebtn_bgcolor', array(
    'label' => __('Quote Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_quotebtn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_read_btn_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_read_btn_text_color', array(
    'label' => __('Start Button Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_read_btn_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_slider_read_btn_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_slider_read_btn_text_font', array(
    'section'  => 'cyber_security_services_pro_slider_color_section',
    'label'    => __( 'Start Button Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_read_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_read_btn_bgcolor', array(
    'label' => __('Start Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_read_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_btn_hover_bgcolor', array(
    'label' => __('Button Background Hover Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_slider_btn_texthover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_slider_btn_texthover_color', array(
    'label' => __('Button Hover Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_slider_color_section',
    'settings' => 'cyber_security_services_pro_slider_btn_texthover_color',
  )));
  //------------------- About Us------------------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_about_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_about_section', array(
    'title' => __( 'About us Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_about_Section );

  $wp_customize->add_section('cyber_security_services_pro_about',array(
    'title' => __('About Settings','cyber-security-services-pro'),
    'description' => __('Add About Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_about_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_about_enable', array(
    'label' => esc_html__( 'Show or Hide About Section', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_about'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_about_enable', array(
    'selector' => '#about .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_about_enable',
  ));

  $wp_customize->add_setting('cyber_security_services_pro_about_image1',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_about_image1', array(
      'label' => __('About Image1','cyber-security-services-pro'),
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_about',
      'settings' => 'cyber_security_services_pro_about_image1'
    )));

    $wp_customize->add_setting('cyber_security_services_pro_about_image2',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_about_image2', array(
      'label' => __('About Image2','cyber-security-services-pro'),
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_about',
      'settings' => 'cyber_security_services_pro_about_image2'
    )));

    $wp_customize->add_setting('cyber_security_services_pro_about_image3',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_about_image3', array(
      'label' => __('About Image3','cyber-security-services-pro'),
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_about',
      'settings' => 'cyber_security_services_pro_about_image3'
    )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_content_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_about_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_about_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_heading',array(
    'label' => __('About Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about',
    'setting' => 'cyber_security_services_pro_about_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_about_small_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_small_heading',array(
    'label' => __('About Small Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about',
    'setting' => 'cyber_security_services_pro_about_small_heading',
    'type'    => 'text'
  ));
  
  $wp_customize->add_setting('cyber_security_services_pro_about_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_text',array(
    'label' => __('About Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about',
    'setting' => 'cyber_security_services_pro_about_text',
    'type'    => 'textarea'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_about_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_about_btn',array(
      'label' => __('About Button','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_about',
      'setting' => 'cyber_security_services_pro_about_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_about_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_about_btn_url',array(
      'label' => __('About Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_about',
      'setting' => 'cyber_security_services_pro_about_btn_url',
      'type'  => 'url'
    ));

  // About COLOR SETTINGS

  $wp_customize->add_panel( $Parent_about_Section );

  $wp_customize->add_section('cyber_security_services_pro_about_color_settings',array(
    'title' => __('About Color Settings','cyber-security-services-pro'),
    'description' => __('Add About Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_about_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_about_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_about_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_about_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_about_heading_color_settings',array(
    'label' => __('Heading Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_heading_color', array(
    'label' => __('Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_about_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_heading_font', array(
    'section'  => 'cyber_security_services_pro_about_color_settings',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_about_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_small_head_font', array(
    'section'  => 'cyber_security_services_pro_about_color_settings',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_small_head_bgcolor',
  ))); 

  $wp_customize->add_setting( 'cyber_security_services_pro_about_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_text_color', array(
    'label' => __('Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_about_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_text_font', array(
    'section'  => 'cyber_security_services_pro_about_color_settings',
    'label'    => __( 'Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));  

  $wp_customize->add_setting( 'cyber_security_services_pro_about_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_btn_color', array(
    'label' => __('About Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_btn_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_about_btn_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_about_btn_font', array(
    'section'  => 'cyber_security_services_pro_about_color_settings',
    'label'    => __( 'About button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_btn_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_about_box_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_about_box_btn_text_hover_color', array(
    'label' => __('About Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_about_color_settings',
    'settings' => 'cyber_security_services_pro_about_box_btn_text_hover_color',
  )));

    // --------------Achievement--------------

$wp_customize->add_panel( $ParentPanel );

  $Parent_achievement_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_achievement_section', array(
    'title' => __( 'Achievement Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_achievement_Section );

  $wp_customize->add_section('cyber_security_services_pro_achievement',array(
    'title' => __('
    Achievement Settings','cyber-security-services-pro'),
    'description' => __('Add Achievement Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_achievement_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_achievement_enable', array(
    'label' => esc_html__( 'Show or Hide Achievement', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_achievement'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_achievement_enable', array(
    'selector' => '#Achievement .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_achievement_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_achievement_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_bg_img',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_achievement_bg_img', array(
      'label' => __('Background Image','cyber-security-services-pro'),
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_achievement',
      'settings' => 'cyber_security_services_pro_achievement_bg_img'
    )));


  $wp_customize->add_setting('cyber_security_services_pro_achievement_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_achievement_head',array(
    'label' => __('Achievement Left Count','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement',
    'setting' => 'cyber_security_services_pro_achievement_head',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cyber_security_services_pro_achievement_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_achievement_text',array(
    'label' => __('Achievement Left Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement',
    'setting' => 'cyber_security_services_pro_achievement_text',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_increase',array(
    'default' => '6',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_achievement_increase',array(
    'label' => __('No of Achievement to Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement',
    'setting' => 'cyber_security_services_pro_achievement_increase',
    'type'    => 'number'
  )); 
  $achieve_number=get_theme_mod('cyber_security_services_pro_achievement_increase');
  for($i=1; $i<=$achieve_number; $i++) {
    
  $wp_customize->add_setting('cyber_security_services_pro_achievement_count'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_achievement_count'.$i,array(
    'label' => __('Achievement Count','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_achievement',
    'setting' => 'cyber_security_services_pro_achievement_count'.$i,
    'type'  => 'text'
  ));

    $wp_customize->add_setting('cyber_security_services_pro_achievement_inner_head'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_achievement_inner_head'.$i,array(
    'label' => __('Achievement Inner Head','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_achievement',
    'setting' => 'cyber_security_services_pro_achievement_inner_head'.$i,
    'type'  => 'text'
  ));
}    

  // Achievement COLOR SETTINGS

  $wp_customize->add_panel( $Parent_achievement_Section );

  $wp_customize->add_section('cyber_security_services_pro_achievement_color_settings',array(
    'title' => __('Achievement Color Settings','cyber-security-services-pro'),
    'description' => __('Add Achievement Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_achievement_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_achievement_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_achievement_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_achievement_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_achievement_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_content_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_achievement_content_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_main_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_achievement_main_head_color', array(
    'label' => __('Left Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_main_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_main_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_achievement_main_head_font', array(
    'section'  => 'cyber_security_services_pro_achievement_color_settings',
    'label'    => __( 'Left Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

$wp_customize->add_setting( 'cyber_security_services_pro_achievement_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_achievement_text_color', array(
    'label' => __('Left Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_achievement_text_font', array(
    'section'  => 'cyber_security_services_pro_achievement_color_settings',
    'label'    => __( 'Left Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_count_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_achievement_count_color', array(
    'label' => __('Count Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_count_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_count_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_achievement_count_font', array(
    'section'  => 'cyber_security_services_pro_achievement_color_settings',
    'label'    => __( 'Count Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_achievement_inner_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_achievement_inner_heading_color', array(
    'label' => __('Inner Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_achievement_color_settings',
    'settings' => 'cyber_security_services_pro_achievement_inner_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_achievement_inner_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_achievement_inner_heading_font', array(
    'section'  => 'cyber_security_services_pro_achievement_color_settings',
    'label'    => __( 'Inner Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));


      // ---------------OUR-SERVICES---------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_services_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_our_services_section', array(
    'title' => __( 'Our Services Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_services_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_services',array(
    'title' => __('
    Our Services Settings','cyber-security-services-pro'),
    'description' => __('Add Our Services Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_services_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_services_enable', array(
    'label' => esc_html__( 'Show or Hide Our Services', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_our_services'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_our_services_enable', array(
    'selector' => '#our_services .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_our_services_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_services_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services'
  ))); 

  $wp_customize->add_setting('cyber_security_services_pro_our_services_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_services_small_head',array(
    'label' => __('Services Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services',
    'setting' => 'cyber_security_services_pro_our_services_small_head',
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_services_heading',array(
    'label' => __('Services Heading ','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services',
    'setting' => 'cyber_security_services_pro_our_services_heading',
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_services_post_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_services_post_number',array(
    'label' => __('No Of Posts To Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services',
    'setting' => 'cyber_security_services_pro_services_post_number',
    'type'    => 'number'
  )); 

  $events_count=get_theme_mod('cyber_security_services_pro_our_services_number');
  $args = array(
    'type'                     => 'service',
    'child_of'                 => 0,
    'parent'                   => '',
    'orderby'                  => 'term_group',
    'order'                    => 'ASC',
    'hide_empty'               => false,
    'hierarchical'             => 1,
    'number'                   => '',
    'taxonomy'                 => 'servicecategory',
    'pad_counts'               => false
  );
  $categories = get_categories( $args );
  $cats = array();
  
  foreach($categories as $category){
    $cats[$category->name] = $category->name;
  }
    for($i=1;$i<=$events_count;$i++)
  { 
    
}

$wp_customize->add_setting('cyber_security_services_pro_services_outer_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_services_outer_btn',array(
      'label' => __('Button Text','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_our_services',
      'setting' => 'cyber_security_services_pro_services_outer_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_services_outer_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_services_outer_btn_url',array(
      'label' => __('Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_our_services',
      'setting' => 'cyber_security_services_pro_services_outer_btn_url',
      'type'  => 'url'
    ));


  // Our Services COLOR SETTINGS

  $wp_customize->add_panel( $Parent_services_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_services_color_settings',array(
    'title' => __('Our Services Color Settings','cyber-security-services-pro'),
    'description' => __('Add Our Services Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_services_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_services_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_our_services_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_our_services_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_content_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_services_content_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_our_services_small_head_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_small_head_bgcolor',
  )));
  
   $wp_customize->add_setting( 'cyber_security_services_pro_our_services_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_heading_color', array(
    'label' => __('Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_our_services_heading_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_inner_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_inner_heading_color', array(
    'label' => __('Inner Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_inner_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_inner_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_our_services_inner_heading_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Inner Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

$wp_customize->add_setting( 'cyber_security_services_pro_our_services_inner_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_inner_text_color', array(
    'label' => __('Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_inner_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_inner_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_our_services_inner_text_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_services_button_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_services_button_text_color', array(
    'label' => __('Service Button Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_our_services_button_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_services_button_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_our_services_button_text_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Service Button Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_outer_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_outer_btn_color', array(
    'label' => __('Services Outer Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_outer_btn_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_services_outer_btn_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_services_outer_btn_font', array(
    'section'  => 'cyber_security_services_pro_our_services_color_settings',
    'label'    => __( 'Services Outer button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_outer_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_outer_btn_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_outer_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_outer_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_outer_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_outer_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_outer_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_outer_btn_text_hover_color', array(
    'label' => __('Services Outer Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_outer_btn_text_hover_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_read_button_arrow_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_read_button_arrow_icon_color', array(
    'label' => __('Button Arrow Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_read_button_arrow_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_services_read_button_arrow_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_services_read_button_arrow_icon_bgcolor', array(
    'label' => __('Button Arrow Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_services_color_settings',
    'settings' => 'cyber_security_services_pro_services_read_button_arrow_icon_bgcolor'
  )));

// -------------- CHOOSE US----------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_product_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_choose_us_section', array(
    'title' => __( 'Choose Us Option', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_product_Section );

  $wp_customize->add_section('cyber_security_services_pro_choose_us',array(
    'title' => __('Choose Us','cyber-security-services-pro'),
    'description' => __('Add Choose Us Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_choose_us_section',
  ));
  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_enable',
    array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
    ));
   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_choose_us_enable',
    array(
      'label' => esc_html__( 'Show or Hide Section', 'cyber-security-services-pro' ),
      'section' => 'cyber_security_services_pro_choose_us'
  )));
  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_choose_us_enable', array(
    'selector' => '#choose_us .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_choose_us_enable',
  )); 

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_content_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_custom_Control( $wp_customize, 'cyber_security_services_pro_choose_us_content_settings',
    array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_small_head',array(
    'label' => __('Section Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_small_head',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_main_heading',array(
    'label' => __('Section Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_main_heading',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_text',array(
    'label' => __('Section Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_text',
    'type'    => 'textarea'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_increase',array(
    'default' => '3',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_increase',array(
    'label' => __('No of Choose list to Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_increase',
    'type'    => 'number'
  )); 
  $choose_number=get_theme_mod('cyber_security_services_pro_choose_us_increase');
  for($i=1; $i<=$choose_number; $i++) {    

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_inner_list'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_inner_list'.$i,array(
    'label' => __('Choose list','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_inner_list'.$i,
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cyber_security_services_pro_choose_us_tick_icon'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_tick_icon'.$i,array(
    'label' => __('Choose Tick Icon','cyber-security-services-pro').$i,
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_tick_icon'.$i,
    'type'    => 'text'
  ));
  }
  $wp_customize->add_setting('cyber_security_services_pro_choose_us_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_choose_us_btn',array(
      'label' => __('Choose Button','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us',
      'setting' => 'cyber_security_services_pro_choose_us_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_choose_us_btn_url',array(
      'label' => __('Choose Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us',
      'setting' => 'cyber_security_services_pro_choose_us_btn_url',
      'type'  => 'url'
    ));


  $wp_customize->add_setting('cyber_security_services_pro_choose_us_image',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_choose_us_image', array(
      'label' => __('Choose Us Image','cyber-security-services-pro'),
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us',
      'settings' => 'cyber_security_services_pro_choose_us_image'
    )));   

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_right_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_right_head',array(
    'label' => __('Section Right Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_right_head',
    'type'    => 'text'
  )); 

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_increase2',array(
    'default' => '3',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_increase2',array(
    'label' => __('No of Choose list to Show on Right','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_increase2',
    'type'    => 'number'
  )); 
  $choose_number=get_theme_mod('cyber_security_services_pro_choose_us_increase2');
  for($i=1; $i<=$choose_number; $i++) {    

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_right_list'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_right_list'.$i,array(
    'label' => __('Right Choose list','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_choose_us',
    'setting' => 'cyber_security_services_pro_choose_us_right_list'.$i,
    'type'    => 'text'
  ));

  }
  
  //---------Choose Us color setting-----------

  $wp_customize->add_panel( $Parent_product_Section );

  $wp_customize->add_section('cyber_security_services_pro_choose_us_color_settings',array(
    'title' => __('Choose Us Color Settings','cyber-security-services-pro'),
    'description' => __('Add Choose Us Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_choose_us_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_custom_Control( $wp_customize, 'cyber_security_services_pro_choose_us_settings',
    array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings'
  )));
  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_choose_us_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_choose_us_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_color_settings',
    array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_custom_Control( $wp_customize, 'cyber_security_services_pro_choose_us_color_settings',
        array(
        'label' => __('Section Color Settings ','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_choose_us_color_settings'
    )));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_small_heading_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_small_heading_color', array(
      'label' => __('Small Heading Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_small_heading_color',
    )));
   $wp_customize->add_setting('cyber_security_services_pro_choose_us_small_heading_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_small_heading_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Small Heading Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));


  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_small_head_bgcolor',
  )));
  

    $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_main_heading_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_main_heading_color', array(
      'label' => __('Main Heading Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_main_heading_color',
    )));
   $wp_customize->add_setting('cyber_security_services_pro_choose_us_main_heading_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_main_heading_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Main Heading Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));
    
   $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_text_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_text_color', array(
      'label' => __('Text Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_text_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_text_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_text_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Text Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_inner_smhead_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_inner_smhead_color', array(
      'label' => __('Inner List Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_inner_smhead_color',
    )));
    $wp_customize->add_setting('cyber_security_services_pro_choose_us_inner_smhead_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_inner_smhead_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Inner List Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_btn_color', array(
    'label' => __('Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_btn_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_choose_us_btn_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_choose_us_btn_font', array(
    'section'  => 'cyber_security_services_pro_choose_us_color_settings',
    'label'    => __( 'Button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_btn_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_box_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_box_btn_text_hover_color', array(
    'label' => __('Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_choose_us_color_settings',
    'settings' => 'cyber_security_services_pro_choose_us_box_btn_text_hover_color',
  )));


    $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_right_head_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_right_head_color', array(
      'label' => __('Right Head Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_right_head_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_right_head_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_right_head_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Right Head Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_choose_us_right_list_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_choose_us_right_list_color', array(
      'label' => __('Right List Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_choose_us_color_settings',
      'settings' => 'cyber_security_services_pro_choose_us_right_list_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_choose_us_right_list_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_choose_us_right_list_font_family', array(
        'section'  => 'cyber_security_services_pro_choose_us_color_settings',
        'label'    => __( 'Right List Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));


// Pricing-Plans

  $wp_customize->add_panel( $ParentPanel );

  $Parent_pricing_plan_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_pricing_plan_section', array(
    'title' => __( 'Pricing Plans Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_pricing_plan_Section );

  $wp_customize->add_section('cyber_security_services_pro_pricing_plan',array(
    'title' => __('Pricing Plans Settings','cyber-security-services-pro'),
    'description' => __('Add Pricing Plans Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_pricing_plan_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_enable', array(
    'label' => esc_html__( 'Show or Hide about Section', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_pricing_plan'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_pricing_plan_enable', array(
    'selector' => '#about .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_pricing_plan_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_content_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_small_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_pricing_plan_small_heading',array(
    'label' => __('Section Small Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan',
    'setting' => 'cyber_security_services_pro_pricing_plan_small_heading',
    'type'    => 'text'
  ));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_pricing_plan_main_heading',array(
    'label' => __('Section Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan',
    'setting' => 'cyber_security_services_pro_pricing_plan_main_heading',
    'type'    => 'text'
  ));
  
    $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_increase',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cyber_security_services_pro_pricing_plan_increase',array(
      'label' => __('No of Plans To Show ','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_pricing_plan',
      'setting' => 'cyber_security_services_pro_pricing_plan_increase',
      'type'    => 'number'
    ));

    $plans=get_theme_mod('cyber_security_services_pro_pricing_plan_increase');
    for($i=1;$i<=$plans;$i++)
    {

      $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_info_settings'.$i,
    array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
      ));
      $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_info_settings'.$i,
        array(
        'label' => __('Pricing Plan ','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan'
      )));
      
      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_price'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_price'.$i,array(
        'label' => __('Plan Price For Month','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_price'.$i,
        'type'    => 'text'
      ));

      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_permonth'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_permonth'.$i,array(
        'label' => __('Plan Price Option For Month','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_permonth'.$i,
        'type'    => 'text'
      ));

    $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_price_year'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_price_year'.$i,array(
        'label' => __('Plan Price For Year','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_price_year'.$i,
        'type'    => 'text'
      ));

      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_peryear'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_peryear'.$i,array(
        'label' => __('Plan Price Option For year','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_peryear'.$i,
        'type'    => 'text'
      ));

      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_pack_option'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_pack_option'.$i,array(
        'label' => __('Plan Pack Option','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_pack_option'.$i,
        'type'    => 'text'
      ));

      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_inn_text'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_inn_text'.$i,array(
        'label' => __('Plan Inner Text','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_inn_text'.$i,
        'type'    => 'text'
      ));

      
      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_features_no'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_features_no'.$i,array(
        'label' => __('No Of Features To Show','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_features_no'.$i,
        'type'    => 'number'
      ));
      $plan_features=get_theme_mod('cyber_security_services_pro_pricing_plan_features_no'.$i);
      for($j=1;$j<=$plan_features;$j++)
      {
        $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_features'.$i.$j,array(
          'default' => '',
          'sanitize_callback' => 'sanitize_text_field'
        ));
        $wp_customize->add_control('cyber_security_services_pro_pricing_plan_features'.$i.$j,array(
          'label' => __('Plan Feature','cyber-security-services-pro').$i.$j,
          'section' => 'cyber_security_services_pro_pricing_plan',
          'setting' => 'cyber_security_services_pro_pricing_plan_features'.$i.$j,
          'type'    => 'text'
        ));

  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j,array(
    'label' => __('Tick Icon','cyber-security-services-pro').$i.$j,
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan',
    'setting' => 'cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j,
    'type'    => 'text'
  ));
      }
      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_button_title'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_button_title'.$i,array(
        'label' => __('Plan Button Title','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_button_title'.$i,
        'type'    => 'text'
      ));
      $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_button_url'.$i,array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
      ));
      $wp_customize->add_control('cyber_security_services_pro_pricing_plan_button_url'.$i,array(
        'label' => __('Plan Button Url','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_pricing_plan',
        'setting' => 'cyber_security_services_pro_pricing_plan_button_url'.$i,
        'type'    => 'text'
      ));
  }


  // Pricing Plans COLOR SETTINGS

  $wp_customize->add_panel( $Parent_pricing_plan_Section );

  $wp_customize->add_section('cyber_security_services_pro_pricing_plan_color_settings',array(
    'title' => __('Pricing Plans Color Settings','cyber-security-services-pro'),
    'description' => __('Add Pricing Plans Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_pricing_plan_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_pricing_plan_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_heading_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_small_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_small_heading_color', array(
    'label' => __('Section Small Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_small_heading_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_small_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_small_heading_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Section Small Heading Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_small_head_bgcolor',
  )));

  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_small_heading_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_small_heading_font_size',array(
  //   'label' => __('Small heading Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_small_heading_font_size',
  //   'type'    => 'number'
  // ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_main_head_ct_pallete',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_main_head_ct_pallete',
    array(
    'label' => __('Main Heading Typography','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_main_heading_color', array(
    'label' => __('Section Main Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_main_heading_color'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_main_heading_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Section Main Heading Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_tab_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_tab_title_color', array(
    'label' => __('Tab Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_tab_title_color'
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_tab_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_tab_title_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Tab Title Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_main_heading_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_main_heading_font_size',array(
  //   'label' => __('Main heading Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_main_heading_font_size',
  //   'type'    => 'number'
  // ));  

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_ct_pallete',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_ct_pallete',
    array(
    'label' => __('Plan Box Typography','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_bgcolor', array(
    'label' => __('Plan Box Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_box_bgcolor'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_price_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_price_color', array(
    'label' => __('Plan Price Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_price_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_price_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_price_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Plan Price Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_discount_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_discount_font_size',array(
  //   'label' => __('Discount Title Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_discount_font_size',
  //   'type'    => 'number'
  // ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_main_title_ct_pallete',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_main_title_ct_pallete',
    array(
    'label' => __('Plan Main Title Typography','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_pack_option_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_pack_option_title_color', array(
    'label' => __('Plan Pack Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_pack_option_title_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_pack_option_title_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_pack_option_title_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Plan Pack Title Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_inner_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_inner_text_color', array(
    'label' => __('Inner Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_inner_text_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_inner_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_inner_text_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Inner Text Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_main_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_main_font_size',array(
  //   'label' => __('Plan Main Title Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_main_font_size',
  //   'type'    => 'number'
  // ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_listing_ct_pallete',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_listing_ct_pallete',
    array(
    'label' => __('Plan Listing Typography','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_feature_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_feature_color', array(
    'label' => __('Plan Features Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_feature_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_features_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_features_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Plan Features Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_tick_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_tick_icon_color', array(
    'label' => __('Tick Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_tick_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_tick_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_tick_icon_bgcolor', array(
    'label' => __('Tick Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_tick_icon_bgcolor',
  )));


  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_features_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_features_font_size',array(
  //   'label' => __('Plan Features Title Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_features_font_size',
  //   'type'    => 'number'
  // ));

  
  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_button_ct_pallete',
    array(
      'default' => '',
      'transport' => 'postMessage',
      'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_button_ct_pallete',
    array(
    'label' => __('Plan Button Typography','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_button_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_button_color', array(
    'label' => __('Plan Button Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_button_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_button_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_pricing_plan_button_font_family', array(
    'section'  => 'cyber_security_services_pro_pricing_plan_color_settings',
    'label'    => __('Plan Button Title Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_box_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_box_btn_text_hover_color', array(
    'label' => __('Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_box_btn_text_hover_color',
  )));
  
  // $wp_customize->add_setting('cyber_security_services_pro_pricing_plan_button_font_size',array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_text_field'
  // ));
  // $wp_customize->add_control('cyber_security_services_pro_pricing_plan_button_font_size',array(
  //   'label' => __('Plan Button Font Size','cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_pricing_plan',
  //   'setting' => 'cyber_security_services_pro_pricing_plan_button_font_size',
  //   'type'    => 'number'
  // ));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_button_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_button_bgcolor', array(
    'label' => __('Plan Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_button_bgcolor'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pricing_plan_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pricing_plan_hover_bgcolor', array(
    'label' => __('Pricing Plan Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_pricing_plan_color_settings',
    'settings' => 'cyber_security_services_pro_pricing_plan_hover_bgcolor',
  )));

   // -----------------Our Experts------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_our_experts_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_our_experts_section', array(
    'title' => __( 'Our Experts Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_our_experts_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_experts',array(
    'title' => __('Our Experts Settings','cyber-security-services-pro'),
    'description' => __('Add Our Experts Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_experts_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_experts_enable', array(
    'label' => esc_html__( 'Show or Hide Our Experts', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_our_experts'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_our_experts_enable', array(
    'selector' => '#our_experts .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_our_experts_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_experts_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_small_head',array(
    'label' => __('Experts Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts',
    'setting' => 'cyber_security_services_pro_our_experts_small_head',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_heading',array(
    'label' => __('Experts Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts',
    'setting' => 'cyber_security_services_pro_our_experts_heading',
    'type'    => 'text'
  ));
    
  $wp_customize->add_setting('cyber_security_services_pro_our_experts_post_number',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_post_number',array(
    'label' => __('No Of Posts To Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts',
    'setting' => 'cyber_security_services_pro_our_experts_post_number',
    'type'    => 'number'
  )); 

  $events_count=get_theme_mod('cyber_security_services_pro_our_experts_number');
  $args = array(
    'type'                     => 'our-experts',
    'child_of'                 => 0,
    'parent'                   => '',
    'orderby'                  => 'term_group',
    'order'                    => 'ASC',
    'hide_empty'               => false,
    'hierarchical'             => 1,
    'number'                   => '',
    'taxonomy'                 => 'Expertscategory',
    'pad_counts'               => false
  );
  $categories = get_categories( $args );
  $cats = array();
  
  foreach($categories as $category){
    $cats[$category->name] = $category->name;
  }
    for($i=1;$i<=$events_count;$i++)
  { 

$wp_customize->add_setting('cyber_security_services_pro_our_experts_categoryselection_setting'.$i,array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_our_experts_categoryselection_setting'.$i,array(
        'description' => 'Select Experts Category From Dropdown',
        'type'    => 'select',
        'choices' => $cats,
        'label' => __('Category ','cyber-security-services-pro').$i,
        'section' => 'cyber_security_services_pro_our_experts',
    ));
  }

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_outer_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_our_experts_outer_btn',array(
      'label' => __('Button Text','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_our_experts',
      'setting' => 'cyber_security_services_pro_our_experts_outer_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_our_experts_outer_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_our_experts_outer_btn_url',array(
      'label' => __('Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_our_experts',
      'setting' => 'cyber_security_services_pro_our_experts_outer_btn_url',
      'type'  => 'url'
    ));

    // $wp_customize->add_setting('cyber_security_services_pro_our_experts_social_facebook',array(
    //   'default' => '',
    //   'sanitize_callback' => 'esc_url_raw',
    // ));
    // $wp_customize->add_control('cyber_security_services_pro_our_experts_social_facebook',array(
    //   'label' => __('Members Facebook Link ','cyber-security-services-pro'),
    //   'section' => 'cyber_security_services_pro_our_experts',
    //   'setting' => 'cyber_security_services_pro_our_experts_social_facebook',
    //   'type'  => 'url'
    // ));

    // $wp_customize->add_setting('cyber_security_services_pro_our_experts_social_twitter',array(
    //   'default' => '',
    //   'sanitize_callback' => 'esc_url_raw',
    // ));
    // $wp_customize->add_control('cyber_security_services_pro_our_experts_social_twitter',array(
    //   'label' => __(' Members Pintrest Link ','cyber-security-services-pro'),
    //   'section' => 'cyber_security_services_pro_our_experts',
    //   'setting' => 'cyber_security_services_pro_our_experts_social_twitter',
    //   'type'  => 'url'
    // ));

    // $wp_customize->add_setting('cyber_security_services_pro_our_experts_social_googleplus',array(
    //   'default' => '',
    //   'sanitize_callback' => 'esc_url_raw',
    // ));
    // $wp_customize->add_control('cyber_security_services_pro_our_experts_social_googleplus',array(
    //   'label' => __('Members Instagram Link ','cyber-security-services-pro'),
    //   'section' => 'cyber_security_services_pro_our_experts',
    //   'setting' => 'cyber_security_services_pro_our_experts_social_googleplus',
    //   'type'  => 'url'
    // ));

    // $wp_customize->add_setting('cyber_security_services_pro_our_experts_social_whatsapp',array(
    //   'default' => '',
    //   'sanitize_callback' => 'esc_url_raw',
    // ));
    // $wp_customize->add_control('cyber_security_services_pro_our_experts_social_whatsapp',array(
    //   'label' => __('Members Whatsapp Link ','cyber-security-services-pro'),
    //   'section' => 'cyber_security_services_pro_our_experts',
    //   'setting' => 'cyber_security_services_pro_our_experts_social_whatsapp',
    //   'type'  => 'url'
    // ));   

  // Our Experts COLOR SETTINGS

  $wp_customize->add_panel( $Parent_our_experts_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_experts_color_settings',array(
    'title' => __('Our Experts Color Settings','cyber-security-services-pro'),
    'description' => __('Add Our Experts Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_experts_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_experts_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_our_experts_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_our_experts_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_experts_heading_color_settings',array(
    'label' => __('Heading Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_heading_color', array(
    'label' => __('Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_heading_font', array(
    'section'  => 'cyber_security_services_pro_our_experts_color_settings',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_hr_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_hr_color', array(
    'label' => __('Border Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_hr_color',
  )));  

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_small_head_font', array(
    'section'  => 'cyber_security_services_pro_our_experts_color_settings',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_small_head_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_social_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_social_icon_color', array(
    'label' => __('Social Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_social_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_social_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_social_icon_bgcolor', array(
    'label' => __('Social Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_social_icon_bgcolor'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_name_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_name_color', array(
    'label' => __('Name Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_name_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_name_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_name_font', array(
    'section'  => 'cyber_security_services_pro_our_experts_color_settings',
    'label'    => __( 'Name Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_designation_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_designation_color', array(
    'label' => __( 'Designation Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_designation_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_designation_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_designation_font', array(
    'section'  => 'cyber_security_services_pro_our_experts_color_settings',
    'label'    => __('Designation Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_outer_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_outer_btn_color', array(
    'label' => __('Experts Outer Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_outer_btn_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_experts_outer_btn_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_experts_outer_btn_font', array(
    'section'  => 'cyber_security_services_pro_our_experts_color_settings',
    'label'    => __( 'Experts Outer button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_outer_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_outer_btn_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_outer_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_experts_outer_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_experts_outer_btn_text_hover_color', array(
    'label' => __('Outer Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_experts_color_settings',
    'settings' => 'cyber_security_services_pro_our_experts_outer_btn_text_hover_color',
  )));


//------------- TESTIMONIALS-------------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_Testiminials_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_testimonials_section', array(
    'title' => __( 'Testimonials Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_Testiminials_Section );

  $wp_customize->add_section('cyber_security_services_pro_testimonials',array(
    'title' => __('Testimonials Settings','cyber-security-services-pro'),
    'description' => __('Add Testimonials Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_testimonials_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_testimonials_enable', array(
    'label' => esc_html__( 'Show or Hide Testimonials', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_testimonials'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_testimonials_enable', array(
    'selector' => '#testimonials .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_testimonials_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_testimonials_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials'
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_testimonials_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_small_head',array(
    'label' => __('Testimonial Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testimonials_small_head',
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_heading',array(
    'label' => __('Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testimonials_heading',
    'type'  => 'text'
  ));  

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_increase',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_increase',array(
    'label' => __('No Of Testimonials To Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testimonials_increase',
    'type'    => 'number'
  )); 
  
$testi_count=get_theme_mod('cyber_security_services_pro_testimonials_increase');
for($i=1;$i<=$testi_count;$i++)
  { 

    $wp_customize->add_setting('cyber_security_services_pro_testimonials_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_testimonials_image'.$i,array(
      'label' => __('Testimonials Image ','cyber-security-services-pro').$i,
      'description' => __('Dimention 300 * 300','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_testimonials',
      'settings' => 'cyber_security_services_pro_testimonials_image'.$i
    )));

    $wp_customize->add_setting('cyber_security_services_pro_testimonials_member_name'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_member_name'.$i,array(
    'label' => __('Testimonial Name','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testimonials_member_name'.$i,
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_member_designation'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_member_designation'.$i,array(
    'label' => __('Testimonial Designation','cyber-security-services-pro').$i,
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testimonials_member_designation'.$i,
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_client_text'.$i,array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_testimonials_client_text'.$i,array(
      'label' => __('Testimonial Inner Text','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_testimonials',
      'setting' => 'cyber_security_services_pro_testimonials_client_text'.$i,
      'type'  => 'textarea'
    ));


    $wp_customize->add_setting('cyber_security_services_pro_testi_quote_icon'.$i,array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testi_quote_icon'.$i,array(
    'label' => __('Quote Icon','cyber-security-services-pro').$i,
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials',
    'setting' => 'cyber_security_services_pro_testi_quote_icon'.$i,
    'type'    => 'text'
  ));

    } 
  

  // TESTIMONIALS COLOR SETTINGS

  $wp_customize->add_panel( $Parent_Testiminials_Section );

  $wp_customize->add_section('cyber_security_services_pro_testimonials_color_settings',array(
    'title' => __('Testimonials Color Settings','cyber-security-services-pro'),
    'description' => __('Add Testimonials Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_testimonials_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_testimonials_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_testi_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testi_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testi_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_testi_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_testi_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testi_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_testimonials_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_content_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_content_bgcolor', array(
    'label' => __('Text Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_content_bgcolor',
  )));


  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_small_head_color', array(
    'label' => __( 'Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_small_head_font', array(
    'section'  => 'cyber_security_services_pro_testimonials_color_settings',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_small_head_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_heading_color', array(
    'label' => __('Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_testimonials_heading_font', array(
    'section'  => 'cyber_security_services_pro_testimonials_color_settings',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_name_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_name_color', array(
    'label' => __('Name Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_name_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_name_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_name_font', array(
    'section'  => 'cyber_security_services_pro_testimonials_color_settings',
    'label'    => __( 'Name Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

$wp_customize->add_setting( 'cyber_security_services_pro_testimonials_designation_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_designation_color', array(
    'label' => __('Designation Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_designation_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_designation_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_designation_font', array(
    'section'  => 'cyber_security_services_pro_testimonials_color_settings',
    'label'    => __( 'Designation Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_inner_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_inner_text_color', array(
    'label' => __('Inner Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_inner_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_testimonials_inner_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_testimonials_inner_text_font', array(
    'section'  => 'cyber_security_services_pro_testimonials_color_settings',
    'label'    => __( 'Inner Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  // $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_quote_icon_color', array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_hex_color'
  // ));
  // $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_quote_icon_color', array(
  //   'label' => __('Quote Icon Color', 'cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_testimonials_color_settings',
  //   'settings' => 'cyber_security_services_pro_testimonials_quote_icon_color',
  // )));

  $wp_customize->add_setting( 'cyber_security_services_pro_testimonials_content_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_testimonials_content_bgcolor', array(
    'label' => __('Content Box Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_testimonials_color_settings',
    'settings' => 'cyber_security_services_pro_testimonials_content_bgcolor',
  )));

 //-------------- LATEST NEWS------------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_Latest_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_latest_news_section', array(
    'title' => __( 'Latest News Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_Latest_Section );

  $wp_customize->add_section('cyber_security_services_pro_latest_news',array(
    'title' => __('Latest News Settings','cyber-security-services-pro'),
    'description' => __('Add Latest News Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_latest_news_section',
  ));
  
  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_latest_news_enable', array(
    'label' => esc_html__( 'Show or Hide Latest News', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_latest_news'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_latest_news_enable', array(
    'selector' => '#latest_news .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_latest_news_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_content_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_latest_news_content_settings',
    array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news'
  ))); 

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_small_head',array(
    'label' => __('Latest News Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news',
    'setting' => 'cyber_security_services_pro_latest_news_small_head',
    'type'    => 'text'
  )); 

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_heading',array(
    'label' => __('Latest News Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news',
    'setting' => 'cyber_security_services_pro_latest_news_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_increase',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_increase',array(
    'label' => __('No Of Latest News To Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news',
    'setting' => 'cyber_security_services_pro_latest_news_increase',
    'type'    => 'number'
  ));

  $categories = get_categories();
  $cats = array();
  $i = 0;
  $cat_post[]= 'select';
  foreach($categories as $category){
  if($i==0){
    $default = $category->slug;
    $i++;
  }
  $cat_post[$category->slug] = $category->name;
  }

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_category',array(
    'default' => 'select',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_select',
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_category',array(
    'type'    => 'select',
    'choices' => $cat_post,
    'label' => esc_html__('Select Category to display Post','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news',
  ));
  

$wp_customize->add_setting('cyber_security_services_pro_latest_news_outer_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_latest_news_outer_btn',array(
      'label' => __('Outer Button Text','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_latest_news',
      'setting' => 'cyber_security_services_pro_latest_news_outer_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_latest_news_outer_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_latest_news_outer_btn_url',array(
      'label' => __('Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_latest_news',
      'setting' => 'cyber_security_services_pro_latest_news_outer_btn_url',
      'type'  => 'url'
    ));

  // LATEST NEWS COLOR SETTINGS

  $wp_customize->add_panel( $Parent_Latest_Section );

  $wp_customize->add_section('cyber_security_services_pro_latest_news_color_settings',array(
    'title' => __('Latest News Color Settings','cyber-security-services-pro'),
    'description' => __('Add Latest News Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_latest_news_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_latest_news_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings'
  )));
  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_latest_news_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_latest_news_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_content_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_latest_news_content_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_small_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_small_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_small_head_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Small Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_small_head_bgcolor',
  )));


  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_heading_color', array(
    'label' => __('Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('cyber_security_services_pro_latest_news_heading_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  
  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_post_admin_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_post_admin_color', array(
    'label' => __('Post Admin Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_post_admin_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_post_admin_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_post_admin_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Post Admin Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

$wp_customize->add_setting( 'cyber_security_services_pro_latest_news_comment_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_comment_color', array(
    'label' => __('Comment Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_comment_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_comment_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_comment_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Comment Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_comment_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_comment_icon_color', array(
    'label' => __('Comment Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_comment_icon_color',
  )));


  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_post_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_post_heading_color', array(
    'label' => __('Post Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_post_heading_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_post_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_post_heading_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Post Title Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_post_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_post_text_color', array(
    'label' => __('Post Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_post_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_post_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_post_text_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Post Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  // $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_box_bgcolor', array(
  //   'default' => '',
  //   'sanitize_callback' => 'sanitize_hex_color'
  // ));
  // $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_box_bgcolor', array(
  //   'label' => __('Box Background Color', 'cyber-security-services-pro'),
  //   'section' => 'cyber_security_services_pro_latest_news_color_settings',
  //   'settings' => 'cyber_security_services_pro_latest_news_box_bgcolor',
  // )));
  
  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_read_button_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_read_button_color', array(
      'label' => __('Read More Button Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_latest_news_color_settings',
      'settings' => 'cyber_security_services_pro_latest_news_read_button_color',
    )));
    $wp_customize->add_setting('cyber_security_services_pro_latest_news_read_button_font_family',array(
      'default' => '',
      'capability' => 'edit_theme_options',
      'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
    ));
    $wp_customize->add_control(
        'cyber_security_services_pro_latest_news_read_button_font_family', array(
        'section'  => 'cyber_security_services_pro_latest_news_color_settings',
        'label'    => __( 'Button Fonts','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_read_button_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_read_button_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_read_button_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_outer_btn_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_outer_btn_color', array(
    'label' => __('Blog Outer Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_outer_btn_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_latest_news_outer_btn_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_latest_news_outer_btn_font', array(
    'section'  => 'cyber_security_services_pro_latest_news_color_settings',
    'label'    => __( 'Blog Outer button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_outer_btn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_outer_btn_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_outer_btn_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_outer_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_outer_btn_text_hover_color', array(
    'label' => __('Blog Outer Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_outer_btn_text_hover_color',
  )));  

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_read_button_arrow_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_read_button_arrow_icon_color', array(
    'label' => __('Button Arrow Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_read_button_arrow_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor', array(
    'label' => __('Button Arrow Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_latest_news_color_settings',
    'settings' => 'cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor'
  )));


  // ------------OUR-VIDEO-----------------------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_our_video_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_our_video_section', array(
    'title' => __( 'Our Video Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_our_video_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_video',array(
    'title' => __('Our Video Settings','cyber-security-services-pro'),
    'description' => __('Add Our Video Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_video_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_video_enable', array(
    'label' => esc_html__( 'Show or Hide Our Video Section', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_our_video'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_our_video_enable', array(
    'selector' => '#our_video .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_our_video_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_content_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_video_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_our_video_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_video_small_head',array(
    'label' => __('Section Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video',
    'setting' => 'cyber_security_services_pro_our_video_small_head',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_our_video_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_video_main_heading',array(
    'label' => __('Section Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video',
    'setting' => 'cyber_security_services_pro_our_video_main_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_our_video_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_video_text',array(
    'label' => __('Section Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video',
    'setting' => 'cyber_security_services_pro_our_video_text',
    'type'    => 'textarea'
  ));
  
$wp_customize->add_setting('cyber_security_services_pro_our_video_nav_txt',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_video_nav_txt',array(
    'label' => __('Navigation Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video',
    'setting' => 'cyber_security_services_pro_our_video_nav_txt',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_our_video_increase',array(
    'default' => '2',
    'sanitize_callback' => 'motivational_speaker_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_our_video_increase',array(
    'label' => __('No of Video to Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video',
    'setting' => 'cyber_security_services_pro_our_video_increase',
    'type'    => 'number'
  )); 
  $video_number=get_theme_mod('cyber_security_services_pro_our_video_increase');
  for($i=1; $i<=$video_number; $i++) {

    $wp_customize->add_setting('cyber_security_services_pro_our_video_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_our_video_image'.$i, array(
      'label' => __('Video Image ','cyber-security-services-pro').$i,
      'description' => __('Dimention 600 * 600','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_our_video',
      'settings' => 'cyber_security_services_pro_our_video_image'.$i
    )));

    $wp_customize->add_setting('cyber_security_services_pro_our_video_btn_url'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_our_video_btn_url'.$i,array(
      'label' => __('Video Url','cyber-security-services-pro').$i,
      'section' => 'cyber_security_services_pro_our_video',
      'setting' => 'cyber_security_services_pro_our_video_btn_url'.$i,
      'type'  => 'url',
    ));
  }

  // Our Video COLOR SETTINGS

  $wp_customize->add_panel( $Parent_our_video_Section );

  $wp_customize->add_section('cyber_security_services_pro_our_video_color_settings',array(
    'title' => __('Our Video Color Settings','cyber-security-services-pro'),
    'description' => __('Add Our Video Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_our_video_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_video_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_our_video_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_our_video_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_our_video_heading_color_settings',array(
    'label' => __('Content Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_small_head_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_our_video_small_head_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_our_video_small_head_font_family', array(
    'section'  => 'cyber_security_services_pro_our_video_color_settings',
    'label'    => __('Small Head Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_small_head_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_main_heading_color', array(
    'label' => __('Section Main Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_main_heading_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_our_video_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_our_video_main_heading_font_family', array(
    'section'  => 'cyber_security_services_pro_our_video_color_settings',
    'label'    => __('Section Main Heading Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_text_color', array(
    'label' => __('Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_text_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_our_video_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_our_video_text_font_family', array(
    'section'  => 'cyber_security_services_pro_our_video_color_settings',
    'label'    => __('Text Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_nav_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_nav_text_color', array(
    'label' => __('Navigation Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_nav_text_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_our_video_nav_text_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_our_video_nav_text_font_family', array(
    'section'  => 'cyber_security_services_pro_our_video_color_settings',
    'label'    => __('Navigation Text Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_btn_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_btn_icon_color', array(
    'label' => __('Video Play Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_btn_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_btn_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_btn_icon_bgcolor', array(
    'label' => __('Video Play Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_btn_icon_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_nav_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_nav_icon_color', array(
    'label' => __('Navigation Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_nav_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_our_video_nav_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_our_video_nav_icon_bgcolor', array(
    'label' => __('Navigation Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_our_video_color_settings',
    'settings' => 'cyber_security_services_pro_our_video_nav_icon_bgcolor',
  ))); 

 // ------------Companies------------

$wp_customize->add_panel( $ParentPanel );

  $Parent_sponsors_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_sponsors_section', array(
    'title' => __( 'Companies Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_sponsors_Section );

  $wp_customize->add_section('cyber_security_services_pro_sponsors',array(
    'title' => __('Companies Settings','cyber-security-services-pro'),
    'description' => __('Add Companies Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_sponsors_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_sponsors_enable', array(
    'label' => esc_html__( 'Show or Hide Companies', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_sponsors'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_sponsors_enable', array(
    'selector' => '#Companies .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_sponsors_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_sponsors_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_sponsors_small_head',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_sponsors_small_head',array(
    'label' => __('Section Small Head','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors',
    'setting' => 'cyber_security_services_pro_sponsors_small_head',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_sponsors_main_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_sponsors_main_heading',array(
    'label' => __('Section Main Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors',
    'setting' => 'cyber_security_services_pro_sponsors_main_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_sponsors_increase',array(
    'default' => '8',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint'
  ));
  $wp_customize->add_control('cyber_security_services_pro_sponsors_increase',array(
    'label' => __('No Of Companies Image To Show','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors',
    'setting' => 'cyber_security_services_pro_sponsors_increase',
    'type'    => 'number'
  ));

  $Companies_number=get_theme_mod('cyber_security_services_pro_sponsors_increase');
  for($i=1; $i<=$Companies_number; $i++) {

    $wp_customize->add_setting('cyber_security_services_pro_sponsors_image'.$i,array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_sponsors_image'.$i,array(
      'label' => __('Sponsors Image ','cyber-security-services-pro').$i,
      'description' => __('Dimension 170 * 120','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_sponsors',
      'settings' => 'cyber_security_services_pro_sponsors_image'.$i
    )));
  }

// ----------Companies COLOR SETTINGS---------

  $wp_customize->add_panel( $Parent_sponsors_Section );

  $wp_customize->add_section('cyber_security_services_pro_sponsors_color_settings',array(
    'title' => __('Companies Color Settings','cyber-security-services-pro'),
    'description' => __('Add Companies Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_sponsors_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_sponsors_settings',
    array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_sponsors_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_sponsors_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_bgimage'
  )));
  

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_small_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_small_head_color', array(
    'label' => __('Small Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_small_head_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_sponsors_small_head_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_sponsors_small_head_font_family', array(
    'section'  => 'cyber_security_services_pro_sponsors_color_settings',
    'label'    => __('Small Head Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_small_head_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_small_head_bgcolor', array(
    'label' => __('Small Heading Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_small_head_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_main_heading_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_main_heading_color', array(
    'label' => __('Section Main Heading Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_main_heading_color'
  )));
  $wp_customize->add_setting('cyber_security_services_pro_sponsors_main_heading_font_family',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(
    'cyber_security_services_pro_sponsors_main_heading_font_family', array(
    'section'  => 'cyber_security_services_pro_sponsors_color_settings',
    'label'    => __('Section Main Heading Font Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
$wp_customize->add_setting( 'cyber_security_services_pro_sponsors_nav_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_nav_icon_color', array(
    'label' => __('Navigation Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_nav_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_sponsors_nav_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_sponsors_nav_icon_bgcolor', array(
    'label' => __('Navigation Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_sponsors_color_settings',
    'settings' => 'cyber_security_services_pro_sponsors_nav_icon_bgcolor',
  ))); 

   // ------------Experience------------------

  $wp_customize->add_panel( $ParentPanel );

  $Parent_experience_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_experience_section', array(
    'title' => __( 'Experience Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_experience_Section );

  $wp_customize->add_section('cyber_security_services_pro_experience',array(
    'title' => __('Experience Settings','cyber-security-services-pro'),
    'description' => __('Add Experience Content Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_experience_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_enable', array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_experience_enable', array(
    'label' => esc_html__( 'Show or Hide Experience', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_experience'
  )));

  $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_experience_enable', array(
    'selector' => '#experience .container',
    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_experience_enable',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_content_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_experience_content_settings',array(
    'label' => __('Section Content Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_experience_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('cyber_security_services_pro_experience_heading',array(
    'label' => __('Experience Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience',
    'setting' => 'cyber_security_services_pro_experience_heading',
    'type'  => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_experience_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_experience_text',array(
    'label' => __('Experience Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience',
    'setting' => 'cyber_security_services_pro_experience_text',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_experience_btn',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_experience_btn',array(
      'label' => __('Experience Button','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_experience',
      'setting' => 'cyber_security_services_pro_experience_btn',
      'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_experience_btn_url',array(
      'default' => '',
      'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('cyber_security_services_pro_experience_btn_url',array(
      'label' => __('Experience Button Url','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_experience',
      'setting' => 'cyber_security_services_pro_experience_btn_url',
      'type'  => 'url'
    ));  

  // ----------Experience COLOR SETTINGS---------

  $wp_customize->add_panel( $Parent_experience_Section );

  $wp_customize->add_section('cyber_security_services_pro_experience_color_settings',array(
    'title' => __('Experience Color Settings','cyber-security-services-pro'),
    'description' => __('Add Experience Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_experience_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_experience_settings',
    array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_bgcolor',
  )));
  
  $wp_customize->add_setting('cyber_security_services_pro_experience_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_experience_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimention 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_experience_heading_color_settings',array(
    'label' => __('Heading Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_head_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_head_color', array(
    'label' => __('Head Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_head_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_experience_head_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_experience_head_font', array(
    'section'  => 'cyber_security_services_pro_experience_color_settings',
    'label'    => __( 'Head Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));  

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_text_color', array(
    'label' => __('Experience Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_experience_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
  ));
  $wp_customize->add_control('cyber_security_services_pro_experience_text_font', array(
    'section'  => 'cyber_security_services_pro_experience_color_settings',
    'label'    => __( 'Experience Text Fonts','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_button_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_button_color', array(
    'label' => __('Button Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_button_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_experience_button_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_experience_button_font', array(
    'section'  => 'cyber_security_services_pro_experience_color_settings',
    'label'    => __( 'Button Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_button_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_button_bgcolor', array(
    'label' => __('Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_button_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_btn_hover_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_btn_hover_bgcolor', array(
    'label' => __('Button Hover Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_btn_hover_bgcolor',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_experience_btn_text_hover_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_experience_btn_text_hover_color', array(
    'label' => __('Experience Button Hover Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_experience_color_settings',
    'settings' => 'cyber_security_services_pro_experience_btn_text_hover_color',
  )));

?>