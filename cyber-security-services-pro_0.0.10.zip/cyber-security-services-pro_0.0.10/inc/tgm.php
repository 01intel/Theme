<?php

	require get_template_directory() . '/inc/class-tgm-plugin-activation.php';
/**
 * Recommended plugins.
 */
function cyber_security_services_pro_register_recommended_plugins() {
	$plugins = array(
		array(
			'name'             => __( 'Contact Form 7', 'contact-form-7' ),
			'slug'             => 'contact-form-7',
			'source'           => 'https://downloads.wordpress.org/plugin/contact-form-7.zip',
			'required'         => true,
			'force_activation' => false,
		),
	);
	$config = array();
	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'cyber_security_services_pro_register_recommended_plugins' );