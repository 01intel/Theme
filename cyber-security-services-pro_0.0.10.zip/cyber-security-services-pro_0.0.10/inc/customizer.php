<?php
/**
 * cyber-security-services-pro Theme Customizer
 *
 * @package cyber-security-services-pro
 */
/**
 * Loads custom control for layout settings
 */
function cyber_security_services_pro_custom_controls() {
    require_once get_template_directory() . '/inc/custom-controls.php';
}
add_action( 'customize_register', 'cyber_security_services_pro_custom_controls' );
/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function cyber_security_services_pro_customize_register( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

    $wp_customize->selective_refresh->add_partial( 'blogname', array(
        'selector' => '.logo a',
        'render_callback' => 'twentyfifteen_customize_partial_blogname',
    ) );
    $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
        'selector' => '.site-description',
        'render_callback' => 'twentyfifteen_customize_partial_blogdescription',
    ) );

    $wp_customize->add_setting( 'cyber_security_services_pro_display_title',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
    ));   
    $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_display_title',
        array(
        'label' => esc_html__( 'Show Title', 'cyber-security-services-pro' ),
        'section' => 'title_tagline'
    )));

    $wp_customize->add_setting( 'cyber_security_services_pro_display_tagline',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
    ));   
    $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_display_tagline',
        array(
        'label' => esc_html__( 'Show Tagline', 'cyber-security-services-pro' ),
        'section' => 'title_tagline'
    )));
    
    //add home page setting pannel
    $ParentPanel = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_panel_id', array(
        'priority' => 10,
        'capability' => 'edit_theme_options',
        'theme_supports' => '',
        'title' => __( 'Theme Settings', 'cyber-security-services-pro' ),
        'description' => __( 'Description of what this panel does.', 'cyber-security-services-pro' ),
    ) );

    $font_array = array(
        '' => __( 'No Fonts', 'cyber-security-services-pro' ),
        'Abril Fatface' => __( 'Abril Fatface', 'cyber-security-services-pro' ),
        'Acme' => __( 'Acme', 'cyber-security-services-pro' ),
        'Anton' => __( 'Anton', 'cyber-security-services-pro' ),
        'Architects Daughter' => __( 'Architects Daughter', 'cyber-security-services-pro' ),
        'Arimo' => __( 'Arimo', 'cyber-security-services-pro' ),
        'Arsenal' => __( 'Arsenal', 'cyber-security-services-pro' ),
        'Arvo' => __( 'Arvo', 'cyber-security-services-pro' ),
        'Alegreya' => __( 'Alegreya', 'cyber-security-services-pro' ),
        'Alfa Slab One' => __( 'Alfa Slab One', 'cyber-security-services-pro' ),
        'Averia Serif Libre' => __( 'Averia Serif Libre', 'cyber-security-services-pro' ),
        'Bangers' => __( 'Bangers', 'cyber-security-services-pro' ),
        'Boogaloo' => __( 'Boogaloo', 'cyber-security-services-pro' ),
        'Bad Script' => __( 'Bad Script', 'cyber-security-services-pro' ),
        'Bitter' => __( 'Bitter', 'cyber-security-services-pro' ),
        'Bree Serif' => __( 'Bree Serif', 'cyber-security-services-pro' ),
        'BenchNine' => __( 'BenchNine', 'cyber-security-services-pro' ),
        'Cabin' => __( 'Cabin', 'cyber-security-services-pro' ),
        'Cardo' => __( 'Cardo', 'cyber-security-services-pro' ),
        'Courgette' => __( 'Courgette', 'cyber-security-services-pro' ),
        'Cherry Swash' => __( 'Cherry Swash', 'cyber-security-services-pro' ),
        'Cormorant Garamond' => __( 'Cormorant Garamond', 'cyber-security-services-pro' ),
        'Crimson Text' => __( 'Crimson Text', 'cyber-security-services-pro' ),
        'Cuprum' => __( 'Cuprum', 'cyber-security-services-pro' ),
        'Cookie' => __( 'Cookie', 'cyber-security-services-pro' ),
        'Chewy' => __( 'Chewy', 'cyber-security-services-pro' ),
        'Days One' => __( 'Days One', 'cyber-security-services-pro' ),
        'Dosis' => __( 'Dosis', 'cyber-security-services-pro' ),
        'Economica' => __( 'Economica', 'cyber-security-services-pro' ),
        'Fredoka One' => __( 'Fredoka One', 'cyber-security-services-pro' ),
        'Fjalla One' => __( 'Fjalla One', 'cyber-security-services-pro' ),
        'Francois One' => __( 'Francois One', 'cyber-security-services-pro' ),
        'Frank Ruhl Libre' => __( 'Frank Ruhl Libre', 'cyber-security-services-pro' ),
        'Gloria Hallelujah' => __( 'Gloria Hallelujah', 'cyber-security-services-pro' ),
        'Great Vibes' => __( 'Great Vibes', 'cyber-security-services-pro' ),
        'Handlee' => __( 'Handlee', 'cyber-security-services-pro' ),
        'Hammersmith One' => __( 'Hammersmith One', 'cyber-security-services-pro' ),
        'Inconsolata' => __( 'Inconsolata', 'cyber-security-services-pro' ),
        'Indie Flower' => __( 'Indie Flower', 'cyber-security-services-pro' ),
        'IM Fell English SC' => __( 'IM Fell English SC', 'cyber-security-services-pro' ),
        'Julius Sans One' => __( 'Julius Sans One', 'cyber-security-services-pro' ),
        'Josefin Slab' => __( 'Josefin Slab', 'cyber-security-services-pro' ),
        'Josefin Sans' => __( 'Josefin Sans', 'cyber-security-services-pro' ),
        'Kanit' => __( 'Kanit', 'cyber-security-services-pro' ),
        'Lobster' => __( 'Lobster', 'cyber-security-services-pro' ),
        'Lato' => __( 'Lato', 'cyber-security-services-pro' ),
        'Lora' => __( 'Lora', 'cyber-security-services-pro' ),
        'Libre Baskerville' => __( 'Libre Baskerville', 'cyber-security-services-pro' ),
        'Lobster Two' => __( 'Lobster Two', 'cyber-security-services-pro' ),
        'Merriweather' => __( 'Merriweather', 'cyber-security-services-pro' ),
        'Monda' => __( 'Monda', 'cyber-security-services-pro' ),
        'Montserrat' => __( 'Montserrat', 'cyber-security-services-pro' ),
        'Muli' => __( 'Muli', 'cyber-security-services-pro' ),
        'Marck Script' => __( 'Marck Script', 'cyber-security-services-pro' ),
        'Noto Serif' => __( 'Noto Serif', 'cyber-security-services-pro' ),
        'Open Sans' => __( 'Open Sans', 'cyber-security-services-pro' ),
        'Overpass' => __( 'Overpass', 'cyber-security-services-pro' ),
        'Overpass Mono' => __( 'Overpass Mono', 'cyber-security-services-pro' ),
        'Oxygen' => __( 'Oxygen', 'cyber-security-services-pro' ),
        'Orbitron' => __( 'Orbitron', 'cyber-security-services-pro' ),
        'Patua One' => __( 'Patua One', 'cyber-security-services-pro' ),
        'Pacifico' => __( 'Pacifico', 'cyber-security-services-pro' ),
        'Padauk' => __( 'Padauk', 'cyber-security-services-pro' ),
        'Playball' => __( 'Playball', 'cyber-security-services-pro' ),
        'Playfair Display' => __( 'Playfair Display', 'cyber-security-services-pro' ),
        'PT Sans' => __( 'PT Sans', 'cyber-security-services-pro' ),
        'Philosopher' => __( 'Philosopher', 'cyber-security-services-pro' ),
        'Permanent Marker' => __( 'Permanent Marker', 'cyber-security-services-pro' ),
        'Poiret One' => __( 'Poiret One', 'cyber-security-services-pro' ),
        'Quicksand' => __( 'Quicksand', 'cyber-security-services-pro' ),
        'Quattrocento Sans' => __( 'Quattrocento Sans', 'cyber-security-services-pro' ),
        'Raleway' => __( 'Raleway', 'cyber-security-services-pro' ),
        'Rubik' => __( 'Rubik', 'cyber-security-services-pro' ),
        'Rokkitt' => __( 'Rokkitt', 'cyber-security-services-pro' ),
        'Russo One' => __( 'Russo One', 'cyber-security-services-pro' ),
        'Righteous' => __( 'Righteous', 'cyber-security-services-pro' ),
        'Slabo' => __( 'Slabo', 'cyber-security-services-pro' ),
        'Source Sans Pro' => __( 'Source Sans Pro', 'cyber-security-services-pro' ),
        'Shadows Into Light Two' => __( 'Shadows Into Light Two', 'cyber-security-services-pro'),
        'Shadows Into Light' => __( 'Shadows Into Light', 'cyber-security-services-pro' ),
        'Sacramento' => __( 'Sacramento', 'cyber-security-services-pro' ),
        'Shrikhand' => __( 'Shrikhand', 'cyber-security-services-pro' ),
        'Tangerine' => __( 'Tangerine', 'cyber-security-services-pro' ),
        'Ubuntu' => __( 'Ubuntu', 'cyber-security-services-pro' ),
        'VT323' => __( 'VT323', 'cyber-security-services-pro' ),
        'Varela Round' => __( 'Varela Round', 'cyber-security-services-pro' ),
        'Vampiro One' => __( 'Vampiro One', 'cyber-security-services-pro' ),
        'Vollkorn' => __( 'Vollkorn', 'cyber-security-services-pro' ),
        'Volkhov' => __( 'Volkhov', 'cyber-security-services-pro' ),
        'Yanone Kaffeesatz' => __( 'Yanone Kaffeesatz', 'cyber-security-services-pro' )
    );

    require_once get_template_directory() . '/inc/customizer-seperator/class/customizer-seperator.php';
    require get_template_directory() . '/inc/customize-repeater/customize-repeater.php';
    //General Settings
    require get_template_directory() . '/inc/customizer-custom-general-settings.php';    
    //Typography
    require get_template_directory() . '/inc/customizer-custom-typography.php';
    //Social Icon
    require get_template_directory() . '/inc/customizer-part-social-icons.php';
    //Header
    require get_template_directory() . '/inc/customizer-part-header.php';   
    //Home page sections
    require get_template_directory() . '/inc/customizer-part-home.php';
    //Footer
    require get_template_directory() . '/inc/customizer-part-footer.php';
    //Contact Page
    require get_template_directory() . '/inc/customizer-part-contact-page.php';

    // Has to be at the top
    $wp_customize->register_panel_type( 'cyber_security_services_pro_WP_Customize_Panel' );
    $wp_customize->register_section_type( 'cyber_security_services_pro_WP_Customize_Section' );
}
add_action( 'customize_register', 'cyber_security_services_pro_customize_register' );


if ( class_exists( 'WP_Customize_Panel' ) ) {
    class cyber_security_services_pro_WP_Customize_Panel extends WP_Customize_Panel {
        public $panel;
        public $type = 'cyber_security_services_pro_panel';
        public function json() {

          $array = wp_array_slice_assoc( (array) $this, array( 'id', 'description', 'priority', 'type', 'panel', ) );
          $array['title'] = html_entity_decode( $this->title, ENT_QUOTES, get_bloginfo( 'charset' ) );
          $array['content'] = $this->get_content();
          $array['active'] = $this->active();
          $array['instanceNumber'] = $this->instance_number;
          return $array;
        }
    }
}

if ( class_exists( 'WP_Customize_Section' ) ) {
    class cyber_security_services_pro_WP_Customize_Section extends WP_Customize_Section {
        public $section;
        public $type = 'cyber_security_services_pro_section';
        public function json() {

          $array = wp_array_slice_assoc( (array) $this, array( 'id', 'description', 'priority', 'panel', 'type', 'description_hidden', 'section', ) );
          $array['title'] = html_entity_decode( $this->title, ENT_QUOTES, get_bloginfo( 'charset' ) );
          $array['content'] = $this->get_content();
          $array['active'] = $this->active();
          $array['instanceNumber'] = $this->instance_number;

          if ( $this->panel ) {
            $array['customizeAction'] = sprintf( 'Customizing &#9656; %s', esc_html( $this->manager->get_panel( $this->panel )->title ) );
          } else {
            $array['customizeAction'] = 'Customizing';
          }
          return $array;
        }
    }
}

// Enqueue our scripts and styles
function cyber_security_services_pro_customize_controls_scripts() {
  wp_enqueue_script( 'customizer-controls', get_theme_file_uri( '/assets/js/customizer-controls.js' ), array(), '1.0', true );
}
add_action( 'customize_controls_enqueue_scripts', 'cyber_security_services_pro_customize_controls_scripts' );