<?php

    $wp_customize->add_panel( $Parent_General_Section );

    $wp_customize->add_section('cyber_security_services_pro_social_icons',array(
        'title' => __('Social Icons','cyber-security-services-pro'),
        'description'   => __('Add social Icons Here','cyber-security-services-pro'),
        'panel' => 'cyber_security_services_pro_parent_general_section',
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerfacebook',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));

    $wp_customize->add_control('cyber_security_services_pro_headerfacebook',array(
        'label' => __('Add facebook Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerfacebook',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headertwitter',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headertwitter',array(
        'label' => __('Add twitter Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headertwitter',
        'type'      => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerinstagram',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headerinstagram',array(
        'label' => __('Add Instagram Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerinstagram',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headeryoutube',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headeryoutube',array(
        'label' => __('Add Youtube Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headeryoutube',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerpinterest',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));    
    $wp_customize->add_control('cyber_security_services_pro_headerpinterest',array(
        'label' => __('Add pinterest Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerpinterest',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headergoogleplus',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));    
    $wp_customize->add_control('cyber_security_services_pro_headergoogleplus',array(
        'label' => __('Add Google+ Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headergoogleplus',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerwhatsapp',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));    
    $wp_customize->add_control('cyber_security_services_pro_headerwhatsapp',array(
        'label' => __('Add Whatsapp Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerwhatsapp',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerlinkedin',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headerlinkedin',array(
        'label' => __('Add Linkedin Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerlinkedin',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headertumblric',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headertumblric',array(
        'label' => __('Add Tumblr Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headertumblric',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headerflickr',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headerflickr',array(
        'label' => __('Add Flickr Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headerflickr',
        'type'  => 'text'
    ));

    $wp_customize->add_setting('cyber_security_services_pro_headervk',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    $wp_customize->add_control('cyber_security_services_pro_headervk',array(
        'label' => __('Add VK Link','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_social_icons',
        'setting'   => 'cyber_security_services_pro_headervk',
        'type'  => 'text'
    ));
?>