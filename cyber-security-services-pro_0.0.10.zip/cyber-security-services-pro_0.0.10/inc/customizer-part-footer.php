<?php

    // FOOTER WIDGETS SETTINGS

    $wp_customize->add_panel( $ParentPanel );

    $Parent_Footer_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_footer_section', array(
        'title' => __( 'Footer Options', 'cyber-security-services-pro' ),
        'panel' => 'cyber_security_services_pro_panel_id',
    ));

    $wp_customize->add_panel( $Parent_Footer_Section );

    $wp_customize->add_section('cyber_security_services_pro_footer_widget_section',array(
        'title' => __('Footer Widgets','cyber-security-services-pro'),
        'description'   => __('Edit footer Widgets sections','cyber-security-services-pro'),
        'panel' => 'cyber_security_services_pro_parent_footer_section',
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_widgets_enable', array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
    ));
       
    $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_footer_widgets_enable', array(
        'label' => esc_html__( 'Show or Hide Footer Widgets', 'cyber-security-services-pro' ),
        'section' => 'cyber_security_services_pro_footer_widget_section'
    )));

    $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_footer_widgets_enable', array(
        'selector' => '#footer .footer-cols',
        'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_footer_widgets_enable',
    ) );

    // FOOTER TEXT SETTINGS
    
    $wp_customize->add_panel( $Parent_Footer_Section );

    $wp_customize->add_section('cyber_security_services_pro_footer_section',array(
        'title' => __('Footer Text','cyber-security-services-pro'),
        'description'   => __('Add some text for footer like copyright etc.','cyber-security-services-pro'),
        'priority'  => null,
        'panel' => 'cyber_security_services_pro_parent_footer_section',
    ));

    $wp_customize->add_setting('cyber_security_services_pro_footer_email_form',array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_footer_email_form',array(
        'label' => __('Email Form Shortcode','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_section',
        'setting' => 'cyber_security_services_pro_footer_email_form',
        'type'  => 'text'
    ));
    

    $wp_customize->add_setting('cyber_security_services_pro_footer_copy',array(
        'default'   => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_footer_copy',array(
        'label' => __('Copyright Text','cyber-security-services-pro'),
        'section'   => 'cyber_security_services_pro_footer_section',
        'type'      => 'textarea'
    ));

    $wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_footer_copy', array(
        'selector' => '.copy-text',
        'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_footer_copy',
    ) );

    // FOOTER COLOR SETTINGS

    $wp_customize->add_panel( $Parent_Footer_Section );

    $wp_customize->add_section('cyber_security_services_pro_footer_color_settings',array(
        'title' => __('Footer Color Settings','cyber-security-services-pro'),
        'description'   => __('Edit Footer Color Settings','cyber-security-services-pro'),
        'panel' => 'cyber_security_services_pro_parent_footer_section',
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_widget_section_setting',array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_footer_widget_section_setting',
        array(
        'label' => __('Section Background Settings','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings'
    )) );

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_widget_bgcolor', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_widget_bgcolor', array(
        'label' => __('Background Color', 'cyber-security-services-pro'),
        'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_widget_bgcolor',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_footer_widget_bgimage',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_footer_widget_bgimage',array(
        'label' => __('Background image','cyber-security-services-pro'),
        'description' => __('Dimention 1600 * 600','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_widget_bgimage'
    )));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_copyright_section_setting',array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_footer_copyright_section_setting',
        array(
        'label' => __('Copyright Section Background Settings','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings'
    )) );

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_copy_bgcolor', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_copy_bgcolor', array(
        'label' => __('Copyright Background Color', 'cyber-security-services-pro'),
        'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_copy_bgcolor',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_footer_copy_bgimage',array(
        'default'   => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'cyber_security_services_pro_footer_copy_bgimage',array(
        'label' => __('Copyright Background image','cyber-security-services-pro'),
        'description' => __('Dimention 1600 * 600','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_copy_bgimage'
    )));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_content_color_setting',array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
    ));
    $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_footer_content_color_setting',
        array(
        'label' => __('Footer Content Color Settings','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings'
    )) );

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_widget_heading_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_widget_heading_color', array(
        'label' => __('Widgets Heading Color', 'cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_widget_heading_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_footer_widget_heading_font_family',array(
        'default' => '',
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cyber_security_services_pro_footer_widget_heading_font_family', array(
        'section'  => 'cyber_security_services_pro_footer_color_settings',
        'label'    => __( 'Widgets Heading Fonts Family','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_widget_content_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_widget_content_color', array(
        'label' => __('Widgets Content Color', 'cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_widget_content_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_footer_widget_content_font_family',array(
        'default' => '',
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cyber_security_services_pro_footer_widget_content_font_family', array(
        'section'  => 'cyber_security_services_pro_footer_color_settings',
        'label'    => __( 'Widgets Content Fonts Family','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_copy_content_color', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_copy_content_color', array(
        'label' => __('Copyright Color', 'cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_footer_color_settings',
        'settings' => 'cyber_security_services_pro_footer_copy_content_color',
    )));

    $wp_customize->add_setting('cyber_security_services_pro_footer_copy_content_font_family',array(
        'default' => '',
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    $wp_customize->add_control('cyber_security_services_pro_footer_copy_content_font_family', array(
        'section'  => 'cyber_security_services_pro_footer_color_settings',
        'label'    => __( 'Copyright Fonts Family','cyber-security-services-pro'),
        'type'     => 'select',
        'choices'  => $font_array,
    ));  

    $wp_customize->add_setting( 'cyber_security_services_pro_footer_social_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_social_icon_color', array(
    'label' => __('Social Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_footer_color_settings',
    'settings' => 'cyber_security_services_pro_footer_social_icon_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_footer_social_icon_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_footer_social_icon_bgcolor', array(
    'label' => __('Social Icon Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_footer_color_settings',
    'settings' => 'cyber_security_services_pro_footer_social_icon_bgcolor'
  )));
?>