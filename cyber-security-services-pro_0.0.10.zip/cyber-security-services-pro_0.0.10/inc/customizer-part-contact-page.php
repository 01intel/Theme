<?php
$wp_customize->add_panel( $ParentPanel );

  $Parent_Contact_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_contact_section', array(
    'title' => __( 'Contact Page & Map Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_Contact_Section );

  $wp_customize->add_section('cyber_security_services_pro_contact',array(
    'title' => __('Contact Page & Map Settings','cyber-security-services-pro'),
    'description' => __('Add Contact Info Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_contact_section',
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_longitude',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_longitude',array(
    'label' => __('Add Map Longitude','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_longitude',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_latitude',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_latitude',array(
    'label' => __('Add Map Latitude','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_latitude',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_heading',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_heading',array(
    'label' => __('Contact Heading','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_heading',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_text',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_text',array(
    'label' => __('Contact Text','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_text',
    'type'    => 'textarea'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_phone_icon',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_phone_icon',array(
    'label' => __('Phone Icon','cyber-security-services-pro'),
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_phone_icon',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_call1',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_call1',array(
    'label' => __('Phone Number1','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_call1',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_call2',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_call2',array(
    'label' => __('Phone Number2','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_call2',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_email',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_email',array(
    'label' => __('Email Id','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_email',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_email_icon',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_email_icon',array(
    'label' => __('Email Icon','cyber-security-services-pro'),
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_email_icon',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_address',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_address',array(
    'label' => __('Address','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_address',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contact_address_icon',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_address_icon',array(
    'label' => __('Address Icon','cyber-security-services-pro'),
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact',
    'setting' => 'cyber_security_services_pro_contact_address_icon',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_contactpage_contact_form',array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cyber_security_services_pro_contactpage_contact_form',array(
        'label' => __('Contact Form Shortcode','cyber-security-services-pro'),
        'section' => 'cyber_security_services_pro_contact',
        'setting' => 'cyber_security_services_pro_contactpage_contact_form',
        'type'  => 'text'
    ));
 

  // CONTACT & MAP COLOR SETTINGS

  $wp_customize->add_panel( $Parent_Contact_Section );

  $wp_customize->add_section('cyber_security_services_pro_contact_color_settings',array(
    'title' => __('Contact Page & Map Color Settings','cyber-security-services-pro'),
    'description' => __('Add Contact Info Color Settings Here','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_contact_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_contact_settings',array(
    'label' => __('Section Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_contactpage_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contactpage_bgcolor', array(
    'label' => __('Section Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contactpage_bgcolor',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_contactpage_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_contactpage_bgimage',array(
    'label' => __('Section Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contactpage_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_heading_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_contact_heading_color_settings',array(
    'label' => __('Heading Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contact_title_color', array(
    'label' => __('Title Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contact_title_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_contact_title_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_title_font', array(
    'section'  => 'cyber_security_services_pro_contact_color_settings',
    'label'    => __( 'Title Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contact_text_color', array(
    'label' => __('Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contact_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_contact_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_text_font', array(
    'section'  => 'cyber_security_services_pro_contact_color_settings',
    'label'    => __( 'Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_border_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contact_border_color', array(
    'label' => __('Border Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contact_border_color',
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_box_color_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_contact_box_color_settings',array(
    'label' => __('Contact Info Color Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_info_title_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contact_info_title_color', array(
    'label' => __('Inner Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contact_info_title_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_contact_info_title_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_contact_info_title_font', array(
    'section'  => 'cyber_security_services_pro_contact_color_settings',
    'label'    => __( 'Inner Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_contact_info_icon_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_contact_info_icon_color', array(
    'label' => __('Contact page Icon Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_contact_color_settings',
    'settings' => 'cyber_security_services_pro_contact_info_icon_color',
  )));




?>