<?php //to use wp udpate plugin
wp_enqueue_script( 'updates' ); ?>

<div class="theme-offer">
	<?php
      require_once trailingslashit( __DIR__ ) . 'class-ot-widget-importer.php';
      $OT_cyber_security_WIE_FILE = trailingslashit( THEME_DIR ) . 'inc/widget/ot-cyber-security-widgets.wie';
      // var_dump($OT_cyber_security_WIE_FILE);
      if(isset($_GET['import-demo'])){
        $home_id=''; $blog_id=''; $page_id=''; $contact_id=''; $casestudy_id=''; $services_id='';$shop_id=''; $typography_id=''; $about_id=''; $pricing_id='';$case_id='';$privacy_id='';$secure_id='';$backup_id='';$website_id='';$cyber_id='';$network_id='';$collaborate_id='';

        $home_content = '';
        $home_title = 'Home';
    		$home_check = get_page_by_title($home_title);
   	   	$home = array(
    		  'post_type' => 'page',
    		  'post_title' => $home_title,
          'post_content'  => $home_content,
    		  'post_status' => 'publish',
    		  'post_author' => 1,
    		  'post_slug' => 'home'
   		  );
        $home_id = wp_insert_post($home);
         
        //Set the home page template
        add_post_meta( $home_id, '_wp_page_template', 'page-template/home-page.php' );

        //Set the static front page
        $home = get_page_by_title( 'Home' );
        update_option( 'page_on_front', $home->ID );
        update_option( 'show_on_front', 'page' );

        // Create a blog page and assigned the template

          $blog_title = 'Blog';
          $blog_check = get_page_by_title($blog_title);
          $blog = array(
            'post_type'   => 'page',
            'post_title'  => $blog_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'blog'
          );
          $blog_id = wp_insert_post($blog);

          //Set the blog page template
          add_post_meta( $blog_id, '_wp_page_template', 'page-template/blog-fullwidth-extend.php' );

          $blog_title = 'Blog Left Sidebar';
          $blog = array(
            'post_type'   => 'page',
            'post_title'  => $blog_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'blog-left-sidebar'
          );
          $blog_id = wp_insert_post($blog);


          //Set the blog page template
          add_post_meta( $blog_id, '_wp_page_template', 'page-template/blog-with-left-sidebar.php' );

          $blog_title = 'Blog Right Sidebar';
          $blog = array(
            'post_type'   => 'page',
            'post_title'  => $blog_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'blog-right-sidebar'
          );
          $blog_id = wp_insert_post($blog);


          //Set the blog page template
          add_post_meta( $blog_id, '_wp_page_template', 'page-template/blog-with-right-sidebar.php' );

          // Create a Page
          if( get_page_by_title( 'Page' ) == NULL ) {
            $page_title = 'Page';
            $content = 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semelTe obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel';

            $page_check = get_page_by_title($page_title);
            $ot_page = array(
              'post_type'     => 'page',
              'post_title'    => $page_title,
              'post_content'  => $content,
              'post_status'   => 'publish',
              'post_author'   => 1,
              'post_slug'     => 'page'
            );
            $page_id = wp_insert_post($ot_page);
            
            $page_title = 'Page Left Sidebar';
            $content = 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semelTe obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel.Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel.';

            $page_check = get_page_by_title($page_title);
            $ot_page = array(
              'post_type' => 'page',
              'post_title' => $page_title,
              'post_content'  => $content,
              'post_status'   => 'publish',
              'post_author'   => 1,
              'post_slug'     => 'page-left'
            );
            $page_id = wp_insert_post($ot_page);

            //Set the page template
            add_post_meta( $page_id, '_wp_page_template', 'page-template/page-with-left-sidebar.php' );

            $page_title = 'Page Right Sidebar';
            $content = 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semelTe obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel.Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel.';

            $page_check = get_page_by_title($page_title);
            $ot_page = array(
              'post_type'     => 'page',
              'post_title'    => $page_title,
              'post_content'  => $content,
              'post_status'   => 'publish',
              'post_author'   => 1,
              'post_slug'     => 'page-right'
            );
            $page_id = wp_insert_post($ot_page);

            //Set the page template
            add_post_meta( $page_id, '_wp_page_template', 'page-template/page-with-right-sidebar.php' );
          }

          // Create a contact page and assigned the template
          $contact_title = 'CONTACT';
          $contact_check = get_page_by_title($contact_title);
          $contact = array(
            'post_type'   => 'page',
            'post_title'  => $contact_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'contact'
          );
          $contact_id = wp_insert_post($contact);

          //Set the contact template
          add_post_meta( $contact_id, '_wp_page_template', 'page-template/contact-page-template.php' );
          

          // Create a case-studies page and assigned the template
          $casestudy_title = 'Case Studies';
          $casestudy = array(
            'post_type' => 'page',
            'post_title' => $casestudy_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'case-studies'
          );
          $casestudy_id = wp_insert_post($casestudy);

          //Set the schedule Us template
          add_post_meta( $casestudy_id, '_wp_page_template', 'page-template/case-studies-template.php' );

          // Create a Shop page and assigned the template
          $shop_title = 'SHOP';
          $shop = array(
            'post_type' => 'page',
            'post_title' => $shop_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'shop'
          );
          $shop_id = wp_insert_post($shop);

          //Set the shop template
          add_post_meta( $shop_id, '_wp_page_template', 'page-template/shop-template.php' );

          // Create a Typography page and assigned the template
          $typography_title = 'Typography';
          $typography = array(
            'post_type'   => 'page',
            'post_title'  => $typography_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'typography'
          );
          $typography_id = wp_insert_post($typography);

          //Set the typography template
          add_post_meta( $typography_id, '_wp_page_template', 'page-template/typography-template.php' );

          // Create a Services page and assigned the template
          $services_title = 'SERVICES';
          $services = array(
            'post_type'   => 'page',
            'post_title'  => $services_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug'   => 'services'
          );
          $services_id = wp_insert_post($services);

          //Set the services template
          add_post_meta( $services_id, '_wp_page_template', 'page-template/services-template.php' );       
         
        
      // SECTION ORDERING

        set_theme_mod( 'cyber_security_services_pro_section_ordering_settings_repeater','slider,about,achievement,our-services,choose-us,pricing-plans,our-experts,testimonials,latest-news,our-video,sponsors,experience');

      // --------TOPBAR------------------------

    set_theme_mod( 'cyber_security_services_pro_the_custom_logo', get_template_directory_uri().'/assets/images/cyberlogo.png');

    set_theme_mod( 'cyber_security_services_pro_header_search_icon', 'fas fa-search' ); 

    set_theme_mod( 'cyber_security_services_pro_headerfacebook', 'https://www.facebook.com/' );
    set_theme_mod( 'cyber_security_services_pro_headertwitter', 'https://twitter.com/' );
    set_theme_mod( 'cyber_security_services_pro_headergoogleplus', 'https://plus.google.com/' );
    
    set_theme_mod( 'cyber_security_services_pro_headerwhatsapp', 'https://www.whatsapp.com/' );

   //-------------- SLIDER-----------------------

    set_theme_mod( 'cyber_security_services_pro_slide_delay', '5000' );

    set_theme_mod( 'cyber_security_services_pro_slide_number', 3 );
          for($i=1;$i<=3;$i++)
           {
      set_theme_mod( 'cyber_security_services_pro_slide_image'.$i, get_template_directory_uri().'/assets/images/slides/slider'.$i.'.png' );

      set_theme_mod( 'cyber_security_services_pro_slide_small_heading'.$i, 'SECURE AND GUARANTEED' );

      set_theme_mod( 'cyber_security_services_pro_slide_heading'.$i, 'We Provide The Best Cyber Security' );

      set_theme_mod( 'cyber_security_services_pro_slide_text'.$i, 'Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. ' );
      set_theme_mod( 'cyber_security_services_pro_slide_quote_btn'.$i, 'Get A Free Quote' );
      set_theme_mod( 'cyber_security_services_pro_slide_quote_btn_url'.$i, "#" );
      set_theme_mod( 'cyber_security_services_pro_slide_start_btn'.$i, 'Get Start Now' );
      set_theme_mod( 'cyber_security_services_pro_slide_start_btn_url'.$i, '#' );
      
          }

// ----------------About Us---------------------

  set_theme_mod( 'cyber_security_services_pro_about_image1', get_template_directory_uri().'/assets/images/about/about-img1.png' );

   set_theme_mod( 'cyber_security_services_pro_about_image2', get_template_directory_uri().'/assets/images/about/about-img2.png' );

   set_theme_mod( 'cyber_security_services_pro_about_image3', get_template_directory_uri().'/assets/images/about/about-img3.png' );

  set_theme_mod( 'cyber_security_services_pro_about_heading', 'We help you run your business securely and successfully' ); 

  set_theme_mod( 'cyber_security_services_pro_about_small_heading', 'ABOUT US' );
           
  set_theme_mod( 'cyber_security_services_pro_about_text', 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.' );       

      set_theme_mod( 'cyber_security_services_pro_about_btn', 'Get The Service' );
      set_theme_mod( 'cyber_security_services_pro_about_btn_url', '#' );
      

// ------------------ACHIEVEMENT-------------

  set_theme_mod( 'cyber_security_services_pro_achievement_bg_img', get_template_directory_uri().'/assets/images/achieve/achieve-bg.png' );

  set_theme_mod( 'cyber_security_services_pro_achievement_head', '35+' );

  set_theme_mod( 'cyber_security_services_pro_achievement_text', 'Year of experience in cyber security' );

  $achieve_num=array('4K','234+','99%','4K','234+','99%');

  $inner_head=array('Cyber Security Project','Cyber Security Experts','Client Retention Rate','Cyber Security Project','Cyber Security Experts','Client Retention Rate');  

  set_theme_mod( 'cyber_security_services_pro_achievement_increase', 6 );
    for($i=1;$i<=6;$i++)
    {

  set_theme_mod( 'cyber_security_services_pro_achievement_count'.$i, $achieve_num[$i-1] ); 

  set_theme_mod( 'cyber_security_services_pro_achievement_inner_head'.$i, $inner_head[$i-1] );
  
        }


      // -----------------Services------------------

  set_theme_mod( 'cyber_security_services_pro_our_services_small_head', "OUR SERVICES" );

  set_theme_mod( 'cyber_security_services_pro_our_services_heading', 'Custom Services For Your Business' );
  

    set_theme_mod( 'cyber_security_services_pro_services_post_number', 6);

    $event_title=array('Cloud Storage Security','Data Protection','Cyber Security','Hacking Protection','Website Protection','Identifying Threats');

    for($i=1;$i<=6;$i++){
      
      $ot_title =$event_title[$i-1];
      $content = 'Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et and the part of new memory dolore magna.';
      // Create post object
      $my_post = array(
         'post_title'    => wp_strip_all_tags( $ot_title ),
         'post_content'  => $content,
         'post_status'   => 'publish',
         'post_type'     => 'service',   
      );

      // Insert the post into the database
      $ot_post_id = wp_insert_post( $my_post );

      // update_post_meta( $ot_post_id,'cyber_security_services_pro_services_display_name',$event_title[$i-1]);

       $image_url = get_template_directory_uri().'/assets/images/service/service'.$i.'.png';
      $image_name= 'service'.$i.'.png';
      $upload_dir       = wp_upload_dir(); 
      // Set upload folder
      $image_data       = file_get_contents($image_url); 
      // Get image data
      $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); 
      // Generate unique name
      $filename= basename( $unique_file_name ); 
      // Create image file name
      // Check folder permission and define file location
      if( wp_mkdir_p( $upload_dir['path'] ) ) {
         $file = $upload_dir['path'] . '/' . $filename;
      } else {
         $file = $upload_dir['basedir'] . '/' . $filename;
      }
      // Create the image  file on the server
      file_put_contents( $file, $image_data );
      // Check image file type
      $wp_filetype = wp_check_filetype( $filename, null );
      // Set attachment data
      $attachment = array(
       'post_mime_type' => $wp_filetype['type'],
       'post_title'     => sanitize_file_name( $filename ),
       'post_content'   => '',
       'post_type'     => 'service',
       'post_status'    => 'inherit'
      );

      // Create the attachment
      $attach_id = wp_insert_attachment( $attachment, $file, $ot_post_id );
      // Include image.php
      require_once(ABSPATH . 'wp-admin/includes/image.php');
      // Define attachment metadata
      $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
      // Assign metadata to attachment
       wp_update_attachment_metadata( $attach_id, $attach_data );
      // And finally assign featured image to post
      set_post_thumbnail( $ot_post_id, $attach_id );

    }
    
    set_theme_mod( 'cyber_security_services_pro_services_outer_btn_url', '#' );

    set_theme_mod( 'cyber_security_services_pro_services_outer_btn', 'View All Services' );

// ---------------- choose-us ----------------

      
    set_theme_mod( 'cyber_security_services_pro_choose_us_small_head', 'WHY CHOOSE US' );

    set_theme_mod( 'cyber_security_services_pro_choose_us_main_heading', 'We are your trusted partner in Cyber security and IT sector' );

    set_theme_mod( 'cyber_security_services_pro_choose_us_text', 'Duis aute irure dolor in reprehenderit in voluptate velse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cuptat non proident, sunt in culpa qui fficia deserunt mollit anim id est laborum perspiciatis unde omnis iste natus error sit voluptatem accusantium.' );

    set_theme_mod( 'cyber_security_services_pro_choose_us_increase', '4' );
        $about_title=array('Duis aute irure dolor in reprehenderit.','In voluptate velit esse cillum.','Dolore eu fugiat nulla and pariatur.','Excepteur sint occaecat cupidatat non proident.');
        for($i=1; $i<=4; $i++) {          
          set_theme_mod( 'cyber_security_services_pro_choose_us_inner_list'.$i, $about_title[$i-1] ); 
          set_theme_mod( 'cyber_security_services_pro_choose_us_tick_icon'.$i, 'fa-regular fa-circle-check' );
        }
          set_theme_mod( 'cyber_security_services_pro_choose_us_btn', 'Get The Service' );
          set_theme_mod( 'cyber_security_services_pro_choose_us_btn_url', '#' );


    set_theme_mod( 'cyber_security_services_pro_choose_us_image', get_template_directory_uri().'/assets/images/choose-us/choose-img.png' );

    set_theme_mod( 'cyber_security_services_pro_choose_us_right_head', 'Our Security Operations' );

    set_theme_mod( 'cyber_security_services_pro_choose_us_increase2', '6' );
        $choose_title=array('Cyber Security','Risk Assessment','Network Security','Server Monitoring','Email Protection','Backup & Recovery');
        for($i=1; $i<=6; $i++) {          
          set_theme_mod( 'cyber_security_services_pro_choose_us_right_list'.$i, $choose_title[$i-1] ); 
        }

         // -------------Pricing-Plans-----------------

        set_theme_mod( 'cyber_security_services_pro_pricing_plan_small_heading', 'PRICING' );
        set_theme_mod( 'cyber_security_services_pro_pricing_plan_main_heading', 'Our Affordable Pricing Plans' );       
        
        set_theme_mod( 'cyber_security_services_pro_pricing_plan_increase', '3' );

        $plan_price_year=array('$40','$90','$100'); 

        $plan_price=array('$19','$69','$89');
        
        $plan_pack=array('Beginner','Popular','Enterprise');
          
          
        for($i=1;$i<=3;$i++) 
           {

            set_theme_mod( 'cyber_security_services_pro_pricing_plan_button_title'.$i, 'Buy Plan' );
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_button_url'.$i, '#' );   
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_price'.$i, $plan_price[$i-1] );
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_permonth'.$i, '/Month' );

            set_theme_mod( 'cyber_security_services_pro_pricing_plan_price_year'.$i, $plan_price_year[$i-1] );
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_peryear'.$i, '/Year' );

            set_theme_mod( 'cyber_security_services_pro_pricing_plan_inn_text'.$i, 'Consectetur adipiscing elit, sed do eiuod tempor incididunt ut laboreet.' );

            set_theme_mod( 'cyber_security_services_pro_pricing_plan_pack_option'.$i, $plan_pack[$i-1] );

            set_theme_mod( 'cyber_security_services_pro_pricing_plan_features_no'.$i, 6 );

            $plan_features=array('1 seat','1 active project','Limited blocks','Conditions','CSV export','Password protection');

            for($j=1;$j<=6;$j++)
            {
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_features'.$i.$j, $plan_features[$j-1] );
            set_theme_mod( 'cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j,'fa-solid fa-check' );
            }
            }     

  // ----------OUR-Experts----------------------
    
    set_theme_mod( 'cyber_security_services_pro_our_experts_small_head', 'OUR EXPERTS' );

    set_theme_mod( 'cyber_security_services_pro_our_experts_heading', 'Our Special Team To Protect Your Cyber Security' );

    set_theme_mod( 'cyber_security_services_pro_our_experts_post_number', 6);


  for($i=1;$i<=6;$i++){
    
  $ot_title = 'James Watson';
  $content = 'Security Analytics';
    // Create post object
    $my_post = array(
       'post_title'    => wp_strip_all_tags( $ot_title ),
       'post_content'  => $content,
       'post_status'   => 'publish',
       'post_type'     => 'our_experts',   
    );

    // Insert the post into the database
    $ot_post_id = wp_insert_post( $my_post );
    
    // update_post_meta( $ot_post_id,'literacy-custom-field2','FREE');
    update_post_meta( $ot_post_id,'cyber_security_services_pro_our_experts_social_facebook','https://www.facebook.com/');

    update_post_meta( $ot_post_id,'cyber_security_services_pro_our_experts_social_twitter','https://in.twitter.com/');

    update_post_meta( $ot_post_id,'cyber_security_services_pro_our_experts_social_googleplus','https://plus.google.com/');

    update_post_meta( $ot_post_id,'cyber_security_services_pro_our_experts_social_whatsapp','https://www.whatsapp.com/');

    // update_post_meta( $ot_post_id,'cyber_security_services_pro_literacy_time', '02 hours');

     $image_url = get_template_directory_uri().'/assets/images/team/team'.$i.'.png';
    $image_name= 'team'.$i.'.png';
    $upload_dir       = wp_upload_dir(); 
    // Set upload folder
    $image_data       = file_get_contents($image_url); 
    // Get image data
    $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); 
    // Generate unique name
    $filename= basename( $unique_file_name ); 
    // Create image file name
    // Check folder permission and define file location
    if( wp_mkdir_p( $upload_dir['path'] ) ) {
       $file = $upload_dir['path'] . '/' . $filename;
    } else {
       $file = $upload_dir['basedir'] . '/' . $filename;
    }
    // Create the image  file on the server
    file_put_contents( $file, $image_data );
    // Check image file type
    $wp_filetype = wp_check_filetype( $filename, null );
    // Set attachment data
    $attachment = array(
     'post_mime_type' => $wp_filetype['type'],
     'post_title'     => sanitize_file_name( $filename ),
     'post_content'   => '',
     'post_type'     => 'our_experts',
     'post_status'    => 'inherit'
    );

    // Create the attachment
    $attach_id = wp_insert_attachment( $attachment, $file, $ot_post_id );
    // Include image.php
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    // Define attachment metadata
    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    // Assign metadata to attachment
     wp_update_attachment_metadata( $attach_id, $attach_data );
    // And finally assign featured image to post
    set_post_thumbnail( $ot_post_id, $attach_id );
    }  
 
    set_theme_mod( 'cyber_security_services_pro_our_experts_outer_btn_url', '#' );
    set_theme_mod( 'cyber_security_services_pro_our_experts_outer_btn', 'View All Teams' );

     // -------------- Testimonial ---------------

    set_theme_mod( 'cyber_security_services_pro_testimonials_small_head', 'TESTIMONIALS'  );

    set_theme_mod( 'cyber_security_services_pro_testimonials_heading', 'Clients From 100+ Countries Say About Us' );
    
      
    set_theme_mod( 'cyber_security_services_pro_testimonials_increase', '6' );

        $testi_title=array('Andrea Carolyn','Jonathan Buckland','Andrea Carolyn','Jonathan Buckland','Andrea Carolyn','Jonathan Buckland');

        for($i=1; $i<=6; $i++) {

          set_theme_mod( 'cyber_security_services_pro_testimonials_image'.$i, get_template_directory_uri().'/assets/images/testimonials/testi'.$i.'.png' );
          set_theme_mod( 'cyber_security_services_pro_testimonials_member_name'.$i, $testi_title[$i-1] );
          set_theme_mod( 'cyber_security_services_pro_testimonials_member_designation'.$i, 'UI Desinger' );
          set_theme_mod( 'cyber_security_services_pro_testi_quote_icon'.$i, 'fa-solid fa-quote-right' );
          
          set_theme_mod( 'cyber_security_services_pro_testimonials_client_text'.$i, 'Enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim.' );
          }

    //--------- LATEST NEWS------------

        set_theme_mod( 'cyber_security_services_pro_latest_news_small_head', 'OUR BLOG' );

        set_theme_mod( 'cyber_security_services_pro_latest_news_heading', 'Latest From The News' );      

        set_theme_mod( 'cyber_security_services_pro_latest_news_increase', '4' );

        $latest_category = wp_create_category('latest-news');
        set_theme_mod( 'cyber_security_services_pro_latest_news_category', 'latest-news' ); 
        $blog_title=array('Web development the best work in the future for the world','Web development the best work in the future for the world','Web development the best work in the future for the world','Web development the best work in the future for the world');

        for($i=1;$i<=4;$i++) {
            
          $title = $blog_title[$i-1];   
          $content = 'Duis aute irure dolor in reprehenderit in voluptate velse cillum dolore eu fugiat nulla pariatxcepteur sint occaecat cuptat non proident.';

          // Create post object
          $my_post = array(
           'post_title'    => wp_strip_all_tags( $title ),
           'post_content'  => $content,
           'post_status'   => 'publish',
           'post_type'     => 'post',
           'post_category' => array($latest_category) 
          );

          // Insert the post into the database
          $post_id = wp_insert_post( $my_post );

          $image_url = get_template_directory_uri().'/assets/images/blogs/blog'.$i.'.png';

          $image_name= 'blog'.$i.'.png';
          $upload_dir       = wp_upload_dir(); 
          // Set upload folder
          $image_data       = file_get_contents($image_url); 
          // Get image data
          $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); 
          // Generate unique name
          $filename= basename( $unique_file_name ); 
          // Create image file name
          // Check folder permission and define file location
          if( wp_mkdir_p( $upload_dir['path'] ) ) {
             $file = $upload_dir['path'] . '/' . $filename;
          } else {
             $file = $upload_dir['basedir'] . '/' . $filename;
          }
          // Create the image  file on the server
          file_put_contents( $file, $image_data );
          // Check image file type
          $wp_filetype = wp_check_filetype( $filename, null );
          // Set attachment data
          $attachment = array(
           'post_mime_type' => $wp_filetype['type'],
           'post_title'     => sanitize_file_name( $filename ),
           'post_content'   => '',
           'post_type'     => 'post',
           'post_status'    => 'inherit'
          );

          // Create the attachment
          $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
          // Include image.php
          require_once(ABSPATH . 'wp-admin/includes/image.php');
          // Define attachment metadata
          $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
          // Assign metadata to attachment
           wp_update_attachment_metadata( $attach_id, $attach_data );
          // And finally assign featured image to post
          set_post_thumbnail( $post_id, $attach_id );

        }

    set_theme_mod( 'cyber_security_services_pro_latest_news_outer_btn_url', '#' );

    set_theme_mod( 'cyber_security_services_pro_latest_news_outer_btn', 'View All Blogs' );
    
    // -------------OUR-VIDEO-----------------

    set_theme_mod( 'cyber_security_services_pro_our_video_small_head', 'HOW IT WORKS' );

    set_theme_mod( 'cyber_security_services_pro_our_video_main_heading', 'A simple guide to getting start' );

    set_theme_mod( 'cyber_security_services_pro_our_video_text', 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliquauis ipsum suspen edisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisisLorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod.' );

    set_theme_mod( 'cyber_security_services_pro_our_video_nav_txt', 'See More Videos' );


    set_theme_mod( 'cyber_security_services_pro_our_video_increase', '2' );

        $video_url=array('https://www.youtube.com/watch?v=Q2W_nNdReXM','https://www.youtube.com/watch?v=H759qpwMC8s');


      for($i=1; $i<=2; $i++) {

      set_theme_mod( 'cyber_security_services_pro_our_video_image'.$i, get_template_directory_uri().'/assets/images/video/video'.$i.'.png' );

      set_theme_mod( 'cyber_security_services_pro_our_video_btn_url'.$i, $video_url[$i-1] );      

      }

//-----------COMPANIES---------------------

    set_theme_mod( 'cyber_security_services_pro_sponsors_small_head', 'SPONSORS' );

    set_theme_mod( 'cyber_security_services_pro_sponsors_main_heading', 'Trusted by 3,225+ world-class brands & organizations' );
    
    set_theme_mod( 'cyber_security_services_pro_sponsors_increase', '8' ); 

    for($i=1; $i<=8; $i++) {
      set_theme_mod( 'cyber_security_services_pro_sponsors_image'.$i, get_template_directory_uri().'/assets/images/company/sponser'.$i.'.png' );
    } 

   // -------------Experience-------------------------- 

   set_theme_mod( 'cyber_security_services_pro_experience_heading', 'Are You Ready for the Best Cyber Security Experience?' );

   set_theme_mod( 'cyber_security_services_pro_experience_text', 'We’re confident you’ll be 100% satisfied With Our Awesome Services!' );

    set_theme_mod( 'cyber_security_services_pro_experience_btn_url', '#' );
    
    set_theme_mod( 'cyber_security_services_pro_experience_btn', 'Get Started' );

       
        // CONTACT & MAP
        
        set_theme_mod( 'cyber_security_services_pro_contact_longitude', '37.0902° N' );
        set_theme_mod( 'cyber_security_services_pro_contact_latitude', '95.7129° W' );

        set_theme_mod( 'cyber_security_services_pro_contact_heading', 'Contact Us' );
        set_theme_mod( 'cyber_security_services_pro_contact_text', "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis erat metus, posuere eget pulvinar gravida, pulvinar vitae velit. Quisque vel" );

        set_theme_mod( 'cyber_security_services_pro_contact_phone_icon', 'fas fa-phone' );
        set_theme_mod( 'cyber_security_services_pro_contact_call1', '(+91) 1800-1234-1234' );

        set_theme_mod( 'cyber_security_services_pro_contact_call2', '(+91) 1800-1234-1234' );

        set_theme_mod( 'cyber_security_services_pro_contact_email', 'spa&beauty@demomail.com' );

        set_theme_mod( 'cyber_security_services_pro_contact_email_icon', 'fas fa-envelope' );

        set_theme_mod( 'cyber_security_services_pro_contact_address', '7750 East Nicholesds Street Waxhaw, St. Arlington' );

        set_theme_mod( 'cyber_security_services_pro_contact_address_icon', 'fas fa-map-marker-alt' );        
          
          // contact form shortcode
    $cf7title = "contact Form";
    $cf7content = '<div class="row form-info">
                    <div class="col-lg-6 col-md-6 col-12">
                      [text YourName class:contactp-name placeholder "Your Name"]
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                      [email youremail class:contactp-email placeholder "Your Email"]
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                      [tel yourcall class:contactp-call placeholder "Phone No"]
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                      [date* contact-date class:contact-date placeholder "Date"]
                    </div>
                    <div class="col-lg-12 col-md-12 col-12">
                      [textarea yourmsg class:contactp-msg placeholder "Message"]
                    </div>
                    <div class="col-lg-12 col-md-12 col-12 form-btn">
                      [submit class:contactp-sumbit "Contact Us"]
                    </div>
                  </div>
    [_site_title] "[your-subject]"
    [_site_title] <vowelweb79@gmail.com>
    From: [your-name] <[your-email]>
    Subject: [your-subject]

    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [_site_admin_email]
    Reply-To: [your-email]

    0
    0

    [_site_title] "[your-subject]"
    [_site_title] <vowelweb79@gmail.com>
    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [your-email]
    Reply-To: [_site_admin_email]

    0
    0
    Thank you for your message. It has been sent.
    There was an error trying to send your message. Please try again later.
    One or more fields have an error. Please check and try again.
    There was an error trying to send your message. Please try again later.
    You must accept the terms and conditions before sending your message.
    The field is required.
    The field is too long.
    The field is too short.
    There was an unknown error uploading the file.
    You are not allowed to upload files of this type.
    The file is too big.
    There was an error uploading the file.';

    $cf7_post = array(
      'post_title'    => wp_strip_all_tags( $cf7title ),
      'post_content'  => $cf7content,
      'post_status'   => 'publish',
      'post_type'     => 'wpcf7_contact_form',
    );
    // Insert the post into the database
    $cf7post_id = wp_insert_post( $cf7_post );

    add_post_meta(
      $cf7post_id,
      "_form",
      '<div class="row form-info">
        <div class="col-lg-6 col-md-6 col-12">
          [text YourName class:contactp-name placeholder "Your Name"]
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          [email youremail class:contactp-email placeholder "Your Email"]
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          [tel yourcall class:contactp-call placeholder "Phone No"]
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          [date* contact-date class:contact-date placeholder "Date"]
        </div>
        <div class="col-lg-12 col-md-12 col-12">
          [textarea yourmsg class:contactp-msg placeholder "Message"]
        </div>
        <div class="col-lg-12 col-md-12 col-12 form-btn">
          [submit class:contactp-sumbit "Contact Us"]
        </div>
      </div>'
    );

    $cf7mail_data  = array(
      'subject' => '[_site_title] "[your-subject]"',
      'sender'  => '[_site_title] <vowelweb79@gmail.com>',
      'body'    => 'From: [your-name] <[your-email]>
      Subject: [your-subject]

      Message Body:
      [your-message]

      --
      This e-mail was sent from a contact form on [_site_title] ([_site_url])',
      'recipient'           => '[_site_admin_email]',
      'additional_headers'  => 'Reply-To: [your-email]',
      'attachments'         => '',
      'use_html'            => 0,
      'exclude_blank'       => 0
    );

    add_post_meta($cf7post_id, "_mail", $cf7mail_data);
    // Gets term object from Tree in the database.

    $cf7shortcode = '[contact-form-7 id="'.$cf7post_id.'" title="'.$cf7title.'"]';

    set_theme_mod( 'cyber_security_services_pro_contactpage_contact_form',$cf7shortcode );

    // print_r($cf7shortcode);
    // exit;


// ------------footer------------
  set_theme_mod( 'cyber_security_services_pro_footer_logo', get_template_directory_uri().'/assets/images/footer/footerlogo.png' );

  set_theme_mod( 'cyber_security_services_pro_footer_social_facebook', 'https://www.facebook.com/' );    
    set_theme_mod( 'cyber_security_services_pro_footer_social_twitter', 'https://www.twitter.com/' );
    set_theme_mod( 'cyber_security_services_pro_footer_social_googleplus', 'https://plus.google.com/' );    
    set_theme_mod( 'cyber_security_services_pro_footer_social_whatsapp', 'https://www.whatsapp.com/' );

  // Footer mail form shortcode
    $cf7title = "footer Form";
    $cf7content = '<div class="row ft-form">
                    <div class="col-lg-9 col-md-9 col-12">
                      [email footer-email class:ft-email placeholder "Email here..."]
                    </div>
                    <div class="col-lg-3 col-md-3 col-12">
                      [submit class:ft-btn btn "Submit"]
                    </div>
                  </div>

    [_site_title] "[your-subject]"
    [_site_title] <vowelweb79@gmail.com>
    From: [your-name] <[your-email]>
    Subject: [your-subject]

    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [_site_admin_email]
    Reply-To: [your-email]

    0
    0

    [_site_title] "[your-subject]"
    [_site_title] <vowelweb79@gmail.com>
    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [your-email]
    Reply-To: [_site_admin_email]

    0
    0
    Thank you for your message. It has been sent.
    There was an error trying to send your message. Please try again later.
    One or more fields have an error. Please check and try again.
    There was an error trying to send your message. Please try again later.
    You must accept the terms and conditions before sending your message.
    The field is required.
    The field is too long.
    The field is too short.
    There was an unknown error uploading the file.
    You are not allowed to upload files of this type.
    The file is too big.
    There was an error uploading the file.';

    $cf7_post = array(
      'post_title'    => wp_strip_all_tags( $cf7title ),
      'post_content'  => $cf7content,
      'post_status'   => 'publish',
      'post_type'     => 'wpcf7_contact_form',
    );
    // Insert the post into the database
    $cf7post_id = wp_insert_post( $cf7_post );

    add_post_meta(
      $cf7post_id,
      "_form",
      ' <div class="row ft-form">
          <div class="col-lg-9 col-md-9 col-12">
            [email footer-email class:ft-email placeholder "Email here..."]
          </div>
          <div class="col-lg-3 col-md-3 col-12">
            [submit class:ft-btn btn "Submit"]
          </div>
        </div>'
    );

    $cf7mail_data  = array(
      'subject' => '[_site_title] "[your-subject]"',
      'sender'  => '[_site_title] <vowelweb79@gmail.com>',
      'body'    => 'From: [your-name] <[your-email]>
      Subject: [your-subject]

      Message Body:
      [your-message]

      --
      This e-mail was sent from a contact form on [_site_title] ([_site_url])',
      'recipient'           => '[_site_admin_email]',
      'additional_headers'  => 'Reply-To: [your-email]',
      'attachments'         => '',
      'use_html'            => 0,
      'exclude_blank'       => 0
    );

    add_post_meta($cf7post_id, "_mail", $cf7mail_data);
    // Gets term object from Tree in the database.

    $cf7shortcode = '[contact-form-7 id="'.$cf7post_id.'" title="'.$cf7title.'"]';

    set_theme_mod( 'cyber_security_services_pro_footer_email_form',$cf7shortcode );

    // print_r($cf7shortcode);
    // exit;

       
// ---------------COPYRIGHT TEXT-----------

        // set_theme_mod( 'cyber_security_services_pro_footer_copy1', '© 2021 ' );
        set_theme_mod( 'cyber_security_services_pro_footer_copy', '. All Rights Reserved.' );

    



          // ------- Create Main Menu --------
          $menuname =  'OT_MAIN_Primary Menu';
          $bpmenulocation = 'primary';
          $menu_exists = wp_get_nav_menu_object( $menuname );
      
          if( !$menu_exists){
              $menu_id = wp_create_nav_menu($menuname);
              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('HOME','cyber-security-services-pro'),
                  'menu-item-classes' => 'home',
                  'menu-item-url' => home_url( '/' ),
                  'menu-item-status' => 'publish'));

              $parent_page_item = wp_update_nav_menu_item($menu_id, 0, array(
              'menu-item-title' =>  __('PAGE','cyber-security-services-pro'),
              'menu-item-classes' => 'page',
              'menu-item-url' => home_url( '/index.php/page/' ),
              'menu-item-status' => 'publish'));

            wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' => __('Page Left Sidebar','cyber-security-services-pro'),
                  'menu-item-classes' => 'page-left',
                  'menu-item-url' => home_url( '/index.php/page-left/' ),
                  'menu-item-status' => 'publish',
                  'menu-item-parent-id' => $parent_page_item
                ));

            wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' => __('Page Right Sidebar','cyber-security-services-pro'),
                  'menu-item-classes' => 'page-right',
                  'menu-item-url' => home_url( '/index.php/page-right/' ),
                  'menu-item-status' => 'publish',
                  'menu-item-parent-id' => $parent_page_item
                ));

            wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('TYPOGRAPHY','cyber-security-services-pro'),
                  'menu-item-classes' => 'typography',
                  'menu-item-url' => home_url( '/index.php/typography/' ),
                  'menu-item-status' => 'publish',
                  'menu-item-parent-id' => $parent_page_item
                ));

            wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('CONTACT US','cyber-security-services-pro'),
                  'menu-item-classes' => 'contact',
                  'menu-item-url' => home_url( '/index.php/contact/' ),
                  'menu-item-status' => 'publish',
                  'menu-item-parent-id' => $parent_page_item
                ));

            $parent_item = wp_update_nav_menu_item($menu_id, 0, array(
              'menu-item-title' => __('BLOG','cyber-security-services-pro'),
              'menu-item-classes' => 'blog',
              'menu-item-url' => home_url( '/index.php/blog/' ),
              'menu-item-status' => 'publish'
            ));
            wp_update_nav_menu_item($menu_id, 0, array(
              'menu-item-title' => __('Blog Left Sidebar','cyber-security-services-pro'),
              'menu-item-classes' => 'blog-left-sidebar',
              'menu-item-url' => home_url( '/index.php/blog-left-sidebar/' ),
              'menu-item-status' => 'publish',
              'menu-item-parent-id' => $parent_item
            ));
      
            wp_update_nav_menu_item($menu_id, 0, array(
              'menu-item-title' => __('Blog Right Sidebar','cyber-security-services-pro'),
              'menu-item-classes' => 'blog-right-sidebar',
              'menu-item-url' => home_url( '/index.php/blog-right-sidebar/' ),
              'menu-item-status' => 'publish',
              'menu-item-parent-id' => $parent_item
            ));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('CASE STUDIES','cyber-security-services-pro'),
                  'menu-item-classes' => 'case',
                  'menu-item-url' => home_url( '/index.php/case-studies/' ),
                  'menu-item-status' => 'publish'));


              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('SERVICES','cyber-security-services-pro'),
                  'menu-item-classes' => 'services',
                  'menu-item-url' => home_url( '/index.php/services/' ),
                  'menu-item-status' => 'publish'));      
                
              if( !has_nav_menu( $bpmenulocation ) ){
                  $locations = get_theme_mod('nav_menu_locations');
                  $locations[$bpmenulocation] = $menu_id;
                  set_theme_mod( 'nav_menu_locations', $locations );
              }
          }

          $about_title = 'About Us';
          $about_check = get_page_by_title($about_title);
          $about = array(
            'post_type' => 'page',
            'post_title' => $about_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'about'
          );
          $about_id = wp_insert_post($about);

          $pricing_title = 'Pricing';
          $pricing_check = get_page_by_title($pricing_title);
          $pricing = array(
            'post_type' => 'page',
            'post_title' => $pricing_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'pricing'
          );
          $pricing_id = wp_insert_post($pricing);

          $case_title = 'Case Studies';
          $case_check = get_page_by_title($case_title);
          $case = array(
            'post_type' => 'page',
            'post_title' => $case_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'case'
          );
          $case_id = wp_insert_post($case);

          $privacy_title = 'Privacy Policy';
          $privacy_check = get_page_by_title($privacy_title);
          $privacy = array(
            'post_type' => 'page',
            'post_title' => $privacy_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'privacy-policy'
          );
          $privacy_id = wp_insert_post($privacy);

          $terms_title = 'Terms & Conditions';
          $terms_check = get_page_by_title($terms_title);
          $terms = array(
            'post_type' => 'page',
            'post_title' => $terms_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'terms'
          );
          $terms_id = wp_insert_post($terms);


          // ------- Create Footer Info Menu --------
          $menuname =  'OT_info_Menu';
          $bpmenulocation = 'footer-info';
          $menu_exists = wp_get_nav_menu_object( $menuname );
      
          if( !$menu_exists){
              $menu_id = wp_create_nav_menu($menuname);
              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('About Us','cyber-security-services-pro'),
                  'menu-item-classes' => 'about',
                  'menu-item-url' => home_url( '/index.php/about/' ),
                  'menu-item-status' => 'publish'));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Pricing','cyber-security-services-pro'),
                  'menu-item-classes' => 'pricing',
                  'menu-item-url' => home_url( '/index.php/pricing/' ),
                  'menu-item-status' => 'publish'));
      
              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Case Studies','cyber-security-services-pro'),
                  'menu-item-classes' => 'case',
                  'menu-item-url' => home_url( '/index.php/case/' ),
                  'menu-item-status' => 'publish'));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Privacy Policy','cyber-security-services-pro'),
                  'menu-item-classes' => 'privacy-policy',
                  'menu-item-url' => home_url( '/index.php/privacy-policy/' ),
                  'menu-item-status' => 'publish'));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Terms & Conditions','cyber-security-services-pro'),
                  'menu-item-classes' => 'terms',
                  'menu-item-url' => home_url( '/index.php/terms/' ),
                  'menu-item-status' => 'publish'));
      
              if( !has_nav_menu( $bpmenulocation ) ){
                  $locations = get_theme_mod('nav_menu_locations');
                  $locations[$bpmenulocation] = $menu_id;
                  set_theme_mod( 'nav_menu_locations', $locations );
              }
          }


          $secure_title = 'Secure Private Cloud';
          $secure_check = get_page_by_title($secure_title);
          $secure = array(
            'post_type' => 'page',
            'post_title' => $secure_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'secure'
          );
          $secure_id = wp_insert_post($secure);

          $backup_title = 'Online Backup';
          $backup_check = get_page_by_title($backup_title);
          $backup = array(
            'post_type' => 'page',
            'post_title' => $backup_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'backup'
          );
          $backup_id = wp_insert_post($backup);

          $website_title = 'Secure Websites';
          $website_check = get_page_by_title($website_title);
          $website = array(
            'post_type' => 'page',
            'post_title' => $website_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'blog'
          );
          $website_id = wp_insert_post($website);

          $cyber_title = 'Cyber-Security';
          $cyber_check = get_page_by_title($cyber_title);
          $cyber = array(
            'post_type' => 'page',
            'post_title' => $cyber_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'cyber-security'
          );
          $cyber_id = wp_insert_post($cyber);

          $network_title = 'Enterprise Networks';
          $network_check = get_page_by_title($network_title);
          $network = array(
            'post_type' => 'page',
            'post_title' => $network_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'network'
          );
          $network_id = wp_insert_post($network);

          $collaborate_title = 'Collaboration';
          $collaborate_check = get_page_by_title($collaborate_title);
          $collaborate = array(
            'post_type' => 'page',
            'post_title' => $collaborate_title,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => 'collaborate'
          );
          $collaborate_id = wp_insert_post($collaborate);


          // ------- Create Footer links Menu --------
          $menuname =  'OT_link_Menu';
          $bpmenulocation = 'footer-link';
          $menu_exists = wp_get_nav_menu_object( $menuname );
      
          if( !$menu_exists){
              $menu_id = wp_create_nav_menu($menuname);
              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Secure Private Cloud','cyber-security-services-pro'),
                  'menu-item-classes' => 'secure',
                  'menu-item-url' => home_url( '/index.php/secure/' ),
                  'menu-item-status' => 'publish'));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Online Backup','cyber-security-services-pro'),
                  'menu-item-classes' => 'backup',
                  'menu-item-url' => home_url( '/index.php/backup/' ),
                  'menu-item-status' => 'publish'));
      
              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Secure Websites','cyber-security-services-pro'),
                  'menu-item-classes' => 'websites',
                  'menu-item-url' => home_url( '/index.php/websites/' ),
                  'menu-item-status' => 'publish'));

              wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Cyber-Security','cyber-security-services-pro'),
                  'menu-item-classes' => 'cyber-security',
                  'menu-item-url' => home_url( '/index.php/cyber-security/' ),
                  'menu-item-status' => 'publish'));

               wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Enterprise Networks','cyber-security-services-pro'),
                  'menu-item-classes' => 'networks',
                  'menu-item-url' => home_url( '/index.php/networks/' ),
                  'menu-item-status' => 'publish'));

               wp_update_nav_menu_item($menu_id, 0, array(
                  'menu-item-title' =>  __('Collaboration','cyber-security-services-pro'),
                  'menu-item-classes' => 'collaborate',
                  'menu-item-url' => home_url( '/index.php/collaborate/' ),
                  'menu-item-status' => 'publish'));

      
              if( !has_nav_menu( $bpmenulocation ) ){
                  $locations = get_theme_mod('nav_menu_locations');
                  $locations[$bpmenulocation] = $menu_id;
                  set_theme_mod( 'nav_menu_locations', $locations );
              }
          }
          

          $OT_Widget_Importer = new OT_Widget_Importer;
		      $OT_Widget_Importer->import_widgets( $OT_cyber_security_WIE_FILE );

       }
    ?>
    
    <p><?php esc_html_e('Please take backup if your website is already live with data.This importer will fill the Cyber Security Services Pro new customizer values.','cyber-security-services-pro'); ?></p>
      <form id="mep-demo-importer-form" action="<?php echo esc_url(home_url()); ?>/wp-admin/themes.php?page=cyber_security_services_pro_guide" method="POST">
          <input type="submit" name="submit" value="<?php echo esc_attr('Run Importer','cyber-security-services-pro'); ?>" class="button button-primary button-large">

      </form>
      <div class="mep-spinner-div">
        <p class="spinner"></p>
      </div>
      <div class="success">
        <?php
          if (isset($_GET['import-demo'])) {
            echo esc_html('Demo Import Successful','cyber-security-services-pro');
          }
        ?>
      </div>

      <?php
         $admin_url = admin_url( 'admin-ajax.php' );
       ?>
      <script type="text/javascript">
             function validate() {
              document.forms[0].submit();
             }

               jQuery(document).ready(function($) {
                var pathUrl = new URL(window.location.href)
                var searchParams = pathUrl.searchParams.get("import-demo")
                if(searchParams) {
                  history.replaceState({}, '', 'themes.php?page=cyber_security_services_pro_guide')
                }
                $( "#mep-demo-importer-form" ).submit(function( event ) {
                  event.preventDefault();
                  if(confirm("Do you really want to do this?")){
                    $('.spinner').addClass('is-active');
                    var mep_plugin_array = [{
                      'name'             : 'contact-form-7',
                      'slug'             : 'contact-form-7',
                      'source'           : 'https://downloads.wordpress.org/plugin/contact-form-7.zip',
                      'required'         : true,
                      'force_activation' : false,
                      'text-domain'      : 'contact-form-7',
                      'file_name'        : 'wp-contact-form-7.php'
                    },
                    {
                    'name'             : 'woocommerce',
                    'slug'             : 'woocommerce',
                    'source'           : 'https://downloads.wordpress.org/plugin/woocommerce.zip',
                    'required'         : true,
                    'force_activation' : false,
                    'text-domain'      : 'woocommerce',
                    'file_name'        : 'woocommerce.php'
                  }];
                  var url = '<?php echo $admin_url; ?>';
                    // console.log(url)
                    mep_plugin_array.map(function (plugin_url_data, index) {

                              var data_to_post = {
                                action:             'ive-check-plugin-exists',
                                plugin_text_domain: plugin_url_data.slug,
                                main_plugin_file:   plugin_url_data.file_name
                              };
                              var data_to_post_install = {
                                action:             'ive_install_and_activate_plugin',
                                plugin_details: {
                                  plugin_text_domain: plugin_url_data.slug,
                                  plugin_main_file: plugin_url_data.file_name,
                                  plugin_url: plugin_url_data.source
                                },
                                main_plugin_file:   plugin_url_data.file_name
                              };

                              jQuery.ajax({
                                url:    url,
                                type:   'post',
                                data:   data_to_post,
                                async:  false
                              }).done( function( response ) {
                                if ( response.data.install_status == true ) {
                                  jQuery.ajax({
                                    url:    url,
                                    type:   'post',
                                    data:   data_to_post_install,
                                    async:  false
                                  }).done( function( response ) {
                                    console.log(plugin_url_data.slug ,'installed');
                                    if((mep_plugin_array.length - 1) == index) {
                                      console.log('inside length');
                                      $('.spinner').removeClass('is-active');
                                      location.href = location.href + '&import-demo=true';
                                    }
                                  })
                                }
                                else{
                                    wp.updates.installPlugin({
                                      slug:     plugin_url_data.slug,
                                      success:  function(data) {
                                        console.log(plugin_url_data);
                                        jQuery.ajax({
                                          url:    url,
                                          type:   'post',
                                          data:   data_to_post_install,
                                          async:  false
                                        }).done( function( response ) {
                                          console.log(plugin_url_data.slug ,'installed');
                                          if((mep_plugin_array.length - 1) == index) {
                                            $('.spinner').removeClass('is-active');
                                            location.href = location.href + '&import-demo=true';
                                          }
                                      })
                                      },
                                      error: function(data) {
                                        console.log(data);
                                      },
                                    });
                                }
                              });
                        })
                  } else {
                    return false;
                  }
                });
              });
              //
      </script>
      </div>




