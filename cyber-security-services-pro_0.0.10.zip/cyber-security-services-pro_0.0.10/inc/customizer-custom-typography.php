<?php

  // GLOBAL COLOR

  $wp_customize->add_panel( $Parent_General_Section );
  
  $wp_customize->add_section('cyber_security_services_pro_color_pallette',array(
    'title' => __('Global Color / Typography Settings','cyber-security-services-pro'),
    'description'=> __('Global Color / Typography Settings','cyber-security-services-pro'),
    'panel' => 'cyber_security_services_pro_parent_general_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_global_color_settings', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_global_color_settings',array(
    'label' => __('Complete Site Color Changes','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_global_background_options',array(
    'default' => 'simple-bgcolor',
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_select'
  ));
  $wp_customize->add_control('cyber_security_services_pro_global_background_options',array(
    'type' => 'select',
    'label' => __('Background Color Option','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'choices' => array(
      'simple-bgcolor' => __('Simple Background Color','cyber-security-services-pro'),
      'gradiant-bg-color' => __('Gradient Background Color','cyber-security-services-pro')
    ),
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_global_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_global_bgcolor', array(
    'label' => __('Background Color', 'cyber-security-services-pro'),
    'description' => __('You can change complete site background color in one click ', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'settings' => 'cyber_security_services_pro_global_bgcolor',
    'active_callback' => 'cyber_security_services_pro_global_simple_bgcolor'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_global_gradient_options',array(
    'default' => 'linear-gradient',
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_select'
  ));
  $wp_customize->add_control('cyber_security_services_pro_global_gradient_options',array(
    'type' => 'select',
    'label' => __('Background Color Option','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'choices' => array(
      'linear-gradient' => __('Linear Gradient','cyber-security-services-pro'),
      'radial-gradient' => __('Radial Gradient','cyber-security-services-pro')
    ),
    'active_callback' => 'cyber_security_services_pro_global_gradiant_bgcolor'
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_global_gradiant_1', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_global_gradiant_1', array(
    'label' => __('Gradient Color 1', 'cyber-security-services-pro'),
    'description' => __('You can change complete site gradiant background color in one click ', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'settings' => 'cyber_security_services_pro_global_gradiant_1',
    'active_callback' => 'cyber_security_services_pro_global_gradiant_bgcolor'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_global_gradiant_2', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_global_gradiant_2', array(
    'label' => __('Gradient Color 2', 'cyber-security-services-pro'),
    'description' => __('You can change complete site gradiant background color in one click ', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'settings' => 'cyber_security_services_pro_global_gradiant_2',
    'active_callback' => 'cyber_security_services_pro_global_gradiant_bgcolor'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_gradient_angle',array(
    'default' => '',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_number_absint',
  ));
  $wp_customize->add_control('cyber_security_services_pro_gradient_angle',array(
    'label' => __('Gradient Angle','cyber-security-services-pro'),
    'description' => __('You can change gradient angle ex: 90.','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'type'    => 'number',
    'active_callback' => 'cyber_security_services_pro_linear_gradient'
  ));

  $wp_customize->add_setting('cyber_security_services_pro_gradient_sides',array(
    'default' => 'center',
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_sanitize_select'
  ));
  $wp_customize->add_control('cyber_security_services_pro_gradient_sides',array(
    'type' => 'select',
    'label' => __('Gradient Sides','cyber-security-services-pro'),
    'description' => __('You can change gradient sides ex: top.','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette',
    'choices' => array(
      'center' => __('Center','cyber-security-services-pro'),
      'left' => __('Left','cyber-security-services-pro'),
      'right' => __('Right','cyber-security-services-pro'),
      'top' => __('Top','cyber-security-services-pro'),
      'bottom' => __('Bottom','cyber-security-services-pro')
    ),
    'active_callback' => 'cyber_security_services_pro_radial_gradient'
  )); 

  // GLOBAL FONTS

  $wp_customize->add_setting( 'cyber_security_services_pro_global_font', array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_global_font',
    array(
    'label' => __('Complete Site Fonts Changes','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_color_pallette'
  )));

  $wp_customize->add_setting('cyber_security_services_pro_global_heading_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_global_heading_font', array(
    'section'  => 'cyber_security_services_pro_color_pallette',
    'label'    => __( 'Heading Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting('cyber_security_services_pro_global_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_global_text_font', array(
    'section'  => 'cyber_security_services_pro_color_pallette',
    'label'    => __( 'Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));
 
 ?>