<?php

	// Topbar
	
	$wp_customize->add_panel( $ParentPanel );

	$Parent_Tobar_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_topbar_section', array(
		'title' => __( 'Topbar Option', 'cyber-security-services-pro' ),
		'panel' => 'cyber_security_services_pro_panel_id',
	));

	$wp_customize->add_panel( $Parent_Tobar_Section );

	$wp_customize->add_section( 'cyber_security_services_pro_topbar_section', array(
		'title' => __( 'Topbar Settings', 'cyber-security-services-pro' ),
		'description' => __('Topbar Settings','cyber-security-services-pro'),
		'priority'  => null,
		'panel' => 'cyber_security_services_pro_parent_topbar_section',
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_topbar_enable', array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  	));
	$wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_topbar_enable', array(
		'label' => esc_html__( 'Show or Hide Topbar', 'cyber-security-services-pro' ),
		'section' => 'cyber_security_services_pro_topbar_section'
	)));

	$wp_customize->selective_refresh->add_partial( 'cyber_security_services_pro_topbar_enable', array(
	    'selector' => '.topbar_section .container',
	    'render_callback' => 'cyber_security_services_pro_customize_partial_cyber_security_services_pro_topbar_enable',
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_search_enable',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_search_enable',
    array(
    'label' => esc_html__( 'Show or Hide header Search', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_topbar_section'
  )));

// $wp_customize->add_setting('cyber_security_services_pro_header_search_placeholder_text',array(
//         'default'   => '',
//         'sanitize_callback' => 'sanitize_textarea_field',
//     ));
//     $wp_customize->add_control('cyber_security_services_pro_header_search_placeholder_text',array(
//         'label' => __('Search placeholder Text','cyber-security-services-pro'),
//         'section'   => 'cyber_security_services_pro_logo_menu_color_section',
//         'type'      => 'text'
//     ));

  $wp_customize->add_setting('cyber_security_services_pro_header_search_icon',array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_header_search_icon',array(
    'label' => __('Search Icon','cyber-security-services-pro'),
    'description' => __('Add Font Awesome Class Here','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_topbar_section',
    'setting' => 'cyber_security_services_pro_header_search_icon',
    'type'    => 'text'
  ));

	

	// Topbar COLOR SETTINGS

	$wp_customize->add_panel( $Parent_Tobar_Section );

	$wp_customize->add_section( 'cyber_security_services_pro_topbar_color_section', array(
		'title' => __( 'Topbar Color Settings', 'cyber-security-services-pro' ),
		'description' => __('Topbar Color Settings','cyber-security-services-pro'),
		'priority'  => null,
		'panel' => 'cyber_security_services_pro_parent_topbar_section',
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_topbar_bg_settings',array(
	    'default' => '',
	    'transport' => 'postMessage',
	    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
	));
	$wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_topbar_bg_settings', array(
		'label' => __('Section Background Settings','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section'
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_topbar_bgcolor', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_topbar_bgcolor', array(
		'label' => __('Section Background Color', 'cyber-security-services-pro'),
		'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section',
		'settings' => 'cyber_security_services_pro_topbar_bgcolor',
	)));

	$wp_customize->add_setting('cyber_security_services_pro_topbar_bgimage',array(
		'default' => '',
		'sanitize_callback' => 'esc_url_raw',
	));
	$wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_topbar_bgimage',array(
		'label' => __('Section Background Image','cyber-security-services-pro'),
		'description' => __('Dimension 1600 * 800','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section',
		'settings' => 'cyber_security_services_pro_topbar_bgimage'
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_topbar_color_settings', array(
		'default' => '',
		'transport' => 'postMessage',
		'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
	));
	$wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_topbar_color_settings',
	  array(
		'label' => __('Topbars Color Settings ','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section'
	)));
	
	$wp_customize->add_setting( 'cyber_security_services_pro_topbar_social_icon_color', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_topbar_social_icon_color', array(
		'label' => __('Topbar Social Icon Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section',
		'settings' => 'cyber_security_services_pro_topbar_social_icon_color',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_header_search_icon_bgcolor', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_header_search_icon_bgcolor', array(
		'label' => __('Topbar Search Icon Background Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section',
		'settings' => 'cyber_security_services_pro_header_search_icon_bgcolor',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_header_search_icon_color', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_header_search_icon_color', array(
		'label' => __('Topbar Search Icon Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_topbar_color_section',
		'settings' => 'cyber_security_services_pro_header_search_icon_color',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_search_placeholder_color', array(
      'default' => '',
      'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_search_placeholder_color', array(
      'label' => __('Search Placeholder Color', 'cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_topbar_color_section',
      'settings' => 'cyber_security_services_pro_search_placeholder_color',
  )));	

  $wp_customize->add_setting( 'cyber_security_services_pro_topbar_searchbtn_text_color', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_topbar_searchbtn_text_color', array(
    'label' => __('Search Button Text Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_topbar_color_section',
    'settings' => 'cyber_security_services_pro_topbar_searchbtn_text_color',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_topbar_searchbtn_text_font',array(
    'default' => '',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('cyber_security_services_pro_topbar_searchbtn_text_font', array(
    'section'  => 'cyber_security_services_pro_topbar_color_section',
    'label'    => __( 'Search Button Text Fonts Family','cyber-security-services-pro'),
    'type'     => 'select',
    'choices'  => $font_array,
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_topbar_searchbtn_bgcolor', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_topbar_searchbtn_bgcolor', array(
    'label' => __('Search Button Background Color', 'cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_topbar_color_section',
    'settings' => 'cyber_security_services_pro_topbar_searchbtn_bgcolor',
  )));

	// LOGO COLOR SETTINGS

	$wp_customize->add_panel( $Parent_Tobar_Section);

	$wp_customize->add_section('cyber_security_services_pro_logo_menu_color_section',array(
		'title'	=> __('Logo & Menus Color Settings','cyber-security-services-pro'),
		'description'	=> __('Logo & Menus Color Settings','cyber-security-services-pro'),
		'priority'	=> null,
		'panel' => 'cyber_security_services_pro_parent_topbar_section',
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_logo_bg_settings',array(
	    'default' => '',
	    'transport' => 'postMessage',
	    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
	));
	$wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_logo_bg_settings', array(
		'label' => __('Logo Color Settings','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section'
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_logo_title_bgcolor', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_logo_title_bgcolor', array(
		'label' => __('Logo Background Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_logo_title_bgcolor',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_logo_title_color', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_logo_title_color', array(
		'label' => __('Logo Title Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_logo_title_color',
	)));

	$wp_customize->add_setting('cyber_security_services_pro_logo_title_font',array(
		'default' => '',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
	));
	$wp_customize->add_control('cyber_security_services_pro_logo_title_font', array(
		'section'  => 'cyber_security_services_pro_logo_menu_color_section',
		'label'    => __( 'Logo Title Fonts','cyber-security-services-pro'),
		'type'     => 'select',
		'choices'  => $font_array,
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_logo_text_color', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_logo_text_color', array(
		'label' => __('Logo Text Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_logo_text_color',
	)));

	$wp_customize->add_setting('cyber_security_services_pro_logo_text_font',array(
		'default' => '',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
	));
	$wp_customize->add_control('cyber_security_services_pro_logo_text_font', array(
		'section'  => 'cyber_security_services_pro_logo_menu_color_section',
		'label'    => __( 'Logo Text Fonts','cyber-security-services-pro'),
		'type'     => 'select',
		'choices'  => $font_array,
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_menu_text_color', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_menu_text_color', array(
		'label' => __('Menu Text Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_menu_text_color',
	)));

	$wp_customize->add_setting('cyber_security_services_pro_menu_text_font',array(
		'default' => '',
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
	));
	$wp_customize->add_control('cyber_security_services_pro_menu_text_font', array(
		'section'  => 'cyber_security_services_pro_logo_menu_color_section',
		'label'    => __( 'Menu Text Fonts','cyber-security-services-pro'),
		'type'     => 'select',
		'choices'  => $font_array,
	));

	$wp_customize->add_setting('cyber_security_services_pro_headermenu_font_size',array(
		'default' => '',
		'sanitize_callback' => 'sanitize_text_field'
	));
	$wp_customize->add_control('cyber_security_services_pro_headermenu_font_size',array(
		'label' => __('Menu Font Size','cyber-security-services-pro'),
		'description' => __('Add font size in px','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'setting' => 'cyber_security_services_pro_headermenu_font_size',
		'type'    => 'number'
	));

	$wp_customize->add_setting( 'cyber_security_services_pro_header_menuhovercolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_header_menuhovercolor', array(
		'label' => __('Menu Item Hover Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_header_menuhovercolor',
	)));
	
	// This is Nav Dropdown Background Color picker setting
	$wp_customize->add_setting( 'cyber_security_services_pro_dropdownbg_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_dropdownbg_color', array(
		'label' => __('Menu DropDown Background Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_dropdownbg_color',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_dropdownbg_itemcolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_dropdownbg_itemcolor', array(
		'label' => __('Menu DropDown Item Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_dropdownbg_itemcolor',
	)));

	//This is Header Menu FontFamily picker setting
	$wp_customize->add_setting('cyber_security_services_pro_dropdownbg_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'cyber_security_services_pro_sanitize_choices'
	 ));
	$wp_customize->add_control(
	    'cyber_security_services_pro_dropdownbg_font_family', array(
	    'section'  => 'cyber_security_services_pro_logo_menu_color_section',
	    'label'    => __( 'Dropdown Menu Item Fonts','cyber-security-services-pro'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	$wp_customize->add_setting('cyber_security_services_pro_dropdownbg_font_size',array(
		'default' => '',
		'sanitize_callback' => 'sanitize_text_field'
	));
	$wp_customize->add_control('cyber_security_services_pro_dropdownbg_font_size',array(
		'label' => __('Dropdown Menu Font Size','cyber-security-services-pro'),
		'description' => __('Add font size in px','cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'setting' => 'cyber_security_services_pro_dropdownbg_font_size',
		'type'    => 'number'
	));


	$wp_customize->add_setting( 'cyber_security_services_pro_dropdownbg_item_hovercolor', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_dropdownbg_item_hovercolor', array(
		'label' => __('Menu DropDown Item Hover Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_dropdownbg_item_hovercolor',
	)));

	$wp_customize->add_setting( 'cyber_security_services_pro_header_menu_active_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_header_menu_active_color', array(
		'label' => __('Active Menu Item Background Color', 'cyber-security-services-pro'),
		'section' => 'cyber_security_services_pro_logo_menu_color_section',
		'settings' => 'cyber_security_services_pro_header_menu_active_color',
	)));
?>