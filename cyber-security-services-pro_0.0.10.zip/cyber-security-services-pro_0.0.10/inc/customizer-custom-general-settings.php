<?php

  //GENERAL SETTINGS

  $wp_customize->add_panel( $ParentPanel );

  $Parent_General_Section = new cyber_security_services_pro_WP_Customize_Panel( $wp_customize, 'cyber_security_services_pro_parent_general_section', array(
    'title' => __( 'General Options', 'cyber-security-services-pro' ),
    'panel' => 'cyber_security_services_pro_panel_id',
  ));

  $wp_customize->add_panel( $Parent_General_Section );

  $wp_customize->add_section('cyber_security_services_pro_post_general_settings',array(
    'title' => __('General Settings','cyber-security-services-pro'),
    'description'=> __('General Settings','cyber-security-services-pro'),
    'priority'=> 1,
    'panel' => 'cyber_security_services_pro_parent_general_section',
  ));

  $wp_customize->add_setting( 'cyber_security_services_pro_theme_layout_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_theme_layout_settings',array(
    'label' => __('Theme Layout Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

//Page Title layout
  $wp_customize->add_setting('cyber_security_services_pro_page_title_content_option',array(
    'default' => __('Left','cyber-security-services-pro'),
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control(new cyber_security_services_pro_Image_Radio_Control($wp_customize, 'cyber_security_services_pro_page_title_content_option', array(
      'type' => 'select',
      'label' => __('Page Title Layouts','cyber-security-services-pro'),
      'section' => 'cyber_security_services_pro_post_general_settings',
      'choices' => array(
       'Left' => get_template_directory_uri().'/assets/images/header-layout1.png',
          'Center' => get_template_directory_uri().'/assets/images/header-layout2.png',
          'Right' => get_template_directory_uri().'/assets/images/header-layout3.png',
  ))));

  $wp_customize->add_setting( 'cyber_security_services_pro_page_template_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_page_template_settings',array(
    'label' => __('Page Title Background Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_pages_bgcolor', array(
    'default' => '#efefef',
    'sanitize_callback' => 'sanitize_hex_color'
  ));
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cyber_security_services_pro_pages_bgcolor', array(
    'label' => __('Page Title Background Color', 'cyber-security-services-pro'),
    'description'   => __('Either add background color or background image, if you add both background color will be top most priority','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_post_general_settings',
    'settings' => 'cyber_security_services_pro_pages_bgcolor',
  )));

  $wp_customize->add_setting('cyber_security_services_pro_pages_bgimage',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(new WP_Customize_Image_Control( $wp_customize,'cyber_security_services_pro_pages_bgimage',array(
    'label' => __('Page Title Background Image','cyber-security-services-pro'),
    'description' => __('Dimension 1600 * 800. First Clear the background Color field.','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_post_general_settings',
    'settings' => 'cyber_security_services_pro_pages_bgimage'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_on_off_settings',array(
    'default' => '',
    'transport' => 'postMessage',
    'sanitize_callback' => 'cyber_security_services_pro_text_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Themes_Seperator_Custom_Control( $wp_customize, 'cyber_security_services_pro_on_off_settings',array(
    'label' => __('Enable / Disable Settings','cyber-security-services-pro'),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_theme_loader',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_theme_loader',
    array(
    'label' => esc_html__( 'Show or Hide Site Loader', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_post_general_settings_post_date',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_post_general_settings_post_date',
    array(
    'label' => esc_html__( 'Show or Hide Post Date', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_post_general_settings_post_comments',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_post_general_settings_post_comments',
    array(
    'label' => esc_html__( 'Show or Hide Comments', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_post_general_settings_post_author',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  )); 
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_post_general_settings_post_author',
    array(
    'label' => esc_html__( 'Show or Hide Author', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_post_general_settings_post_category',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  ));   
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_post_general_settings_post_category',
    array(
    'label' => esc_html__( 'Show or Hide Category', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

  $wp_customize->add_setting( 'cyber_security_services_pro_post_general_settings_post_sidebar',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'cyber_security_services_pro_switch_sanitization'
  )); 
  $wp_customize->add_control( new cyber_security_services_pro_Toggle_Switch_Custom_Control( $wp_customize, 'cyber_security_services_pro_post_general_settings_post_sidebar',
    array(
    'label' => esc_html__( 'Show or Hide Sidebar', 'cyber-security-services-pro' ),
    'section' => 'cyber_security_services_pro_post_general_settings'
  )));

?>