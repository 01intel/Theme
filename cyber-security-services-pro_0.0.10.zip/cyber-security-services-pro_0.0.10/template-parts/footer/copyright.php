<?php
if ( get_theme_mod( 'cyber_security_services_pro_footer_copy_bgcolor' ) ) {
	$about_backg = 'background-color:' . esc_attr( get_theme_mod( 'cyber_security_services_pro_footer_copy_bgcolor' ) ) . ';';
} elseif ( get_theme_mod( 'cyber_security_services_pro_footer_copy_bgimage' ) ) {
	$about_backg = 'background-image:url(\'' . esc_url( get_theme_mod( 'cyber_security_services_pro_footer_copy_bgimage' ) ) . '\')';
} else {
	$about_backg = '';
}
?>
<div class="copyright m-auto" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<div class="ftr-copy text-center">		
			<p class="copy-text py-3 mb-0">
				<span class="credit_link"><?php echo esc_html( cyber_security_services_pro_credit_link() ); ?></span>
				<span><?php echo esc_html( get_theme_mod( 'cyber_security_services_pro_footer_copy' ) ); ?></span>
			</p>				
			<a href="javascript:" id="return-to-top"><i class="fas fa-arrow-up"></i></a>			
		</div>
	</div>
</div>







 














