<?php

  $section_hide = get_theme_mod( 'cyber_security_services_pro_pricing_plan_enable' );
  if ( 'Disable' == $section_hide ) {
    return;
  }
  
if( get_theme_mod('cyber_security_services_pro_pricing_plan_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_pricing_plan_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_pricing_plan_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_pricing_plan_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="pricing-plan" class="py-5 pricing-tables" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container reveal">
    <div class="plan-head text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_small_heading')!=''){ ?>
        <h6 class="plan-sm-head mx-auto px-4"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_small_heading')); ?>
        </h6>
      <?php } if(get_theme_mod('cyber_security_services_pro_pricing_plan_main_heading')!=''){ ?>
        <h2 class="plan-main-head py-3"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_main_heading')); ?>
        </h2>
      <?php } ?>
      <div class="plan-tabs mb-5 mt-3">
        <span class="plantab-bill mr-3"><?php esc_html_e('Bill','cyber-security-services-pro');?></span>
        <span class="pricing-switcher">
          <div class="switch">
            <span class="monthly">Monthly</span>
            <input type="checkbox" class="custom-switch">
            <span class="annually">Annually</span>
          </div>
        </span>              
      </div>
    </div> 
    <div class="plans grid-wrapper">
      <div class="plan plan--starter flex-wrapper">
         <?php $plans=get_theme_mod('cyber_security_services_pro_pricing_plan_increase');
        for($i=1 ; $i<=$plans; $i++) { ?>
          <div class="col-lg-4 col-md-4 col-12">
            <div class="inner-plan-box p-4 my-3 my-lg-0 text-center text-lg-left text-md-left"> 
          <div class="row">
            <div class="col-lg-6 col-md-12 col-12">
              <div class="plan__head">
                <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_pack_option'.$i)!=''){ ?>
                  <h6 class="pack-option"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_pack_option'.$i)); ?>
                  </h6>
                <?php } ?>
                <div class="plan__price">
                  <span class="price price--monthly">
                    <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_price'.$i)!=''|| get_theme_mod('cyber_security_services_pro_pricing_plan_permonth'.$i)!=''){ ?>
                      <h2 class="plans-price">
                    <?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_price'.$i)); ?><sub class="plan__type"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_permonth'.$i)); ?></sub>
                      </h2>
                    <?php }?>
                  </span>
                  <span class="price price--annually">
                    <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_price_year'.$i)!=''|| get_theme_mod('cyber_security_services_pro_pricing_plan_peryear'.$i)!=''){ ?>
                      <h2 class="plans-price">
                    <?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_price_year'.$i)); ?><sub class="plan__type"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_peryear'.$i)); ?></sub>
                      </h2>
                    <?php }?>
                  </span>
                </div>                  
              </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12 align-self-center">
              <div class="plan-button">
                <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_button_title'.$i)!=''){ ?>
                  <a href="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_button_url'.$i)); ?>" class="plan-btn btn">
                  <span><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_button_title'.$i)); ?></span>
                  </a>
                <?php } ?>
              </div>
            </div>
          </div>           
          <div class="plan-inner-head">
            <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_inn_text'.$i)!=''){ ?>
              <p class="pack-txt py-2"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_inn_text'.$i)); ?>
              </p>
            <?php } ?>
            <div class="plan__features">
              <ul class="plan-list">
                <?php $plan_feature=get_theme_mod('cyber_security_services_pro_pricing_plan_features_no'.$i);
                for($j=1;$j<=$plan_feature;$j++){ ?>    
                <li>
                  <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_features'.$i.$j)!=''){ ?>
                    <p class="planlist-item">
                  <?php if(get_theme_mod('cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j)!=''){ ?> 
                    <i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_pricing_plan_tick_icon'.$i.$j)); ?> p-1 mr-3"></i>
                  <?php } ?>
                  <?php esc_html_e(get_theme_mod('cyber_security_services_pro_pricing_plan_features'.$i.$j)); ?></p>
                  <?php }?>               
                </li>
                <?php }  ?>
              </ul>
            </div>           
          </div> 
        </div>
          </div>
        
        <?php }  ?>      
      </div>                
    </div>        
  </div>   
</section>