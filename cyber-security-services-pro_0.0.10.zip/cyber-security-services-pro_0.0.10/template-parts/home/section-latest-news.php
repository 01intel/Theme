<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_latest_news_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_latest_news_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_latest_news_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_latest_news_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_latest_news_bgimage')).'\')';
}else{
  $about_backg = '';
}

$cyber_security_services_pro_year  = get_the_time('Y'); 
$cyber_security_services_pro_month = get_the_time('m'); 
$cyber_security_services_pro_day   = get_the_time('d'); 

?>

<section id="latest_news" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container reveal">
    <div class="news-head py-4 text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_latest_news_small_head')!=''){ ?>
        <h6 class="news-sm-head mx-auto px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_latest_news_small_head')); ?></h6>
      <?php }?>
      <?php if(get_theme_mod('cyber_security_services_pro_latest_news_heading')!=''){ ?>
        <h2 class="news-main-head py-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_latest_news_heading')); ?></h2>
      <?php }?>      
    </div>   
    <div class="news-info">
      <div class="owl-carousel">
        <?php
        $i = 1;
          $latest_category=  get_theme_mod('cyber_security_services_pro_latest_news_category');if($latest_category){
              $page_query = new WP_Query(
          array( 
            'category_name' => esc_html($latest_category ,'cyber-security-services-pro'),
            'posts_per_page' => get_theme_mod('cyber_security_services_pro_latest_news_increase')
          )
        );?>
        <?php while( $page_query->have_posts() ) : $page_query->the_post(); ?>
          <div class="news-box m-2 p-2">
            <div class="news-img-box">
              <?php if (has_post_thumbnail()){ ?>
              <?php the_post_thumbnail(); ?>              
              <?php } ?> 
            </div>                         
            <div class="blog-commnt py-3" style="<?php if (has_post_thumbnail() == ""){
              echo "position: unset;";} ?>">
              <?php if ( get_theme_mod('cyber_security_services_pro_post_general_settings_post_author',true) == "1" ) { ?>
              <span class="entry-author mr-4"><?php esc_html_e('Posted By:','cyber-security-services-pro');?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a></span>
              <?php } ?>
              <?php if ( get_theme_mod('cyber_security_services_pro_post_general_settings_post_comments',true) == "1" ) { ?>
              <span class="entry-comments"><i class="fa-solid fa-comment-dots mx-1"></i> <?php comments_number( __('0 Comments','cyber-security-services-pro'), __('0 Comments','cyber-security-services-pro'), __('% Comments','cyber-security-services-pro')); ?></span>
              <?php } ?>
            </div>
            <div class="lower-new-box">           
              <div class="news-inn-title">
                <h3 class="post-title pt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              </div>                                      
              <p class="news-post-txt mb-0"><?php echo esc_html(wp_trim_words(get_the_content(),'50') );?></p>        
              <div class="news-button py-2">
                <a href="<?php the_permalink(); ?>" class="news-btn pl-0"><span><?php esc_html_e('Read More','cyber-security-services-pro');?><i class="fa-solid fa-angle-right pl-1"></i></span></a>
              </div>              
            </div>
          </div>
              <?php endwhile;
            wp_reset_postdata();
          }?>
      </div>     
    </div>
    <div class="blog-outer-btn text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_url')!='' || get_theme_mod('cyber_security_services_pro_latest_news_outer_btn')!='' ){ ?>
        <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_url')); ?>" class="blog-outr-btn btn">
          <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_latest_news_outer_btn')); ?></span>
        </a>                                
      <?php }?>
    </div>
  </div>  
</section>