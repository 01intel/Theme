<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_achievement_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_achievement_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_achievement_bgcolor')).' !important;';
}elseif( get_theme_mod('cyber_security_services_pro_achievement_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_achievement_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="achievement" class="pb-5" style="<?php echo esc_attr($about_backg); ?>">	
	<div class="container reveal">		
		<div class="row">
			<div class="col-lg-6 col-md-8 col-12">
				<div class="achieve-bg">
					<div class="achieve-img-box">
						<?php if(get_theme_mod('cyber_security_services_pro_achievement_bg_img')!=''){ ?>
							<img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_achievement_bg_img')); ?>">
							<div class="achv-detail">
								<div class="row ac-inn">
									<div class="col-lg-4 col-md-4 col-12 ac-head">
										<?php if(get_theme_mod('cyber_security_services_pro_achievement_head')!=''){ ?>
				    					<h3 class="achieve-head text-center pb-0 pb-lg-2"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_achievement_head')); ?></h3>
										<?php }?>
									</div>
									<div class="col-lg-8 col-md-8 col-12 ac-txt align-self-center">
										<?php if(get_theme_mod('cyber_security_services_pro_achievement_text')!=''){ ?>
				    					<h4 class="achieve-left-txt pt-0 pt-lg-2 text-lg-left text-center"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_achievement_text')); ?></h4>
				  					<?php }?>
									</div>
								</div>
							</div>													
						<?php }?>
					</div>
				</div>
			</div>			
			<div class="col-lg-6 col-md-4 col-12 align-self-center">
				<div class="owl-carousel">							
					<?php $achieve=get_theme_mod('cyber_security_services_pro_achievement_increase');
					for($i=1 ; $i<=$achieve; $i++) { ?>			  				
						<div class="achieve-box text-center text-lg-left text-md-left">	
							<?php if(get_theme_mod('cyber_security_services_pro_achievement_count'.$i)!=''){ ?>
		    				<h3 class="achieve-count"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_achievement_count'.$i)); ?></h3>
		  				<?php }?>
		  				<?php if(get_theme_mod('cyber_security_services_pro_achievement_inner_head'.$i)!=''){ ?>
		    				<p class="achieve-inner-head"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_achievement_inner_head'.$i)); ?></p>
		  				<?php }?>
						</div>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</section>