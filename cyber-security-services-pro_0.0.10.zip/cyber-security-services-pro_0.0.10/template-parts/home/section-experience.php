<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_experience_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_experience_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_experience_bgcolor')).' !important;';
}elseif( get_theme_mod('cyber_security_services_pro_experience_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_experience_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="experience" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
  <div class="intro-bg">
    <div class="container">   
      <div class="intro-head text-center">
        <?php if(get_theme_mod('cyber_security_services_pro_experience_heading')!=''){ ?>
          <h2 class="intro-main-head mx-auto">
          <span><?php esc_html_e(get_theme_mod('cyber_security_services_pro_experience_heading')); ?></span></h2>
        <?php }?>
        <?php if(get_theme_mod('cyber_security_services_pro_experience_text')!=''){ ?>
          <h6 class="intro-para py-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_experience_text')); ?></h6>
        <?php }?>     
      </div>    
      <div class="intro-btn text-center py-3">
        <?php if(get_theme_mod('cyber_security_services_pro_experience_btn_url')!='' || get_theme_mod('cyber_security_services_pro_experience_btn')!='' ){ ?>
          <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_experience_btn_url')); ?>" class="intro-btn btn blue">
            <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_experience_btn')); ?></span>
          </a>                                
        <?php }?>     
      </div>   
    </div>
  </div>  
</section>