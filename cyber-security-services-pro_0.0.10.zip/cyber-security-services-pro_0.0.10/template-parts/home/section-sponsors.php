<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_sponsors_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_sponsors_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_sponsors_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_sponsors_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_sponsors_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="sponsors" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
  <div class="sponser-bg">
    <div class="container reveal">
      <div class="sponsor-head text-center">
        <?php if(get_theme_mod('cyber_security_services_pro_sponsors_small_head')!=''){ ?>
          <h6 class="sponsor-sm-head mx-auto px-4">
        <?php esc_html_e(get_theme_mod('cyber_security_services_pro_sponsors_small_head')); ?>
          </h6>
        <?php } ?>
        <?php if(get_theme_mod('cyber_security_services_pro_sponsors_main_heading')!=''){ ?>
          <h2 class="sponsor-head pt-3 pb-5 mx-auto">
        <?php esc_html_e(get_theme_mod('cyber_security_services_pro_sponsors_main_heading')); ?>
          </h2>
        <?php } ?>
      </div>
      <div class="brand-overlay">
        <div class="sponsor-info px-5">
          <div class="owl-carousel align-self-center">
            <?php $sponsers=get_theme_mod('cyber_security_services_pro_sponsors_increase');
            for($i=1 ; $i<=$sponsers; $i++) { ?>
              <div class="spons-bg-overlay">
                <div class="sponser-imgs align-self-center text-center">
                  <?php if(get_theme_mod('cyber_security_services_pro_sponsors_image'.$i)!=''){ ?>
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_sponsors_image'.$i)); ?>">
                  <?php }?>        
                </div>
              </div>            
            <?php } ?>        
          </div>
        </div> 
      </div>          
    </div>
  </div>
</section>