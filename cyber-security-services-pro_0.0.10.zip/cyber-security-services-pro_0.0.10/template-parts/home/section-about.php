<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_about_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_about_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_about_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_about_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_about_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="about" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container reveal">
		<div class="row abt-in">			
			<div class="col-lg-6 col-md-6 col-12">
				<div class="about-img-box">
					<div class="row img-divs text-center">
						<div class="col-lg-6 col-md-6 col-12 pr-lg-1 align-self-center">
							<div class="abt-inn-pic1">
								<?php if(get_theme_mod('cyber_security_services_pro_about_image1')!=''){ ?>
									<img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image1')); ?>">
								<?php }?>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-12">
							<div class="abt-inn-pic2 pb-3">
								<?php if(get_theme_mod('cyber_security_services_pro_about_image2')!=''){ ?>
									<img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image2')); ?>">
								<?php }?>
							</div>
							<div class="abt-inn-pic3">
								<?php if(get_theme_mod('cyber_security_services_pro_about_image3')!=''){ ?>
									<img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image3')); ?>">
								<?php }?>
							</div>
						</div>
					</div>										
				</div>								
			</div>
			<div class="col-lg-6 col-md-6 col-12">
				<div class="abt-info py-lg-5 py-3 py-md-2 text-center text-lg-left text-md-left">
					<?php if(get_theme_mod('cyber_security_services_pro_about_small_heading')!=''){ ?>
						<h6 class="abt-sm-head px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_small_heading')); ?></h6>
					<?php }?>				
					<?php if(get_theme_mod('cyber_security_services_pro_about_heading')!=''){ ?>
						<h2 class="abt-main-head text-effect"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_heading')); ?></h2>
					<?php }?>												    	    
					<?php if(get_theme_mod('cyber_security_services_pro_about_text')!=''){ ?>
						<p class="abt-para py-lg-3 py-md-1 py-1"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_text')); ?></p>
					<?php }?>
	  			<div class="about-btn text-center text-lg-left text-md-left">            
	          <?php if(get_theme_mod('cyber_security_services_pro_about_btn_url')!='' || get_theme_mod('cyber_security_services_pro_about_btn')!='' ){ ?>
	        		<a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_btn_url')); ?>"			class="abt-read-btn btn">
	              <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_about_btn')); ?></span>
	            </a>                                
	        	<?php }?>
					</div>				
				</div>
			</div>
		</div>	
	</div>
</section>
