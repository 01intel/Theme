<?php
$about_section = get_theme_mod( 'cyber_security_services_pro_choose_us_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_choose_us_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_choose_us_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_choose_us_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_choose_us_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>
<section id="choose_us" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container reveal">
    <div class="row">
      <div class="col-lg-5 col-md-12 col-12">
        <div class="choose_us_head text-center text-lg-left text-md-left">
          <?php if(get_theme_mod('cyber_security_services_pro_choose_us_small_head')!=''){ ?>
            <h6 class="choose-sm-head px-4">
          <?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_small_head')); ?>
            </h6>
          <?php } ?>
          <?php if(get_theme_mod('cyber_security_services_pro_choose_us_main_heading')!=''){ ?>
            <h2 class="choose-head py-lg-3">
          <?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_main_heading')); ?>
            </h2>
          <?php } ?>
          <?php if(get_theme_mod('cyber_security_services_pro_choose_us_text')!=''){ ?>
            <p class="choose-text pt-2 mb-1"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_text')); ?></p>
          <?php }?>
          <div class="chos-checklist text-left">
            <?php $choose=get_theme_mod('cyber_security_services_pro_choose_us_increase');
              for($i=1 ; $i<=$choose; $i++) { ?>           
                <ul class="chos-under text-center text-lg-left text-md-left">
                  <li>
                    <?php if(get_theme_mod('cyber_security_services_pro_choose_us_inner_list'.$i)!=''){ ?>
                      <h6 class="choslist-item1">
                    <?php if(get_theme_mod('cyber_security_services_pro_choose_us_tick_icon'.$i)!=''){ ?> 
                      <i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_choose_us_tick_icon'.$i)); ?> pr-3"></i>
                    <?php } ?>
                    <?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_inner_list'.$i)); ?></h6>
                    <?php }?>
                  </li>
                </ul>                               
            <?php }?>
          </div>          
          <div class="choose-btn text-center text-lg-left text-md-left">            
            <?php if(get_theme_mod('cyber_security_services_pro_choose_us_btn_url')!='' || get_theme_mod('cyber_security_services_pro_choose_us_btn')!='' ){ ?>
              <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_choose_us_btn_url')); ?>" class="choose-read-btn btn mb-2">
                <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_btn')); ?></span>
              </a>                                
            <?php }?>
          </div>
        </div>
      </div>
      <div class="col-lg-5 col-md-8 col-12">
        <div class="chos-img-box">
          <?php if(get_theme_mod('cyber_security_services_pro_choose_us_image')!=''){ ?>
            <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_choose_us_image')); ?>">
          <?php } ?>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-12 px-0 align-self-center">
        <div class="choose-right-list text-center text-lg-left text-md-left">
          <?php if(get_theme_mod('cyber_security_services_pro_choose_us_right_head')!=''){ ?>
            <h6 class="choose-right-head px-2 py-3">
          <?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_right_head')); ?>
            </h6>
          <?php } ?>
          <div class="chos-checklist2 p-3">
            <?php $choose2=get_theme_mod('cyber_security_services_pro_choose_us_increase2');
                for($i=1 ; $i<=$choose2; $i++) { ?>       
              <ul class="chos-under2 mb-0 pl-3">
                <li>
                  <?php if(get_theme_mod('cyber_security_services_pro_choose_us_right_list'.$i)!=''){ ?>
                    <h6 class="choslist1">                
                  <?php esc_html_e(get_theme_mod('cyber_security_services_pro_choose_us_right_list'.$i)); ?></h6>
                  <?php }?>
                </li>
              </ul>                               
            <?php }?>
          </div>
        </div>        
      </div>
    </div>      
  </div>
</section>