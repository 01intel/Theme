<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_testimonials_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_testi_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_testi_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_testi_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_testi_bgimage')).'\')';
}else{
  $about_backg = '';
} 
?>
<section id="testimonials" class="py-5" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container reveal">
    <div class="testi-head text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_testimonials_small_head')!=''){ ?>
        <h6 class="testi-sm-head mx-auto px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_testimonials_small_head')); ?></h6>
      <?php }?>
      <?php if(get_theme_mod('cyber_security_services_pro_testimonials_heading')!=''){ ?>
        <h2 class="testi-main-head text-effect"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_testimonials_heading')); ?></h2>
      <?php }?>      
    </div> 
    <div class="owl-carousel">
      <?php $testimonials=get_theme_mod('cyber_security_services_pro_testimonials_increase');
        for($i=1 ; $i<=$testimonials; $i++) { ?>
          <div class="testi-box p-4 m-2 mt-5">            
            <div class="row">
              <div class="col-lg-2 col-md-4 col-4 px-md-0">
                  <?php if(get_theme_mod('cyber_security_services_pro_testimonials_image'.$i)!=''){ ?>
                    <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_testimonials_image'.$i)); ?>" class="testi-img">
                  <?php }?>
              </div>
              <div class="col-lg-8 col-md-4 col-6 align-self-center">
                  <?php if(get_theme_mod('cyber_security_services_pro_testimonials_member_name'.$i)!=''){ ?>
                    <h3 class="testi-name pb-0"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_testimonials_member_name'.$i)); ?></h3>
                  <?php }?>
                  <?php if(get_theme_mod('cyber_security_services_pro_testimonials_member_designation'.$i)!=''){ ?>
                    <h6 class="testi-desig pt-1"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_testimonials_member_designation'.$i)); ?></h6>
                  <?php }?>
              </div>
              <div class="col-lg-2 col-md-4 col-2 testi-quote">
                <?php if(get_theme_mod('cyber_security_services_pro_testi_quote_icon'.$i)!=''){ ?> 
                  <i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_testi_quote_icon'.$i)); ?> test-quote1"></i>
                <?php } ?>
              </div>
            </div>
            <?php if(get_theme_mod('cyber_security_services_pro_testimonials_client_text'.$i)!=''){ ?>
              <p class="testi-text text-justify py-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_testimonials_client_text'.$i)); ?></p>
            <?php }?>
            <?php if(get_theme_mod('cyber_security_services_pro_testi_quote_icon'.$i)!=''){ ?> 
                  <i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_testi_quote_icon'.$i)); ?> test-quote2"></i>
                <?php } ?>            
          </div>
      <?php }?>
    </div>    
  </div>  
</section>