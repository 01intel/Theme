<?php 
$section_hide = get_theme_mod( 'cyber_security_services_pro_slider_enabledisable' );
if ( 'Disable' == $section_hide ) {
  return;
}

$number = get_theme_mod('cyber_security_services_pro_slide_number'); 
$slide_delay = get_theme_mod('cyber_security_services_pro_slide_delay'); 
  if($number != ''){
?>

<section id="slider">
  <div id="carouselExampleIndicators" class="carousel slide <?php if ( get_theme_mod('cyber_security_services_pro_slide_remove_fade',true) == 1 ) { ?> carousel-fade <?php } ?>" data-ride="carousel" data-interval="<?php echo esc_attr($slide_delay); ?>">
    <div class="carousel-inner" role="listbox">
      <?php for ($i=1; $i<=$number; $i++) { ?>
        <div <?php if($i == 1){echo 'class="carousel-item active"';} else{ echo 'class="carousel-item"';}?>>
          <div class="slider-main-box w-100">
            <div class="row h-100">
              <div class="slide-img">
                <?php if(get_theme_mod('cyber_security_services_pro_slide_image'.$i)!=''){ ?> 
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_slide_image'.$i)); ?>">
              </div>             
              <div class="inner_carousel">                
                <div class="slider-box">
                  <?php if(get_theme_mod('cyber_security_services_pro_slide_small_heading'.$i)!=''){ ?>
                    <h6 class="slide-sm-head px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_slide_small_heading'.$i)); ?> 
                    </h6>
                  <?php }?> 
                  <?php if(get_theme_mod('cyber_security_services_pro_slide_heading'.$i)!=''){ ?>
                    <h1 class="slide-head py-lg-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_slide_heading'.$i)); ?>                         
                    </h1>
                  <?php }?>
                  <?php if(get_theme_mod('cyber_security_services_pro_slide_text'.$i)!=''){ ?>
                    <p class="slide-txt"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_slide_text'.$i)); ?>                         
                    </p>
                  <?php }?>
                  <div class="slide_btn py-lg-3">
                    <?php if(get_theme_mod('cyber_security_services_pro_slide_start_btn_url'.$i)!='' || get_theme_mod('cyber_security_services_pro_slide_start_btn'.$i)!='' || get_theme_mod('cyber_security_services_pro_slide_quote_btn_url'.$i)!='' || get_theme_mod('cyber_security_services_pro_slide_quote_btn'.$i)!=''){ ?>
                    <div class="double-btn">               
                      <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_slide_start_btn_url'.$i)); ?>" class="slid-start-btn btn mr-3 mb-lg-0 mb-2 mb-md-0">
                        <span><?php esc_html_e(get_theme_mod('cyber_security_services_pro_slide_start_btn'.$i)); ?></span></a>
                      <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_slide_quote_btn_url'.$i)); ?>" class="slid-quote-btn">
                        <span><?php esc_html_e(get_theme_mod('cyber_security_services_pro_slide_quote_btn'.$i)); ?></span></a>
                    </div>                        
                      <?php }?>
                  </div>                 
                </div>
              </div>             
                <?php }?>                 
            </div> 
          </div>
        </div>
     <?php } ?>
    </div>
    <?php if ( get_theme_mod('cyber_security_services_pro_slider_dots',true) == "1" ) { ?>
          <ol class="carousel-indicators">
            <?php for($i=1;$i<=$number;$i++){ ?>
              <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo($i-1); ?>" class="<?php if($i==1){echo 'active';} ?> "><span class="ci_inner"><a class="slid-dot"><?php { echo '0'.$i; }?></a></span></li>
            <?php } ?>
          </ol>  
        <?php } ?>
    <?php if ( get_theme_mod('cyber_security_services_pro_slider_arrows',true) != "" ) {?>
      <div class="carousel-control">
        <a class="nav1" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"><i class="fas fa-chevron-left"></i></span>
          <span class="sr-only"><?php esc_html_e('Previous','cyber-security-services-pro'); ?></span>
        </a>
        <a class="nav2" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"><i class="fas fa-chevron-right"></i></span>
          <span class="sr-only"><?php esc_html_e('Next','cyber-security-services-pro'); ?></span>
        </a>
      </div>
    <?php } ?>
  </div>
  <div class="clearfix"></div>
</section>
<?php } ?>