<?php

  $section_hide = get_theme_mod( 'cyber_security_services_pro_our_video_enable' );
  if ( 'Disable' == $section_hide ) {
    return;
  }
  
if( get_theme_mod('cyber_security_services_pro_our_video_bgcolor') ) {
  $video_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_our_video_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_our_video_bgimage') ){
  $video_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_our_video_bgimage')).'\')';
}else{
  $video_backg = '';
}

?>
<section id="our_video" class="py-lg-5 py-2" > 
  <div class="vid-inn-bg" style="<?php echo esc_attr($video_backg); ?>">
    <div class="container-fluid reveal">
      <div class="row">
        <div class="col-lg-6 col-md-12 col-12 align-self-center">
          <div class="video-head px-lg-5 mr-3 text-center text-lg-left text-md-center">
            <?php if(get_theme_mod('cyber_security_services_pro_our_video_small_head')!=''){ ?>
              <h6 class="video-sm-head px-3 mt-3 mt-md-4 mt-lg-2"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_our_video_small_head')); ?>
              </h6>     
            <?php } ?>
            <?php if(get_theme_mod('cyber_security_services_pro_our_video_main_heading')!=''){ ?>
              <h2 class="video-main-head py-3"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_our_video_main_heading')); ?>
              </h2>     
            <?php } ?>
            <?php if(get_theme_mod('cyber_security_services_pro_our_video_text')!=''){ ?>
              <p class="video-text"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_our_video_text')); ?>
              </p>     
            <?php } ?>
          </div>
          <div class="video-navigation px-lg-5">
            <?php if(get_theme_mod('cyber_security_services_pro_our_video_nav_txt')!=''){ ?>
              <h6 class="video-nav-text"><?php echo esc_html(get_theme_mod('cyber_security_services_pro_our_video_nav_txt')); ?>
              </h6>     
            <?php } ?>
          </div>
        </div>
        <div class="col-lg-6 col-md-12 col-12 pr-0">
          <div class="owl-carousel">
            <?php $video=get_theme_mod('cyber_security_services_pro_our_video_increase');
              for($i=1 ; $i<=$video; $i++) { ?>       
              <div class="demo-video">
                <div class="video-img-box">
                  <?php if(get_theme_mod('cyber_security_services_pro_our_video_image'.$i)!=''){ ?>
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_our_video_image'.$i)); ?>">        
                </div>
                <a class="popup-youtube pr-3 pl-4 py-3" href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_our_video_btn_url'.$i)); ?>"><i class="fas fa-play" aria-hidden="true">&nbsp;</i>
                </a>
                <script>
                  $(document).ready(function() {
                  $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
                    disableOn: 700,
                    type: 'iframe',
                    mainClass: 'mfp-fade',
                    removalDelay: 160,
                    preloader: false,

                    fixedContentPos: false
                    });
                  });
                </script>
                <?php }?>              
              </div>            
            <?php }?>
          </div>
        </div>
      </div>            
    </div>
  </div> 
</section>