<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_our_services_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_our_services_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_our_services_bgcolor')).' !important;';
}elseif( get_theme_mod('cyber_security_services_pro_our_services_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_our_services_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="our_services" class="py-5 mb-4" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container reveal">
		<div class="serv-head text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_our_services_small_head')!=''){ ?>
        <h6 class="service-sm-head mx-auto px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_our_services_small_head')); ?></h6>
  		<?php } if(get_theme_mod('cyber_security_services_pro_our_services_heading')!=''){ ?>
    		<h2 class="service-main-head py-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_our_services_heading')); ?></h2>
  		<?php }?>  		
		</div>
		<div class="serv-group py-4"> 
      <div class="row">              
        <?php
          $i=1;
          $args = array(
            'post_type' => 'service',
            'post_status' => 'publish',
            'posts_per_page' => get_theme_mod('cyber_security_services_pro_services_post_number')
          );
          $new = new WP_Query($args); 
          $loop_index = 0;
          while ( $new->have_posts() ){
          $new->the_post(); 
        ?>           
        <div class="col-lg-4 col-md-6 col-12">      
          <div class="service-opacity p-4 mb-4">
            <div class="row icon-serv">
              <div class="col-lg-6 col-md-6 col-5">
                <?php if(has_post_thumbnail()) { the_post_thumbnail(); }
                  else { ?><img src="<?php echo esc_url(get_template_directory_uri()).'images/services/service.png'?>">  
                <?php }?>                  
              </div>
              <div class="col-lg-6 col-md-6 col-7 px-0">
                <a href="<?php the_permalink(); ?>" class="serv-inn-btn">
                  <span><?php esc_html_e('Read More','cyber-security-services-pro');?><i class="fa-solid fa-angle-right ser-arr ml-1"></i></span>
                </a>
              </div>
            </div>
            <div class="serv-box text-center text-lg-left text-md-left">               
              <h5 class="serv-name pt-4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
              <p class="serv-inn-txt mb-0"><?php echo esc_html(wp_trim_words(get_the_content(),'50') );?></p>
            </div>
          </div>   
        </div>
        <?php } ?>         
      </div>           
    </div>
    <div class="serv-outer-btn text-center">
      <?php if(get_theme_mod('cyber_security_services_pro_services_outer_btn_url')!='' || get_theme_mod('cyber_security_services_pro_services_outer_btn')!='' ){ ?>
        <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_services_outer_btn_url')); ?>" class="serv-outr-btn btn">
          <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_services_outer_btn')); ?></span>
        </a>                                
      <?php }?>
    </div>								
	</div>
</section>