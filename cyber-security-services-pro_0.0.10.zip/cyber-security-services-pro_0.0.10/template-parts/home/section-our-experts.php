<?php 
$about_section = get_theme_mod( 'cyber_security_services_pro_our_experts_enable' );
if ( 'Disable' == $about_section ) {
  return;
}
if( get_theme_mod('cyber_security_services_pro_our_experts_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_our_experts_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_our_experts_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_our_experts_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>
<section id="our_experts" class="py-lg-5 py-2 text-center"> 
  <div class="staff-bg" style="<?php echo esc_attr($about_backg); ?>">
    <div class="staff-head py-4">
      <?php if(get_theme_mod('cyber_security_services_pro_our_experts_small_head')!=''){ ?>
        <h6 class="staff-sm-head mx-auto px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_our_experts_small_head')); ?></h6>
      <?php }?>     
      <?php if(get_theme_mod('cyber_security_services_pro_our_experts_heading')!=''){ ?>
        <h2 class="staff-main-head py-3"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_our_experts_heading')); ?></h2>
      <?php }?>
    </div> 
    <div class="container">
      <div class="staff-group">
        <div class="owl-carousel">
          <?php
              $i=1;
              $args = array(
                'post_type' => 'our_experts',
                'post_status' => 'publish',
                'posts_per_page' => get_theme_mod('cyber_security_services_pro_our_experts_post_number')
              );
              $new = new WP_Query($args); 
              $loop_index = 0;
              while ( $new->have_posts() ){
              $new->the_post(); 
            ?>        
            <div class="staff-box">
              <div class="row">
                <div class="col-lg-2 col-md-2 col-3 px-0 px-md-1">
                  <div class="box-content">
                    <hr class="exper-hr mx-auto mt-0">
                    <div class="staff-social-icon"> 
                      <?php if(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_facebook',true)) { ?>
                        <a href="<?php echo esc_html(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_facebook',true)); ?>" class="exfb-circle"><i class="fab fa-facebook-f"></i>
                        </a>
                      <?php } ?>
                      <?php if(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_twitter',true)) { ?>
                        <a href="<?php echo esc_html(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_twitter',true)); ?>" class="extwt-circle"><i class="fa-brands fa-twitter"></i>
                        </a>
                      <?php } ?>
                      <?php if(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_googleplus',true)) { ?>
                        <a href="<?php echo esc_html(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_googleplus',true)); ?>" class="exg-circle"><i class="fa-brands fa-google-plus-g"></i>
                        </a>
                      <?php } ?>
                                        
                      <?php if(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_whatsapp',true)) { ?>
                        <a href="<?php echo esc_html(get_post_meta($post->ID,'cyber_security_services_pro_our_experts_social_whatsapp',true)); ?>" class="exwa-circle"><i class="fa-brands fa-whatsapp"></i>
                        </a>
                      <?php } ?>                           
                    </div>                                   
                  </div>
                </div>
                <div class="col-lg-10 col-md-10 col-9 pl-0">
                  <div class="team-bg">
                    <?php if(has_post_thumbnail()) { the_post_thumbnail(); }
                      else { ?><img src="<?php echo esc_url(get_template_directory_uri()).'images/team/team.png'?>">  
                    <?php }?>
                  </div>
                  <div class="staff-info py-2 text-left">
                    <h5 class="staff-name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>            
                    <p class="staff-desig mb-0"><?php echo esc_html(wp_trim_words(get_the_content(),'15') );?></p>                        
                  </div>
                </div>
              </div>         
            </div>
          <?php } ?>
        </div>
      </div>
      <div class="expert-outer-btn text-center pt-5 pb-3">
        <?php if(get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_url')!='' || get_theme_mod('cyber_security_services_pro_our_experts_outer_btn')!='' ){ ?>
          <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_url')); ?>" class="exper-outr-btn btn">
            <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_our_experts_outer_btn')); ?></span>
          </a>                                
        <?php }?>
      </div>  
    </div>
  </div>
</section>