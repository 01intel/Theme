<?php
/**
 * Template part for displaying Top Bar Content
 *
 * @package cyber-security-services-pro
 */ 

$topbar_section = get_theme_mod( 'cyber_security_services_pro_topbar_enable' );
if ( 'Disable' == $topbar_section ) {
  return;
}

if( get_theme_mod('cyber_security_services_pro_topbar_bgcolor') ) { 
  $topbar_section = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_topbar_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_topbar_bgimage') ){
  $topbar_section = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_topbar_bgimage')).'\')';
}else{
  $topbar_section = '';
}
?>

<div id="topbar_section" style="<?php echo esc_attr($topbar_section); ?>">
  <div class="container">
    <div class="row py-2">
      <div class="col-lg-3 col-md-4 col-12 top-logo align-self-center text-center">
        <div class="logo">
            <?php
           if( has_custom_logo() ){  cyber_security_services_pro_the_custom_logo();  } 
              $logo= get_theme_mod( 'custom_logo' );
              if($logo){ ?>
                <div class="logo-text">
                  <?php if( get_theme_mod('cyber_security_services_pro_display_title', true) != ''){ ?>
                    <h2><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php esc_attr(bloginfo( 'name' )); ?></a></h2>
                  <?php }
                    if( get_theme_mod('cyber_security_services_pro_display_tagline', true) != ''){ 
                    $description = get_bloginfo( 'description', 'display' );
                    if ( $description || is_customize_preview() ) : ?>
                    <p>
                      <?php echo esc_html($description); ?>
                    </p>
                  <?php endif; } 
                  ?>
                </div>
            <?php } else { ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/cyberlogo.png" alt="<?php bloginfo( 'name' ); ?>"/></a>  
            <?php }?>          
          </div>
        <!-- <div class="logo">
            <?php
             if( has_custom_logo() ){  cyber_security_services_pro_the_custom_logo();  } 
                $logo= get_theme_mod( 'custom_logo' );
                if($logo){ ?>
                  <div class="logo-text">
                    <?php if( get_theme_mod('cyber_security_services_pro_display_title', true) != ''){ ?>
                      <h2><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php esc_attr(bloginfo( 'name' )); ?></a></h2>
                    <?php }
                      if( get_theme_mod('cyber_security_services_pro_display_tagline', true) != ''){ 
                      $description = get_bloginfo( 'description', 'display' );
                      if ( $description || is_customize_preview() ) : ?>
                      <p>
                        <?php echo esc_html($description); ?>
                      </p>
                    <?php endif; } 
                    ?>
                  </div>
            <?php } else {
              if(get_theme_mod('cyber_security_services_pro_display_title', true) != '' || get_theme_mod('cyber_security_services_pro_display_tagline', true) != '') {
             ?>
             <div class="logo-text">
                    <?php if( get_theme_mod('cyber_security_services_pro_display_title', true) != ''){ ?>
                      <h2><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php esc_attr(bloginfo( 'name' )); ?></a></h2>
                    <?php }
                      if( get_theme_mod('cyber_security_services_pro_display_tagline', true) != ''){ 
                      $description = get_bloginfo( 'description', 'display' );
                      if ( $description || is_customize_preview() ) : ?>
                      <p>
                        <?php echo esc_html($description); ?>
                      </p>
                    <?php endif; } 
                    ?>
                  </div>
                <?php } else { ?>
              <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/cyberlogo.png" alt="<?php bloginfo( 'name' ); ?>"/></a> <?php } ?>
            <?php }?>          
        </div> -->     
      </div>
      <div class="col-lg-6 col-md-2 col-2 align-self-center text-right pr-0">
        <?php get_template_part( 'template-parts/header/navigation' ); ?>
      </div>
      <div class="col-lg-1 col-md-1 col-1 tobar-search align-self-center">
        <?php if(get_theme_mod('cyber_security_services_pro_search_enable',true)=='1'){ ?>
            <div class="header-search">
              <div class="header-search-wrapper">
                <span class="search-main">
                  <?php if(get_theme_mod('cyber_security_services_pro_header_search_icon')!=''){ ?> 
                      <i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_header_search_icon')); ?>"></i>
                  <?php } ?>
                </span>
                <div class="search-form-main clearfix">
                  <?php if ( shortcode_exists( 'wpbsearch' ) ) { ?><span><?php echo do_shortcode('[wpbsearch]'); ?></span><?php }?>
                </div>
              </div>
            </div>
        <?php } ?>        
      </div>
      <div class="col-lg-2 col-md-4 col-7 topbar-social align-self-center px-0 text-center">
        <?php get_template_part('template-parts/home/social-icons'); ?>
      </div>           
    </div>
  </div>
</div>