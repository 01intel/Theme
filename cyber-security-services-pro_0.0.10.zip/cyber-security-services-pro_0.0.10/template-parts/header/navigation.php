<?php
/**
 * Template part for displaying menus
 *
 * @package cyber_security_services_pro
 */
?>

<div class="menubar m-0 mt-md-0">
  <div class="innermenubox">
    <div class="toggle-nav mobile-menu text-center text-md-center my-2 mb-md-0">
      <span onclick="cyber_security_services_pro_openNav()"><i class="fas fa-bars p-2"></i></span>
    </div>
    <div id="mySidenav" class="nav sidenav">
      <nav id="site-navigation" class="main-navigation">
        <a href="javascript:void(0)" class="closebtn mobile-menu" onclick="cyber_security_services_pro_closeNav()"><i class="fas fa-times"></i></a>
        <?php 
          wp_nav_menu( array( 
            'theme_location' => 'primary',
            'container_class' => 'menu clearfix' ,
            'menu_class' => 'clearfix',
            'items_wrap' => '<ul id="%1$s" class="%2$s mobile_nav">%3$s</ul>',
            'fallback_cb' => 'wp_page_menu',
          ) ); 
        ?>
      </nav>
    </div>
  </div>
</div>