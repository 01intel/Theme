<?php

$page_title_style="";
if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Center'){
    $page_title_style='text-align:center;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Left')
{
	$page_title_style='text-align:left;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Right')
{
	$page_title_style='text-align:right;';
}else{
	$page_title_style='';
}

if ( ! is_singular() ) {
	return;
}
global $post;
$img = get_post_meta($post->ID, 'ot_title_banner_image_wp_custom_attachment', true);
$display = '';
$display_title_bbanner = '';
$ot_title_banner_image_title_on_off = get_post_meta($post->ID, 'ot_title_banner_image_title_on_off', true);
if($ot_title_banner_image_title_on_off == 'on') $display = 'style=display:none;';
$ot_title_banner_image_title_below_on_off = get_post_meta($post->ID, 'ot_title_banner_image_title_below_on_off', true);
if($ot_title_banner_image_title_below_on_off != 'on') $display_title_bbanner = 'style=display:none;';
if( $img != '' ){ ?>
	<div class="title-box">
		<div class="container" <?php echo esc_attr($display); ?>>
			<div class="above_title" style="<?php echo esc_attr($page_title_style); ?>">
				<h1><?php the_title();?></h1>
			</div>
			<?php if ( get_theme_mod('ot_eco_nature_pro_site_breadcrumb_enable', true) == "1" ) { ?> 
	            <?php if ( defined( 'OTBC_VERSION' ) ) { echo do_shortcode( '[ot-breadcrumb]' ); } ?>
		    <?php } ?>
		</div>
		<img src="<?php echo esc_url($img); ?>" >
	</div>
	<div class="container main_title" <?php echo esc_attr($display_title_bbanner); ?>>
		<h1 style="<?php echo esc_attr($page_title_style); ?>"><?php the_title();?></h1>
		<?php if ( get_theme_mod('ot_eco_nature_pro_site_breadcrumb_enable', true) == "1" ) { ?> 
            <?php if ( defined( 'OTBC_VERSION' ) ) { echo do_shortcode( '[ot-breadcrumb]' ); } ?>
	    <?php } ?>
	</div>
<?php }else{ ?>
	<div class="container main_title" style="<?php echo esc_attr($page_title_style); ?>">
		<h1><?php the_title();?></h1>
		<?php if ( get_theme_mod('ot_eco_nature_pro_site_breadcrumb_enable', true) == "1" ) { ?> 
            <?php if ( defined( 'OTBC_VERSION' ) ) { echo do_shortcode( '[ot-breadcrumb]' ); } ?>
	    <?php } ?>
	</div>
<?php } ?>