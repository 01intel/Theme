<?php
/**
 * Template part for displaying Post Content
 *
 * @package cyber_security_services_pro
 */
$cyber_security_services_pro_year  = get_the_time('Y'); 
$cyber_security_services_pro_month = get_the_time('m'); 
$cyber_security_services_pro_day   = get_the_time('d'); 

?>

<div id="single_post" class="col-lg-6 col-md-6 col-sm-12"> 
  <div class="news-box my-4">
    <?php if (has_post_thumbnail()){ ?>
    <div class="img-box mb-3">      
      <?php the_post_thumbnail(); ?>        
    </div>    
    <?php } ?>

          <div class="lower-new-box px-4 py-3">
            <?php if ( get_theme_mod('cyber_security_services_pro_post_general_settings_post_author',true) == "1" ) { ?>
            <span class="entry-author mr-2"><i class="far fa-user mr-2"></i><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a></span>
            <?php } ?>
            <?php if ( get_theme_mod('cyber_security_services_pro_post_general_settings_post_comments',true) == "1" ) { ?>
            <span class="entry-comments"><i class="fas fa-comments mr-2"></i> <?php comments_number( __('0 Comments','cyber-security-services-pro'), __('0 Comments','cyber-security-services-pro'), __('% Comments','cyber-security-services-pro')); ?></span>
          <?php } ?>
          <?php if ( get_theme_mod('cyber_security_services_pro_post_general_settings_post_date',true) == "1" ) { ?>
        <span class="news-datebox text-center">         
            <i class="fa-regular fa-calendar-days mx-2"></i><?php esc_html_e(' ','cyber-security-services-pro'); echo '<span class="date-day">' . get_the_date( 'd' ) . '</span>'; echo ' <span class="date-month">' . get_the_date( 'M' ) . '</span>'; echo ' <span class="date-year">' . get_the_date( 'Y' ) . '</span>' ?>         
        </span>
        <?php } ?>
            
            <h5 class="pt-4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
            <p><?php echo esc_html(wp_trim_words(get_the_content(),'15') );?></p>          
          </div>
  </div>
</div>