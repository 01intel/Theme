<?php

	// GLOBAL COLOR
	$cyber_security_services_pro_global_bgcolor = get_theme_mod('cyber_security_services_pro_global_bgcolor');

	// GLOBAL GRADIANT COLOR
   	$cyber_security_services_pro_global_gradiant_1 = get_theme_mod('cyber_security_services_pro_global_gradiant_1');
	$cyber_security_services_pro_global_gradiant_2 = get_theme_mod('cyber_security_services_pro_global_gradiant_2');
	$cyber_security_services_pro_gradient_angle = get_theme_mod('cyber_security_services_pro_gradient_angle');
	$cyber_security_services_pro_gradient_sides = get_theme_mod('cyber_security_services_pro_gradient_sides');

	// GLOBAL FONTS
	$cyber_security_services_pro_global_heading_font = get_theme_mod('cyber_security_services_pro_global_heading_font');
	$cyber_security_services_pro_global_text_font = get_theme_mod('cyber_security_services_pro_global_text_font');
	
    $custom_css ='';

	// GLOBAL COLOR

	if($cyber_security_services_pro_global_bgcolor != false) {
		$custom_css .='#slider span.carousel-control-next-icon:hover,#slider span.carousel-control-prev-icon:hover,.slide_btn a,.about-box h5,.abou_btn a,.about_box_img,#brands,#testimonials button.owl-dot.active,#counter,#about button.owl-dot.active,.box-content h4:hover,.date-month,#latest_news button.owl-dot.active,#volunteer button.owl-dot.active,.project_btn a,.topbar_section,.logo,.main-navigation li:after,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus,.widget_calendar tbody a,#return-to-top,#sidebar .tagcloud a:hover,.site-footer .tagcloud a:hover,#sidebar input[type="submit"],.woocommerce ul.products li.product .onsale, .woocommerce span.onsale,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,nav.woocommerce-MyAccount-navigation ul li,.volunteer_btn a,.career_btn a,.load :first-child,.load :nth-child(2),.load :nth-child(3),.load :last-child,#company_info button.owl-dot.active,input[type="submit"],#about button.owl-prev, #about button.owl-next{';
			if($cyber_security_services_pro_global_bgcolor != false)
				$custom_css .='background: '.esc_html($cyber_security_services_pro_global_bgcolor).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_bgcolor != false) {
		$custom_css .='a,.client-box h5 span,.client-box i.fas.fa-quote-right,#brands button.owl-prev:hover, #brands button.owl-next:hover,.about-box h6,.contact-info-box h4,.lower-new-box i,.title-box h2,.header-info h6,.header-info i,.main-navigation .current_page_item > a,.main-navigation .current-menu-item > a,.main-navigation a:hover,.main-navigation ul ul li:hover > a,#footer ul li a:hover,#sidebar caption,#sidebar td,#sidebar th,#sidebar select ,#sidebar td#prev a,a.showcoupon,.woocommerce-message::before,.box-button a,.service_btn a,.toggle-nav i,.search-icon i,body a{';
			if($cyber_security_services_pro_global_bgcolor != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_global_bgcolor).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_bgcolor != false) {
		$custom_css .='.about-box h3 span{';
			if($cyber_security_services_pro_global_bgcolor != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_global_bgcolor).'!important;';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_bgcolor != false) {
		$custom_css .='#slider span.carousel-control-prev-icon, .contact-info-box,#slider span.carousel-control-next-icon,.info-box hr, #service hr, #testimonials hr, #about hr, .contact-info-box hr, #latest_news hr, #projects hr, #our_video hr,.client-box img,.box-button a, .service_btn a{';
			if($cyber_security_services_pro_global_bgcolor != false)
				$custom_css .='border-color: '.esc_html($cyber_security_services_pro_global_bgcolor).';';
	   	$custom_css .='}';
   	}

   	// GLOBAL GRADIANT COLOR

    $gradient_option = get_theme_mod( 'cyber_security_services_pro_global_gradient_options','linear-gradient');
	
	if($gradient_option == 'linear-gradient'){ 

   	if($cyber_security_services_pro_global_gradiant_1 != false || $cyber_security_services_pro_global_gradiant_2 != false){
		$custom_css .='#slider span.carousel-control-next-icon:hover,#slider span.carousel-control-prev-icon:hover,.slide_btn a,.about-box h5,.abou_btn a,.about_box_img,#brands,#testimonials button.owl-dot.active,#counter,#about button.owl-dot.active,.box-content h4:hover,.date-month,#latest_news button.owl-dot.active,#volunteer button.owl-dot.active,.project_btn a,.topbar_section,.logo,.main-navigation li:after,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus,.widget_calendar tbody a,#return-to-top,#sidebar .tagcloud a:hover,.site-footer .tagcloud a:hover,#sidebar input[type="submit"],.woocommerce ul.products li.product .onsale, .woocommerce span.onsale,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,nav.woocommerce-MyAccount-navigation ul li,.volunteer_btn a,.career_btn a,.load :first-child,.load :nth-child(2),.load :nth-child(3),.load :last-child,#company_info button.owl-dot.active,input[type="submit"],#about button.owl-prev, #about button.owl-next{
			background-image: linear-gradient('.esc_attr($cyber_security_services_pro_gradient_angle).'deg, '.esc_html($cyber_security_services_pro_global_gradiant_1).' , '.esc_html($cyber_security_services_pro_global_gradiant_2).');
		}';
	}

	} else if($gradient_option == 'radial-gradient'){

   	if($cyber_security_services_pro_global_gradiant_1 != false || $cyber_security_services_pro_global_gradiant_2 != false){
		$custom_css .='#slider span.carousel-control-next-icon:hover,#slider span.carousel-control-prev-icon:hover,.slide_btn a,.about-box h5,.abou_btn a,.about_box_img,#brands,#testimonials button.owl-dot.active,#counter,#about button.owl-dot.active,.box-content h4:hover,.date-month,#latest_news button.owl-dot.active,#volunteer button.owl-dot.active,.project_btn a,.topbar_section,.logo,.main-navigation li:after,.widget_calendar tbody a:hover,.widget_calendar tbody a:focus,.widget_calendar tbody a,#return-to-top,#sidebar .tagcloud a:hover,.site-footer .tagcloud a:hover,#sidebar input[type="submit"],.woocommerce ul.products li.product .onsale, .woocommerce span.onsale,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,nav.woocommerce-MyAccount-navigation ul li,.volunteer_btn a,.career_btn a,.load :first-child,.load :nth-child(2),.load :nth-child(3),.load :last-child,#company_info button.owl-dot.active,input[type="submit"],#about button.owl-prev, #about button.owl-next{
			background-image: radial-gradient(ellipse at '.esc_html($cyber_security_services_pro_gradient_sides).', '.esc_html($cyber_security_services_pro_global_gradiant_1).' , '.esc_html($cyber_security_services_pro_global_gradiant_2).');
		}';
	}

	}

	if($cyber_security_services_pro_global_gradiant_1 != false) {
		$custom_css .='.client-box h5 span,.client-box i.fas.fa-quote-right,#brands button.owl-prev:hover, #brands button.owl-next:hover,.about-box h6,.contact-info-box h4,.lower-new-box i,.title-box h2,.header-info h6,.header-info i,.main-navigation .current_page_item > a,.main-navigation .current-menu-item > a,.main-navigation a:hover,.main-navigation ul ul li:hover > a,#footer ul li a:hover,#sidebar caption,#sidebar td,#sidebar th,#sidebar select ,#sidebar td#prev a,a.showcoupon,.woocommerce-message::before,.box-button a, .service_btn a,.toggle-nav i,.search-icon i,body a{';
			if($cyber_security_services_pro_global_gradiant_1 != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_global_gradiant_1).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_gradiant_1 != false) {
		$custom_css .='.about-box h3 span{';
			if($cyber_security_services_pro_global_gradiant_1 != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_global_gradiant_1).'!important;';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_gradiant_1 != false || $cyber_security_services_pro_global_gradiant_2 != false){
		$custom_css .='#slider span.carousel-control-prev-icon, .contact-info-box, #slider span.carousel-control-next-icon, .info-box hr, #service hr, #testimonials hr, #about hr, .contact-info-box hr, #latest_news hr, #projects hr, #our_video hr,.client-box img,.box-button a, .service_btn a{
			border-image: linear-gradient(to right, '.esc_html($cyber_security_services_pro_global_gradiant_1).' , '.esc_html($cyber_security_services_pro_global_gradiant_2).');
			border-image-slice: 1;
		}';
	}

	// GLOBAL FONTS

	if($cyber_security_services_pro_global_heading_font != false) {
		$custom_css .='h1,h2,h3,h4,h5,h6{';
			if($cyber_security_services_pro_global_heading_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_global_heading_font).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_global_text_font != false) {
		$custom_css .='html body{';
			if($cyber_security_services_pro_global_text_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_global_text_font).';';
	   	$custom_css .='}';
   	}