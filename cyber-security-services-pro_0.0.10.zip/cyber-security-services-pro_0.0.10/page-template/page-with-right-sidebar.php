<?php
/**
 * Template Name:Page with Right Sidebar
 */
$page_title_style="";
if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Center'){
    $page_title_style='text-align:center;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Left')
{
    $page_title_style='text-align:left;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Right')
{
    $page_title_style='text-align:right;';
}else{
    $page_title_style='';
}
get_header();
if( get_theme_mod('cyber_security_services_pro_pages_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_pages_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_pages_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_pages_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>

<?php do_action('cyber_security_services_pro_before_page'); ?>

<div class="title-box mb-5 text-center" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
    <?php while ( have_posts() ) : the_post(); ?>
      <h2 style="<?php echo esc_attr($page_title_style); ?>" class="py-5"><?php the_title(); ?></h2>
    <?php endwhile; ?>
  </div>
</div>

<div class="container">
    <div class="middle-align">
      <div class="row">
        <div class="col-lg-8 col-md-7 content_page">
          <?php while ( have_posts() ) : the_post(); ?>
             <?php the_content();?>
             <?php
             //If comments are open or we have at least one comment, load up the comment template
              if ( comments_open() || '0' != get_comments_number() )
                  comments_template();
             ?>
           <?php endwhile; // end of the loop. ?>
        </div>
         <div class="col-lg-4 col-md-5" id="sidebar">
            <?php  dynamic_sidebar('sidebar-2'); ?>
         </div>
         <div class="clear"></div>
      </div>
    </div>
</div>
<?php do_action('cyber_security_services_pro_after_page'); ?>

<?php get_footer(); ?>