<?php
/**
 * Template Name: Blog Full Page Template
 */
$page_title_style="";
if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Center'){
    $page_title_style='text-align:center;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Left')
{
    $page_title_style='text-align:left;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Right')
{
    $page_title_style='text-align:right;';
}else{
    $page_title_style='';
}
get_header(); ?>

<?php do_action('cyber_security_services_pro_before_blog'); ?>

<div class="title-box mb-5 text-center" style="<?php echo esc_attr($about_backg); ?>">
  <div class="container">
    <?php while ( have_posts() ) : the_post(); ?>
      <h2 style="<?php echo esc_attr($page_title_style); ?>" class="py-5"><?php the_title(); ?></h2>
    <?php endwhile; ?>
  </div>
</div>

<div id="full-width-blog" class="mt-5">
	<div class="container">
    	<div class="content_page row">
			<?php if ( have_posts() ) : ?>
		      	<?php $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
					$args = array(
					   'paged' => $paged,
					   'category_name' => get_theme_mod('cyber_security_services_pro_category_setting')
					);
					$custom_query = new WP_Query( $args );
					while($custom_query->have_posts()) :
					   $custom_query->the_post();
					   	get_template_part( 'template-parts/post/post-content' );
					$p++; endwhile;
					wp_reset_postdata(); ?>
					<div class="navigation">
						<?php 
							$big = 999999999;
							echo paginate_links( array(
								'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
								'format' => 'paged=%#%',
								'current' =>  (get_query_var('paged') ? get_query_var('paged') : 1),
								'total' => $custom_query->max_num_pages
							) );
						?>
					</div>
			<?php else : ?>
				<h3><?php esc_html_e('Not Found','cyber-security-services-pro'); ?></h3>
			<?php endif; ?>
        	<div class="clearfix"></div>
		</div>
        <div class="clearfix"></div>
	</div>
</div>

<?php do_action('cyber_security_services_pro_after_blog'); ?>

<?php get_footer(); ?>