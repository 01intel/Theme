<?php
/**
 * Template Name:Events Template
 */
get_header();

if( get_theme_mod('cyber_security_services_pro_our_gallery_template_bgcolor') ) {
  $events_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_our_gallery_template_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_our_gallery_template_bgimage') ){
  $events_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_our_gallery_template_bgimage')).'\')';
}else{
  $events_backg = '';
}
?>
<?php do_action('cyber_security_services_pro_before_our_gallery_title'); ?>

<div class="title-box mb-5 text-center" style="<?php echo esc_attr($events_backg); ?>">
  <div class="container">
    <?php while ( have_posts() ) : the_post(); ?>
      <h2 class="py-5"><?php the_title(); ?></h2>
    <?php endwhile; ?>
  </div>
</div>
<div class="container">
    <div class="row abt-in">      
      <div class="col-lg-6 col-md-6 col-12">
        <div class="about-img-box">
          <div class="row img-divs text-center">
            <div class="col-lg-6 col-md-6 col-12 pr-1 align-self-center">
              <div class="abt-inn-pic1">
                <?php if(get_theme_mod('cyber_security_services_pro_about_image1')!=''){ ?>
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image1')); ?>">
                <?php }?>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
              <div class="abt-inn-pic2 pb-3">
                <?php if(get_theme_mod('cyber_security_services_pro_about_image2')!=''){ ?>
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image2')); ?>">
                <?php }?>
              </div>
              <div class="abt-inn-pic3">
                <?php if(get_theme_mod('cyber_security_services_pro_about_image3')!=''){ ?>
                  <img src="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_image3')); ?>">
                <?php }?>
              </div>
            </div>
          </div>                    
        </div>                
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <div class="abt-info py-lg-5 py-3 py-md-2">
          <?php if(get_theme_mod('cyber_security_services_pro_about_small_heading')!=''){ ?>
            <h6 class="abt-sm-head px-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_small_heading')); ?></h6>
          <?php }?>       
          <?php if(get_theme_mod('cyber_security_services_pro_about_heading')!=''){ ?>
            <h2 class="abt-main-head text-effect"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_heading')); ?></h2>
          <?php }?>                                 
          <?php if(get_theme_mod('cyber_security_services_pro_about_text')!=''){ ?>
            <p class="abt-para py-lg-3 py-md-1 py-1"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_about_text')); ?></p>
          <?php }?>
          <div class="about-btn">            
            <?php if(get_theme_mod('cyber_security_services_pro_about_btn_url')!='' || get_theme_mod('cyber_security_services_pro_about_btn')!='' ){ ?>
              <a href="<?php echo esc_url(get_theme_mod('cyber_security_services_pro_about_btn_url')); ?>"      class="abt-read-btn btn">
                <span><?php  esc_html_e(get_theme_mod('cyber_security_services_pro_about_btn')); ?></span>
              </a>                                
            <?php }?>
          </div>        
        </div>
      </div>
    </div>  
  </div>
<?php do_action('cyber_security_services_pro_before_footer'); ?>
<?php get_footer(); ?>