<?php
/**
 * Template Name: Contact Page Template
*/

get_header();

if( get_theme_mod('cyber_security_services_pro_contactpage_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_contactpage_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_contactpage_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_contactpage_bgimage')).'\')';
}else{
  $about_backg = '';
}
?>

<?php do_action('cyber_security_services_pro_before_contact_title'); ?>

<div class="title-box mb-5 text-center" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<?php while ( have_posts() ) : the_post(); ?>
			<h2 class="py-5"><?php the_title(); ?></h2>
		<?php endwhile; ?>
	</div>
</div>

<div id="contact-box">
	<div class="container">
		<div class="row innerc">
			<div class="col-lg-6 col-md-6 col-12">
				<div class="contact-info my-5 py-3">
					<!-- <hr class="first my-1 mx-0"> -->
  				<?php if(get_theme_mod('cyber_security_services_pro_contact_heading')!=''){ ?>
  		  		<h3><?php esc_html_e(get_theme_mod('cyber_security_services_pro_contact_heading')); ?></h3>
    			<?php }?>
      		<?php if(get_theme_mod('cyber_security_services_pro_contact_text')!=''){ ?>
        		<p class="mr-lg-5 pr-lg-5 pr-md-5 mr-md-5 pt-4"><?php esc_html_e(get_theme_mod('cyber_security_services_pro_contact_text')); ?></p>
      		<?php }?>
      		<div class="row">
      			<div class="col-lg-1 col-md-1 col-2 call-icon">
          		<?php if(get_theme_mod('cyber_security_services_pro_contact_phone_icon')!=''){ ?> 
          			<i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_phone_icon')); ?> my-4 contactpage-phone-icon"></i>
          		<?php } ?>
    				</div>
            <div class="col-lg-10 col-md-10 col-10  call0 pl-0">
            	<?php if(get_theme_mod('cyber_security_services_pro_contact_call1')!=''|| get_theme_mod('cyber_security_services_pro_contact_call2')!=''){ ?>            
              		<h6 class="pt-3">              
              <?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_call1')); ?><br>
              <?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_call2')); ?>
                	</h6>
              <?php } ?>
        		</div>
      		</div>
        			<?php if(get_theme_mod('cyber_security_services_pro_contact_email')!=''){ ?>      
          			<h6 class="pt-3">
            	<?php if(get_theme_mod('cyber_security_services_pro_contact_email_icon')!=''){ ?> 
            		<i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_email_icon')); ?> mr-2 contactpage-email-icon"></i>
            	<?php } ?>
            		<span><?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_email')); ?></span>
          			</h6>
        			<?php } ?>
        			<?php if(get_theme_mod('cyber_security_services_pro_contact_address')!=''){ ?>    
          		<h6 class="pt-3">
            	<?php if(get_theme_mod('cyber_security_services_pro_contact_address_icon')!=''){ ?> 
            		<i class="<?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_address_icon')); ?> mr-2 contactpage-add-icon"></i>
            	<?php } ?>
            		<span><?php echo esc_html(get_theme_mod('cyber_security_services_pro_contact_address')); ?></span>
          			</h6>
        			<?php } ?>
  			</div> 
			</div>
			<div class="col-lg-6 col-md-6 col-12">
				<div class="contact-section-form py-5 px-4 my-3">
					<?php if(get_theme_mod('cyber_security_services_pro_contactpage_contact_form',true) != ''){ ?>
						<?php echo do_shortcode(get_theme_mod('cyber_security_services_pro_contactpage_contact_form')); ?>
					<?php } ?>
				</div>
    	</div>
		</div>
		<div class="google-map p-0 my-5" id="map">
      		<?php if ( get_theme_mod('cyber_security_services_pro_contact_latitude',true) != "" && get_theme_mod('cyber_security_services_pro_contact_longitude',true) != "" ) {?>
	        	<embed width="100%" height="650" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=<?php echo esc_attr(get_theme_mod('cyber_security_services_pro_contact_latitude')); ?>,<?php echo esc_attr(get_theme_mod('cyber_security_services_pro_contact_longitude')); ?>&hl=es;z=14&amp;output=embed"></embed>
	      	<?php }?>
    	</div>
	</div>
</div>	
	
</div>
<?php do_action('cyber_security_services_pro_before_footer'); ?>

<?php get_footer(); ?>