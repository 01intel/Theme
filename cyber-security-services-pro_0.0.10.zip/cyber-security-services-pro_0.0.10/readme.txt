=== Cyber Security Services Pro ===
Contributors: ovationthemes
Tags: left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, sticky-post, full-width-template, theme-options, translation-ready, threaded-comments, rtl-language-support, blog, e-commerce
Requires at least: 5.0
Requires PHP: 7.2.14
Tested up to: 5.7
Stable tag: 0.0.9
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html



== Description ==

Cyber Security WordPress Theme is a feature-rich theme with a gorgeous layout. It is specifically designed for repairing services, manufacturing plants, road building, company, constructor, corporate, industry, plumber, electrician, carpenter, painter, handyman, mills, small contractors to big corporates, heavy vehicle and rent websites. This premium theme is compatible with all famous WordPress plugins like WooCommerce, Contact Form 7 etc. It uses theme options using customizer API. The responsive design will fit in all devices. Also, it is translation-ready and has RTL layout support. You have a lot of customization options like simple menu option, Favicon, Logo, Title and Tagline Customization, support to add CSS/JS, pagination option, enable-disable options on all sections.

== Changelog ==

= 0.0.1=
* Initial version released.

= 0.0.2=
* Bugs resolved.

= 0.0.3=
* Bugs resolved,Animation added.

= 0.0.8=
* Console Errors resolved.

= 0.0.9 =
* Added bundle link in dashbord.

== Resources ==

Cyber Security Services Pro WordPress Theme, Copyright 2021 ovation
Cyber Security Services Pro is distributed under the terms of the GNU GPL.

Theme is Built using the following resource bundles.

* CSS bootstrap.css
-- Copyright 2011-2018 The Bootstrap Authors
-- https://github.com/twbs/bootstrap/blob/master/LICENSE
    
* JS bootstrap.js
-- Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
-- https://github.com/twbs/bootstrap/blob/master/LICENSE

* Free to use and abuse under the MIT license.
-- http://www.opensource.org/licenses/mit-license.php
-- font-awesome.css and fonts folder
Font Awesome 5.0.0 by @davegandy - http://fontawesome.io - @fontawesome
-- License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

* All the icons taken from genericons licensed under GPL License.
http://genericons.com/