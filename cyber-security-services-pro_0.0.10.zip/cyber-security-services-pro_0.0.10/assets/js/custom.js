/**
 * Exoplanet Custom JS
 *
 * @package Exoplanet
 *
 * Distributed under the MIT license - http://opensource.org/licenses/MIT
 */

 function showOTSearch()
{
  jQuery(".serach_outer").slideDown(700);
}
function closeOTSearch()
{
  jQuery(".serach_outer").slideUp(700);
}


jQuery(function($){
  "use strict";
  jQuery('.menu > ul').superfish({
    delay:       500, 
    animation:   {opacity:'show',height:'show'},  
    speed:       'fast'
  });
});

// MOBILE MENU

function cyber_security_services_pro_openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}
function cyber_security_services_pro_closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

// THEME OWL SLIDERS

jQuery('document').ready(function(){
  var owl = jQuery('#our_video .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: true,
    autoplay : false,
    lazyLoad: true,
    autoplayTimeout: 3000,
    loop: true,
    dots:false,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 1
      },
      1000: {
        items: 1
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

jQuery('document').ready(function(){
  var owl = jQuery('#testimonials .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: false,
    autoplay : true,
    lazyLoad: true,
    autoplayTimeout: 5000,
    loop: true,
    dots:true,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 2
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

jQuery('document').ready(function(){
  var owl = jQuery('#achievement .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: false,
    autoplay : true,
    lazyLoad: true,
    autoplayTimeout: 5000,
    loop: true,
    dots:false,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 1
      },
      1000: {
        items: 3
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

jQuery('document').ready(function(){
  var owl = jQuery('#our_experts .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: false,
    autoplay : false,
    lazyLoad: true,
    autoplayTimeout: 5000,
    loop: false,
    dots:false,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 3
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

jQuery('document').ready(function(){
  var owl = jQuery('#latest_news .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: false,
    autoplay : true,
    lazyLoad: true,
    autoplayTimeout: 3000,
    loop: false,
    dots:true,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 2
      },
      1000: {
        items: 3
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

jQuery('document').ready(function(){
  var owl = jQuery('#sponsors .owl-carousel');
    owl.owlCarousel({
    margin:20,
    nav: true,
    autoplay : false,
    lazyLoad: true,
    autoplayTimeout: 5000,
    loop: false,
    dots:false,
    navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 5
      },
      1000: {
        items: 7
      }
    },
    autoplayHoverPause : true,
    mouseDrag: true
  });
});

// SCROLL TOP

jQuery('document').ready(function(){
  jQuery(window).scroll(function() {
  if (jQuery(this).scrollTop() >= 50) {
      jQuery('#return-to-top').fadeIn(200);
    } else {
      jQuery('#return-to-top').fadeOut(200);
    }
  });
  jQuery('#return-to-top').click(function() {
    jQuery('body,html').animate({
      scrollTop : 0
    }, 2000);
  });

  jQuery('#counter .count').each(function () {
      jQuery(this).prop('Counter',0).animate({
          Counter: jQuery(this).text()
      }, {
          duration: 8000,
          easing: 'swing',
          step: function (now) {
             jQuery(this).text(Math.ceil(now));
          }
      });
  });
});

// // STICKY NAV BAR

// window.onscroll = function() { myScrollNav() };

// var navbar = document.getElementById("nav-box");
// var sticky = navbar.offsetTop;
// function myScrollNav() {
//   if (window.pageYOffset > sticky) {
//     navbar.classList.add("sticky");
//     navbar.classList.add("stickynavbar");
//   } else {
//     navbar.classList.remove("sticky");
//     navbar.classList.remove("stickynavbar");
//   }
// }

// SITE LOADER

jQuery(window).load(function() {
  jQuery(".preloader").delay(2000).fadeOut("slow");
});


// SEARCH POPUP

$('.header-search-wrapper .search-main').click(function(){
    $('.search-form-main').toggleClass('active-search');
    $('.search-form-main .search-field').focus();
});

// //pop up video

// $('#videoLink').magnificPopup({
//   type:'inline',
//   midClick: true // Allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source in href.
// })


// testimonials

jQuery('#testimonials .project-tabs ul li a').click(function()
  {
    jQuery('#testimonials .project-tabs ul li a').removeClass('active');
  });

// pricing plan



// UI Desgin inspired from dribbble: https://dribbble.com/shots/4393156-Daily-UI-Challenge-030

// JavaScript Code Reference:
// https://codepen.io/yy/pen/doPgJW


$(".custom-switch").each(function(i) {
    var classes = $(this).attr("class"),
        id      = $(this).attr("id"),
        name    = $(this).attr("name");
    
    $(this).wrap('<div class="custom-switch" id="' + name + '"></div>');
      $(this).after('<label for="custom-switch-' + i + '"></label>');
    $(this).attr("id", "custom-switch-" + i);
    $(this).attr("name", name);
  });
  $(".custom-switch input").change(function() {
    $(".pricing-tables").toggleClass("plans--annually");
  });


// Scroll Animation

function reveal() {
  var reveals = document.querySelectorAll(".reveal");
  for (var i = 0; i < reveals.length; i++) {
    var windowHeight = window.innerHeight;
    var elementTop = reveals[i].getBoundingClientRect().top;
    var elementVisible = 150;
    if (elementTop < windowHeight - elementVisible) {
      reveals[i].classList.add("active");
    } else {
      reveals[i].classList.remove("active");
    }
  }
}

window.addEventListener("scroll", reveal);

// To check the scroll position on page load
reveal();

