<?php
/**
 * The Header for our theme.
 *
 * @package cyber-security-services-pro
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
 
<!-- popup video -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.0.0/magnific-popup.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.0.0/jquery.magnific-popup.min.js"></script>



<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>
<?php
  if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
  } else {
    do_action( 'wp_body_open' );
  }
?>
<?php if( get_theme_mod('cyber_security_services_pro_theme_loader',true) != ''){ ?>
  <div class="preloader">
  <div class="loader">
    <div class="loader-inner"></div>
    <div class="loader-inner"></div>
    <div class="loader-inner"></div>
</div>
</div>

<?php }?>

  <header id="masthead" class="site-header">
    <div id="header">
      <div class="header-wrap">
        <?php
          get_template_part('template-parts/header/topbar');                      
        ?>
      </div>     
    </div>
  </header>