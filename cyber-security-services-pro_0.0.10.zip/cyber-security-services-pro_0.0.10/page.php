<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package cyber-security-services-pro
 */
$page_title_style="";
if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Center'){
    $page_title_style='text-align:center;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Left')
{
    $page_title_style='text-align:left;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Right')
{
    $page_title_style='text-align:right;';
}else{
    $page_title_style='';
}
get_header();

if( get_theme_mod('cyber_security_services_pro_pages_bgcolor') ) {
  $about_backg = 'background-color:'.esc_attr(get_theme_mod('cyber_security_services_pro_pages_bgcolor')).';';
}elseif( get_theme_mod('cyber_security_services_pro_pages_bgimage') ){
  $about_backg = 'background-image:url(\''.esc_url(get_theme_mod('cyber_security_services_pro_pages_bgimage')).'\')';
}else{
  $about_backg = '';
}

?>

<?php do_action( 'cyber_security_services_pro_after_page_header' ); ?>

<div class="title-box mb-5 text-center" style="<?php echo esc_attr($about_backg); ?>">
	<div class="container">
		<?php while ( have_posts() ) : the_post(); ?>
			<h2 style="<?php echo esc_attr($page_title_style); ?>" class="py-5"><?php the_title(); ?></h2>
		<?php endwhile; ?>
	</div>
</div>

<div class="outer_dpage mt-5">
	<div class="container">
		<div class="middle-content">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php the_content();
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() ) {
					comments_template(); }
			endwhile; // end of the loop. ?>
		</div>
		<div class="clearfix"></div>
	</div>
</div>

<?php do_action( 'cyber_security_services_pro_before_page_footer' ); ?>

<?php get_footer(); ?>