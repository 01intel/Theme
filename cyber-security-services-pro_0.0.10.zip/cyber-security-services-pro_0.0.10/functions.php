<?php
/**
 * cyber-security-services-pro functions and definitions
 *
 * @package cyber-security-services-pro
 */

if ( ! function_exists( 'cyber_security_services_pro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function cyber_security_services_pro_setup() {
	define( 'THEME_DIR', dirname( __FILE__ ) );
	$GLOBALS['content_width'] = apply_filters( 'cyber_security_services_pro_content_width', 640 );
	if ( ! isset( $content_width ) ) $content_width = 640;
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'custom-header' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'wc-product-gallery-zoom' ); 
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );
	add_image_size('cyber-security-services-pro-homepage-thumb',240,145,true);
	register_nav_menus( array(
		'primary'   => __( 'Primary Menu', 'cyber-security-services-pro' ),
		'footer-info'   => __( 'Footer Info Menu', 'cyber-security-services-pro' ),
		'footer-link'   => __( 'Footer Link Menu', 'cyber-security-services-pro' ),
	) );
	add_theme_support( 'custom-background', array(
		'default-color' => 'f1f1f1'
	) );
	add_editor_style( array( 'assets/css/editor-style.css') );
	add_action( 'wp_ajax_ive-check-plugin-exists', 'check_plugin_exists' );
	add_action( 'wp_ajax_ive_install_and_activate_plugin', 'mep_install_and_activate_plugin' );
}
endif;
add_action( 'after_setup_theme', 'cyber_security_services_pro_setup' );

function mep_install_and_activate_plugin() {

	$post_plugin_details = $_POST['plugin_details'];
	$plugin_text_domain = $post_plugin_details['plugin_text_domain'];
	$plugin_main_file		=	$post_plugin_details['plugin_main_file'];
	$plugin_url					=	$post_plugin_details['plugin_url'];

	$plugin = array(
		'text_domain'	=> $plugin_text_domain,
		'path' 				=> $plugin_url,
		'install' 		=> $plugin_text_domain . '/' . $plugin_main_file
	);

	wp_cache_flush();

	$plugin_path = plugin_basename( trim( $plugin['install'] ) );


	$activate_plugin = activate_plugin( $plugin_path );

	if($activate_plugin) {

		echo $activate_plugin;

	} else {
		echo $activate_plugin;
	}

	$msg = 'installed';

	$response = array( 'status' => true, 'msg' => $msg );
	wp_send_json( $response );
	exit;
}

function check_plugin_exists() {
		$plugin_text_domain = $_POST['plugin_text_domain'];
		$main_plugin_file 	= $_POST['main_plugin_file'];
		$plugin_path = $plugin_text_domain . '/' . $main_plugin_file;

		$get_plugins					= get_plugins();
		$is_plugin_installed	= false;
		$activation_status 		= false;
		if ( isset( $get_plugins[$plugin_path] ) ) {
		$is_plugin_installed = true;

		$activation_status = is_plugin_active( $plugin_path );
		}
		wp_send_json_success(
		array(
		'install_status'  =>	$is_plugin_installed,
			'active_status'		=>	$activation_status,
			'plugin_path'			=>	$plugin_path,
			'plugin_slug'			=>	$plugin_text_domain
		)
		);
}


/* Theme Widgets Setup */
function cyber_security_services_pro_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on blog page sidebar', 'cyber-security-services-pro' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Page Sidebar', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on page sidebar', 'cyber-security-services-pro' ),
		'id'            => 'sidebar-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 1', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on footer', 'cyber-security-services-pro' ),
		'id'            => 'footer-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 2', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on footer', 'cyber-security-services-pro' ),
		'id'            => 'footer-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 3', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on footer', 'cyber-security-services-pro' ),
		'id'            => 'footer-3',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 4', 'cyber-security-services-pro' ),
		'description'   => __( 'Appears on footer', 'cyber-security-services-pro' ),
		'id'            => 'footer-4',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'cyber_security_services_pro_widgets_init' );

/* Theme Font URL */
function cyber_security_services_pro_font_url() {
	$font_url = '';
	$font_family = array();
	$font_family[] = 'Inter:wght@100;200;300;400;500;600;700;800;900';	
	$font_family[] = 'PT Sans:300,400,600,700,800,900';
	$font_family[] = 'Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900';
	$font_family[] = 'Roboto Condensed:400,700';
	$font_family[] = 'Open Sans';
	$font_family[] = 'Overpass';
	$font_family[] = 'Montserrat:300,400,600,700,800,900';
	$font_family[] = 'Playball:300,400,600,700,800,900';
	$font_family[] = 'Alegreya:300,400,600,700,800,900';
	$font_family[] = 'Julius Sans One';
	$font_family[] = 'Arsenal';
	$font_family[] = 'Slabo';
	$font_family[] = 'Lato';
	$font_family[] = 'Overpass Mono';
	$font_family[] = 'Source Sans Pro';
	$font_family[] = 'Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i';
	$font_family[] = 'Merriweather';
	$font_family[] = 'Rubik';
	$font_family[] = 'Lora';
	$font_family[] = 'Ubuntu';
	$font_family[] = 'Cabin';
	$font_family[] = 'Arimo';
	$font_family[] = 'Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900';
	$font_family[] = 'Quicksand';
	$font_family[] = 'Padauk';
	$font_family[] = 'Muli';
	$font_family[] = 'Inconsolata';
	$font_family[] = 'Bitter';
	$font_family[] = 'Pacifico';
	$font_family[] = 'Indie Flower';
	$font_family[] = 'VT323';
	$font_family[] = 'Dosis';
	$font_family[] = 'Frank Ruhl Libre';
	$font_family[] = 'Fjalla One';
	$font_family[] = 'Oxygen';
	$font_family[] = 'Arvo';
	$font_family[] = 'Noto Serif';
	$font_family[] = 'Lobster';
	$font_family[] = 'Crimson Text';
	$font_family[] = 'Yanone Kaffeesatz';
	$font_family[] = 'Anton';
	$font_family[] = 'Libre Baskerville';
	$font_family[] = 'Bree Serif';
	$font_family[] = 'Gloria Hallelujah';
	$font_family[] = 'Josefin Sans:100,100i,300,300i,400,400i,600,600i,700,700i&amp;subset=latin-ext,vietnamese';
	$font_family[] = 'Abril Fatface';
	$font_family[] = 'Varela Round';
	$font_family[] = 'Vampiro One';
	$font_family[] = 'Shadows Into Light';
	$font_family[] = 'Cuprum';
	$font_family[] = 'Rokkitt';
	$font_family[] = 'Vollkorn';
	$font_family[] = 'Francois One';
	$font_family[] = 'Orbitron';
	$font_family[] = 'Patua One';
	$font_family[] = 'Acme';
	$font_family[] = 'Satisfy';
	$font_family[] = 'Josefin Slab';
	$font_family[] = 'Quattrocento Sans';
	$font_family[] = 'Architects Daughter';
	$font_family[] = 'Russo One';
	$font_family[] = 'Monda';
	$font_family[] = 'Righteous';
	$font_family[] = 'Lobster Two';
	$font_family[] = 'Hammersmith One';
	$font_family[] = 'Courgette';
	$font_family[] = 'Permanent Marker';
	$font_family[] = 'Cherry Swash';
	$font_family[] = 'Cormorant Garamond';
	$font_family[] = 'Poiret One';
	$font_family[] = 'BenchNine';
	$font_family[] = 'Economica';
	$font_family[] = 'Handlee';
	$font_family[] = 'Cardo';
	$font_family[] = 'Alfa Slab One';
	$font_family[] = 'Averia Serif Libre';
	$font_family[] = 'Cookie';
	$font_family[] = 'Chewy';
	$font_family[] = 'Great Vibes';
	$font_family[] = 'Coming Soon';
	$font_family[] = 'Philosopher';
	$font_family[] = 'Days One';
	$font_family[] = 'Kanit';
	$font_family[] = 'Shrikhand';
	$font_family[] = 'Tangerine';
	$font_family[] = 'IM Fell English SC';
	$font_family[] = 'Boogaloo';
	$font_family[] = 'Bangers';
	$font_family[] = 'Fredoka One';
	$font_family[] = 'Bad Script';
	$font_family[] = 'Volkhov';
	$font_family[] = 'Shadows Into Light Two';
	$font_family[] = 'Marck Script';
	$font_family[] = 'Sacramento';
	$font_family[] = 'Poppins:100,200,300,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext';
	$font_family[] = 'Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900';
	$font_family[] = 'Zen Kaku Gothic Antique:wght@300;400;500;700;900';
	$font_family[] = 'Gothic A1:wght@100;200;300;400;500;600;700;800;900';
		
	$font_family[] = 'PT Serif';
	$query_args = array(
		'family'	=> urlencode(implode('|',$font_family)),
	);
	$font_url = add_query_arg($query_args,'//fonts.googleapis.com/css');
	return $font_url;
}

/* Theme enqueue scripts */
function cyber_security_services_pro_scripts() {

wp_register_style( 'media-style', get_stylesheet_directory_uri() . '/assets/css/media.css');
    wp_enqueue_style( 'media-style' );

    wp_enqueue_style( 'cyber-security-services-pro-font', cyber_security_services_pro_font_url(), array() );
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri().'/assets/css/bootstrap.min.css' ); 
	wp_enqueue_style( 'cyber-security-services-pro-basic-style', get_stylesheet_uri() );

	   /* Inline style Sheet */
	require get_parent_theme_file_path( '/inline_style.php' );
	wp_add_inline_style( 'cyber-security-services-pro-basic-style',$custom_css );

	wp_enqueue_style( 'animation-wow', get_template_directory_uri().'/assets/css/animation.css' );
	wp_enqueue_style( 'magnific-popup', get_template_directory_uri().'/assets/css/magnific-popup.min.css' );

	wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/assets/css/fontawesome-all.min.css' );

	wp_enqueue_style( 'owl-carousel-style', get_template_directory_uri().'/assets/css/owl.carousel.css' );
	
	wp_enqueue_script( 'tether', 'https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js',array('jquery'),'',true);

	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js',array('jquery'),'',true);
	wp_enqueue_script( 'superfsh', get_template_directory_uri() . '/assets/js/jquery.superfish.js',array('jquery'),'',true);
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.js',array('jquery'),'',true);
	wp_enqueue_script( 'mordernizer', 'https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js', array('jquery'),'', true );
	wp_enqueue_script( 'magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js',array('jquery'),'',true);
	
	wp_enqueue_script( 'cyber-security-services-pro-customscripts', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'),'', true );
    
	wp_register_style( 'woocommerce-style', get_stylesheet_directory_uri() . '/assets/css/woocommerce.css');
    wp_enqueue_style( 'woocommerce-style' );

	wp_style_add_data( 'cyber-security-services-pro-style', 'rtl', 'replace' );
	wp_enqueue_style( 'cyber-security-services-pro-editor-style', get_template_directory_uri().'/editor-style.css' );

	
	require get_parent_theme_file_path( '/color_style.php' );
	wp_add_inline_style( 'cyber-security-services-pro-basic-style',$custom_css );
	

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_style('cyber-security-services-pro-ie', get_template_directory_uri().'/assets/css/ie.css', array('cyber-security-services-pro-basic-style'));
	wp_style_add_data( 'cyber-security-services-pro-ie', 'conditional', 'IE' );

}
add_action( 'wp_enqueue_scripts', 'cyber_security_services_pro_scripts' );

/* Implement the Custom Header feature. */
require get_parent_theme_file_path( '/inc/custom-header.php' );
/* Custom template tags for this theme. */
require get_parent_theme_file_path( '/inc/template-tags.php' );
/* Customizer additions. */
require get_parent_theme_file_path( '/inc/customizer.php' );
/* TGM. */
require get_parent_theme_file_path( '/inc/tgm.php' );
/* Get Started. */
require get_parent_theme_file_path( '/inc/getstarted/getstart.php' );

/* URL DEFINES */
define('cyber_security_services_pro_SITE_URL','https://www.ovationthemes.com/');

/* Theme Credit link */
function cyber_security_services_pro_credit_link() {
	echo "<a href=".esc_url(cyber_security_services_pro_SITE_URL).">". esc_html__('© 2022, Cyber Security','cyber-security-services-pro')."</a>";
}

/*Radio Button sanitization*/
function cyber_security_services_pro_sanitize_choices( $input, $setting ) {
	global $wp_customize;
	$control = $wp_customize->get_control( $setting->id );
	if ( array_key_exists( $input, $control->choices ) ) {
		return $input;
	} else {
		return $setting->default;
	}
}

/* Breadcrumb Begin */
function cyber_security_services_pro_the_breadcrumb() {
	if (!is_home()) {
		echo '<a href="';
			echo esc_url(home_url());
		echo '">';
			bloginfo('name');
		echo "</a> ";
		if (is_category() || is_single()) {
			the_category(', ');
			if (is_single()) {
				echo "<span> ";
					the_title();
				echo "</span> ";
			}
		} elseif (is_page()) {
			the_title();
		}
	}
}

/* Excerpt Read more overwrite */
function cyber_security_services_pro_excerpt_more( $link ) {
	if ( is_admin() ) {
		return $link;
	}
	$link = sprintf( '<p class="link-more"><a href="%1$s" class="more-link">%2$s</a></p>',
		esc_url( get_permalink( get_the_ID() ) ),
		/* translators: %s: Name of current post */
		sprintf( __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'cyber-security-services-pro' ), get_the_title( get_the_ID() ) )
	);
	return ' &hellip; ' . $link;
}

//Contact Widget file
require get_parent_theme_file_path( '/inc/widget/contact-widget.php' );

add_filter( 'excerpt_more', 'cyber_security_services_pro_excerpt_more' );

function cyber_security_services_pro_sanitize_select( $input, $setting ){  
    $input = sanitize_key($input);    
    $choices = $setting->manager->get_control( $setting->id )->choices;
    return ( array_key_exists( $input, $choices ) ? $input : $setting->default );      
}

function cyber_security_services_pro_sanitize_number_absint( $number, $setting ) {
	// Ensure $number is an absolute integer (whole number, zero or greater).
	$number = absint( $number );
	
	// If the input is an absolute integer, return it; otherwise, return the default
	return ( $number ? $number : $setting->default );
}

function cyber_security_services_pro_global_simple_bgcolor(){
	if(get_theme_mod('cyber_security_services_pro_global_background_options') == 'simple-bgcolor' ) {
		return true;
	}
	return false;
}

function cyber_security_services_pro_global_gradiant_bgcolor(){
	if(get_theme_mod('cyber_security_services_pro_global_background_options') == 'gradiant-bg-color' ) {
		return true;
	}
	return false;
}

function cyber_security_services_pro_image_slider(){
	if(get_theme_mod('cyber_security_services_pro_slider_options') == 'image-slider' ) {
		return true;
	}
	return false;
}

function cyber_security_services_pro_video_slider(){
	if(get_theme_mod('cyber_security_services_pro_slider_options') == 'video-slider' ) {
		return true;
	}
	return false;
}


function cyber_security_services_pro_linear_gradient(){
	if(get_theme_mod('cyber_security_services_pro_global_gradient_options') == 'linear-gradient' &&  get_theme_mod('cyber_security_services_pro_global_background_options') == 'gradiant-bg-color' ) {
		return true;
	}
	return false;
}

function cyber_security_services_pro_radial_gradient(){
	if(get_theme_mod('cyber_security_services_pro_global_gradient_options') == 'radial-gradient' &&  get_theme_mod('cyber_security_services_pro_global_background_options') == 'gradiant-bg-color' ) {
		return true;
	}
	return false;
}

//Services

function cyber_security_services_pro_services_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Services', 'Services General Name', 'cyber-security-services-pro' ),
		'singular_name'         => _x( 'Services', 'Post Type Singular Name', 'cyber-security-services-pro' ),
		
	);
	$args = array(
		'label'                 => __( 'Services', 'cyber-security-services-pro' ),
		'description'           => __( 'Services Description', 'cyber-security-services-pro' ),
		'labels'                => $labels,
		'supports'				=> array('title','editor','thumbnail','comments',							  'custom-fields' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post'
	);
	register_post_type( 'service', $args );

}
add_action( 'init', 'cyber_security_services_pro_services_custom_post_type', 0 );


//Our Experts

function cyber_security_services_pro_our_experts_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Our Experts', 'Our Experts General Name', 'cyber-security-services-pro' ),
		'singular_name'         => _x( 'Our Experts', 'Post Type Singular Name', 'cyber-security-services-pro' ),
		
	);
	$args = array(
		'label'                 => __( 'Our Experts', 'cyber-security-services-pro' ),
		'description'           => __( 'Our Experts Description', 'cyber-security-services-pro' ),
		'labels'                => $labels,
		'supports'				=> array('title','editor','thumbnail','comments',							  'custom-fields' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post'
	);
	register_post_type( 'our_experts', $args );

}
add_action( 'init', 'cyber_security_services_pro_our_experts_custom_post_type', 0 );

// woocommere filter
add_filter( 'woocommerce_prevent_automatic_wizard_redirect', '__return_true' );

// serach form

add_shortcode('wpbsearch', 'get_search_form');


//Bundle Bar 
function cyber_security_services_pro_boundle_bar() {
echo '<div class="notice notice-warning is-dismissible ot-bundle">
	  	<div class="ot-bundle-content">
	   		<p>WordPress Bundle - Get 60+ WordPress Themes <br> Worth $2500+ At Just $79 With Additional 20% Discount Use Code "Bundle20" <span class="ot-bundle-btn"><a href="https://www.ovationthemes.com/wordpress/wordpress-bundle/" target="_blank">BUY NOW</a></span></p>
	   	</div>
      </div>'; 
}
add_action( 'admin_notices', 'cyber_security_services_pro_boundle_bar' );