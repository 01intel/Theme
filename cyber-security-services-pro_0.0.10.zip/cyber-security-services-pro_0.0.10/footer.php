<?php
/**
 * The template for displaying the footer.
 *
 * @package cyber-security-services-pro
 */

?>
	<div class="clearfix"></div>
	<div class="outer-footer">
		<?php
		get_template_part( 'template-parts/footer/footer-columns' );
		
		?>
	</div>
	<?php wp_footer(); ?>
	</body>
</html>