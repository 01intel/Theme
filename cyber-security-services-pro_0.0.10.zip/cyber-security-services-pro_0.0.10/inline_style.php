<?php
// SECTION SPACING

$cyber_security_services_pro_spacing_achievement_top = get_theme_mod('cyber_security_services_pro_spacing_achievement_top');

$cyber_security_services_pro_spacing_sponsors_top = get_theme_mod('cyber_security_services_pro_spacing_sponsors_top');

$cyber_security_services_pro_spacing_slider_top = get_theme_mod('cyber_security_services_pro_spacing_slider_top');

$cyber_security_services_pro_spacing_about_top = get_theme_mod('cyber_security_services_pro_spacing_about_top');

$cyber_security_services_pro_spacing_our_video_top = get_theme_mod('cyber_security_services_pro_spacing_our_video_top');

$cyber_security_services_pro_spacing_latest_news_top = get_theme_mod('cyber_security_services_pro_spacing_latest_news_top');	

$cyber_security_services_pro_spacing_choose_us_top = get_theme_mod('cyber_security_services_pro_spacing_choose_us_top');

$cyber_security_services_pro_spacing_pricing_plan_top = get_theme_mod('cyber_security_services_pro_spacing_pricing_plan_top');

$cyber_security_services_pro_spacing_testimonials_top = get_theme_mod('cyber_security_services_pro_spacing_testimonials_top');

$cyber_security_services_pro_spacing_our_experts_top = get_theme_mod('cyber_security_services_pro_spacing_our_experts_top');

$cyber_security_services_pro_spacing_new_project_top = get_theme_mod('cyber_security_services_pro_spacing_new_project_top');

$cyber_security_services_pro_spacing_our_services_top = get_theme_mod('cyber_security_services_pro_spacing_our_services_top');			

	// TOPBAR COLOR SETTINGS

	$cyber_security_services_pro_topbar_searchbtn_text_color = get_theme_mod('cyber_security_services_pro_topbar_searchbtn_text_color');
	
	$cyber_security_services_pro_topbar_searchbtn_text_font = get_theme_mod('cyber_security_services_pro_topbar_searchbtn_text_font');
	$cyber_security_services_pro_topbar_searchbtn_bgcolor = get_theme_mod('cyber_security_services_pro_topbar_searchbtn_bgcolor');

	$cyber_security_services_pro_topbar_social_icon_color = get_theme_mod('cyber_security_services_pro_topbar_social_icon_color');
	
	$cyber_security_services_pro_topbar_mail_icon_color = get_theme_mod('cyber_security_services_pro_topbar_mail_icon_color');
	$cyber_security_services_pro_topbar_email_id_color = get_theme_mod('cyber_security_services_pro_topbar_email_id_color');

	$cyber_security_services_pro_topbar_email_id_font = get_theme_mod('cyber_security_services_pro_topbar_email_id_font');
	$cyber_security_services_pro_topbar_map_icon_color = get_theme_mod('cyber_security_services_pro_topbar_map_icon_color');

	$cyber_security_services_pro_topbar_call_icon_color = get_theme_mod('cyber_security_services_pro_topbar_call_icon_color');
	$cyber_security_services_pro_topbar_call_number_color = get_theme_mod('cyber_security_services_pro_topbar_call_number_color');

	$cyber_security_services_pro_topbar_call_number_font = get_theme_mod('cyber_security_services_pro_topbar_call_number_font');
	$cyber_security_services_pro_topbar_address_color = get_theme_mod('cyber_security_services_pro_topbar_address_color');

	$cyber_security_services_pro_topbar_address_font = get_theme_mod('cyber_security_services_pro_topbar_address_font');

	// HEADER COLOR SETTINGS

	$cyber_security_services_pro_header_search_icon_bgcolor = get_theme_mod('cyber_security_services_pro_header_search_icon_bgcolor');
	
	$cyber_security_services_pro_header_search_icon_color = get_theme_mod('cyber_security_services_pro_header_search_icon_color');

	$cyber_security_services_pro_search_placeholder_color = get_theme_mod('cyber_security_services_pro_search_placeholder_color');

	// LOGO & MENUS COLOR SETTINGS
	$cyber_security_services_pro_logo_title_bgcolor = get_theme_mod('cyber_security_services_pro_logo_title_bgcolor');

	$cyber_security_services_pro_logo_title_color = get_theme_mod('cyber_security_services_pro_logo_title_color');
	$cyber_security_services_pro_logo_title_font = get_theme_mod('cyber_security_services_pro_logo_title_font');

	$cyber_security_services_pro_logo_text_color = get_theme_mod('cyber_security_services_pro_logo_text_color');
	$cyber_security_services_pro_logo_text_font = get_theme_mod('cyber_security_services_pro_logo_text_font');

	$cyber_security_services_pro_menu_text_color = get_theme_mod('cyber_security_services_pro_menu_text_color');
	$cyber_security_services_pro_menu_text_font = get_theme_mod('cyber_security_services_pro_menu_text_font');
	$cyber_security_services_pro_headermenu_font_size = get_theme_mod('cyber_security_services_pro_headermenu_font_size');

	$cyber_security_services_pro_header_menuhovercolor = get_theme_mod('cyber_security_services_pro_header_menuhovercolor');
	$cyber_security_services_pro_dropdownbg_color = get_theme_mod('cyber_security_services_pro_dropdownbg_color');

	$cyber_security_services_pro_dropdownbg_itemcolor = get_theme_mod('cyber_security_services_pro_dropdownbg_itemcolor');
	$cyber_security_services_pro_dropdownbg_font_family = get_theme_mod('cyber_security_services_pro_dropdownbg_font_family');

	$cyber_security_services_pro_dropdownbg_font_size = get_theme_mod('cyber_security_services_pro_dropdownbg_font_size');
	$cyber_security_services_pro_dropdownbg_item_hovercolor = get_theme_mod('cyber_security_services_pro_dropdownbg_item_hovercolor');
	$cyber_security_services_pro_header_menu_active_color = get_theme_mod('cyber_security_services_pro_header_menu_active_color');


	// SLIDER COLOR SETTINGS	

	$cyber_security_services_pro_slider_bgcolor = get_theme_mod('cyber_security_services_pro_slider_bgcolor');

	$cyber_security_services_pro_slider_opacity = get_theme_mod('cyber_security_services_pro_slider_opacity');

	$cyber_security_services_pro_slider_small_head_color = get_theme_mod('cyber_security_services_pro_slider_small_head_color');

	$cyber_security_services_pro_slider_small_head_font = get_theme_mod('cyber_security_services_pro_slider_small_head_font');

	$cyber_security_services_pro_slider_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_slider_small_head_bgcolor');

	$cyber_security_services_pro_slider_title_color = get_theme_mod('cyber_security_services_pro_slider_title_color');
	$cyber_security_services_pro_slider_title_font = get_theme_mod('cyber_security_services_pro_slider_title_font');

	$cyber_security_services_pro_slider_text_color = get_theme_mod('cyber_security_services_pro_slider_text_color');
	$cyber_security_services_pro_slider_text_font = get_theme_mod('cyber_security_services_pro_slider_text_font');

	$cyber_security_services_pro_slider_quotebtn_text_color = get_theme_mod('cyber_security_services_pro_slider_quotebtn_text_color');
	$cyber_security_services_pro_slider_quotebtn_text_font = get_theme_mod('cyber_security_services_pro_slider_quotebtn_text_font');

	$cyber_security_services_pro_slider_quotebtn_bgcolor = get_theme_mod('cyber_security_services_pro_slider_quotebtn_bgcolor');
	$cyber_security_services_pro_slider_read_btn_text_color = get_theme_mod('cyber_security_services_pro_slider_read_btn_text_color');
	$cyber_security_services_pro_slider_read_btn_text_font = get_theme_mod('cyber_security_services_pro_slider_read_btn_text_font');
	$cyber_security_services_pro_slider_read_btn_bgcolor = get_theme_mod('cyber_security_services_pro_slider_read_btn_bgcolor');
	$cyber_security_services_pro_slider_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_slider_btn_hover_bgcolor');

	$cyber_security_services_pro_slider_btn_texthover_color = get_theme_mod('cyber_security_services_pro_slider_btn_texthover_color');
	$cyber_security_services_pro_slider_social_icon_color = get_theme_mod('cyber_security_services_pro_slider_social_icon_color');
	$cyber_security_services_pro_slider_social_icon_bgcolor = get_theme_mod('cyber_security_services_pro_slider_social_icon_bgcolor');


		// ABOUT COLOR SETTINGS

	$cyber_security_services_pro_about_small_head_color = get_theme_mod('cyber_security_services_pro_about_small_head_color');
	$cyber_security_services_pro_about_small_head_font = get_theme_mod('cyber_security_services_pro_about_small_head_font');

	$cyber_security_services_pro_about_heading_color = get_theme_mod('cyber_security_services_pro_about_heading_color');
	$cyber_security_services_pro_about_heading_font = get_theme_mod('cyber_security_services_pro_about_heading_font');

	$cyber_security_services_pro_about_text_color = get_theme_mod('cyber_security_services_pro_about_text_color');
	$cyber_security_services_pro_about_text_font = get_theme_mod('cyber_security_services_pro_about_text_font');
	
	$cyber_security_services_pro_about_btn_color = get_theme_mod('cyber_security_services_pro_about_btn_color');
	$cyber_security_services_pro_about_btn_font = get_theme_mod('cyber_security_services_pro_about_btn_font');

	$cyber_security_services_pro_about_btn_bgcolor = get_theme_mod('cyber_security_services_pro_about_btn_bgcolor');
	$cyber_security_services_pro_about_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_about_btn_hover_bgcolor');
	$cyber_security_services_pro_about_box_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_about_box_btn_text_hover_color');

	$cyber_security_services_pro_about_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_about_small_head_bgcolor');

	// OUR VIDEO COLOR SETTING

	

	$cyber_security_services_pro_our_video_small_head_color = get_theme_mod('cyber_security_services_pro_our_video_small_head_color');

	$cyber_security_services_pro_our_video_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_our_video_small_head_bgcolor');

	$cyber_security_services_pro_our_video_small_head_font_family = get_theme_mod('cyber_security_services_pro_our_video_small_head_font_family');

	$cyber_security_services_pro_our_video_text_color = get_theme_mod('cyber_security_services_pro_our_video_text_color');
	$cyber_security_services_pro_our_video_text_font_family = get_theme_mod('cyber_security_services_pro_our_video_text_font_family');

	$cyber_security_services_pro_our_video_nav_text_color = get_theme_mod('cyber_security_services_pro_our_video_nav_text_color');
	$cyber_security_services_pro_our_video_nav_text_font_family = get_theme_mod('cyber_security_services_pro_our_video_nav_text_font_family');

	$cyber_security_services_pro_our_video_nav_icon_color = get_theme_mod('cyber_security_services_pro_our_video_nav_icon_color');
	$cyber_security_services_pro_our_video_nav_icon_bgcolor = get_theme_mod('cyber_security_services_pro_our_video_nav_icon_bgcolor');

	$cyber_security_services_pro_our_video_main_heading_color = get_theme_mod('cyber_security_services_pro_our_video_main_heading_color');
	$cyber_security_services_pro_our_video_main_heading_font_family = get_theme_mod('cyber_security_services_pro_our_video_main_heading_font_family');

	$cyber_security_services_pro_our_video_btn_icon_color = get_theme_mod('cyber_security_services_pro_our_video_btn_icon_color');
	$cyber_security_services_pro_our_video_btn_icon_bgcolor = get_theme_mod('cyber_security_services_pro_our_video_btn_icon_bgcolor');

	// LATEST NEWS COLOR SETTING


$cyber_security_services_pro_latest_news_comment_color = get_theme_mod('cyber_security_services_pro_latest_news_comment_color');

	$cyber_security_services_pro_latest_news_comment_font = get_theme_mod('cyber_security_services_pro_latest_news_comment_font');

	$cyber_security_services_pro_latest_news_comment_icon_color = get_theme_mod('cyber_security_services_pro_latest_news_comment_icon_color');
	$cyber_security_services_pro_latest_news_outer_btn_color = get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_color');

	$cyber_security_services_pro_latest_news_outer_btn_font = get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_font');
	$cyber_security_services_pro_latest_news_outer_btn_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_bgcolor');

	$cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor');
	$cyber_security_services_pro_latest_news_outer_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_latest_news_outer_btn_text_hover_color');


$cyber_security_services_pro_latest_news_heading_color = get_theme_mod('cyber_security_services_pro_latest_news_heading_color');
	$cyber_security_services_pro_latest_news_heading_font = get_theme_mod('cyber_security_services_pro_latest_news_heading_font');

	$cyber_security_services_pro_latest_news_small_head_color = get_theme_mod('cyber_security_services_pro_latest_news_small_head_color');
	$cyber_security_services_pro_latest_news_small_head_font = get_theme_mod('cyber_security_services_pro_latest_news_small_head_font');

	$cyber_security_services_pro_latest_news_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_small_head_bgcolor');

	$cyber_security_services_pro_latest_news_post_admin_color = get_theme_mod('cyber_security_services_pro_latest_news_post_admin_color');

	$cyber_security_services_pro_latest_news_post_admin_font = get_theme_mod('cyber_security_services_pro_latest_news_post_admin_font');
	$cyber_security_services_pro_latest_news_post_heading_color = get_theme_mod('cyber_security_services_pro_latest_news_post_heading_color');

	$cyber_security_services_pro_latest_news_post_heading_font = get_theme_mod('cyber_security_services_pro_latest_news_post_heading_font');
	$cyber_security_services_pro_latest_news_post_text_color = get_theme_mod('cyber_security_services_pro_latest_news_post_text_color');

	$cyber_security_services_pro_latest_news_post_text_font = get_theme_mod('cyber_security_services_pro_latest_news_post_text_font');
	// $cyber_security_services_pro_latest_news_date_color = get_theme_mod('cyber_security_services_pro_latest_news_date_color');

	// $cyber_security_services_pro_latest_news_date_font = get_theme_mod('cyber_security_services_pro_latest_news_date_font');
	// $cyber_security_services_pro_latest_news_box_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_box_bgcolor');
	

	$cyber_security_services_pro_latest_news_read_button_arrow_icon_color = get_theme_mod('cyber_security_services_pro_latest_news_read_button_arrow_icon_color');

	$cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor');

	$cyber_security_services_pro_latest_news_read_button_bgcolor = get_theme_mod('cyber_security_services_pro_latest_news_read_button_bgcolor');	
	
	$cyber_security_services_pro_latest_news_read_button_color = get_theme_mod('cyber_security_services_pro_latest_news_read_button_color');
	$cyber_security_services_pro_latest_news_read_button_font_family = get_theme_mod('cyber_security_services_pro_latest_news_read_button_font_family');

	// ------ACHIEVEMENT-------------

	$cyber_security_services_pro_achievement_main_head_color = get_theme_mod('cyber_security_services_pro_achievement_main_head_color');
	
	$cyber_security_services_pro_achievement_main_head_font = get_theme_mod('cyber_security_services_pro_achievement_main_head_font');	
	
	$cyber_security_services_pro_achievement_text_color = get_theme_mod('cyber_security_services_pro_achievement_text_color');
	$cyber_security_services_pro_achievement_text_font = get_theme_mod('cyber_security_services_pro_achievement_text_font');	

	$cyber_security_services_pro_achievement_count_color = get_theme_mod('cyber_security_services_pro_achievement_count_color');

	$cyber_security_services_pro_achievement_count_font = get_theme_mod('cyber_security_services_pro_achievement_count_font');
	$cyber_security_services_pro_achievement_inner_heading_color = get_theme_mod('cyber_security_services_pro_achievement_inner_heading_color');

	$cyber_security_services_pro_achievement_inner_heading_font = get_theme_mod('cyber_security_services_pro_achievement_inner_heading_font');

	// Choose Us

	$cyber_security_services_pro_choose_us_small_heading_color = get_theme_mod('cyber_security_services_pro_choose_us_small_heading_color');

	$cyber_security_services_pro_choose_us_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_choose_us_small_head_bgcolor');

	$cyber_security_services_pro_choose_us_small_heading_font_family = get_theme_mod('cyber_security_services_pro_choose_us_small_heading_font_family');


	$cyber_security_services_pro_choose_us_main_heading_color = get_theme_mod('cyber_security_services_pro_choose_us_main_heading_color');
	$cyber_security_services_pro_choose_us_main_heading_font_family = get_theme_mod('cyber_security_services_pro_choose_us_main_heading_font_family');

	$cyber_security_services_pro_choose_us_text_color = get_theme_mod('cyber_security_services_pro_choose_us_text_color');
	$cyber_security_services_pro_choose_us_text_font_family = get_theme_mod('cyber_security_services_pro_choose_us_text_font_family');

	$cyber_security_services_pro_choose_us_right_head_color = get_theme_mod('cyber_security_services_pro_choose_us_right_head_color');
	$cyber_security_services_pro_choose_us_right_head_font_family = get_theme_mod('cyber_security_services_pro_choose_us_right_head_font_family');

	$cyber_security_services_pro_choose_us_inner_smhead_color = get_theme_mod('cyber_security_services_pro_choose_us_inner_smhead_color');
	$cyber_security_services_pro_choose_us_inner_smhead_font_family = get_theme_mod('cyber_security_services_pro_choose_us_inner_smhead_font_family');

	$cyber_security_services_pro_choose_us_right_list_color = get_theme_mod('cyber_security_services_pro_choose_us_right_list_color');
	$cyber_security_services_pro_choose_us_right_list_font_family = get_theme_mod('cyber_security_services_pro_choose_us_right_list_font_family');

	$cyber_security_services_pro_choose_us_btn_color = get_theme_mod('cyber_security_services_pro_choose_us_btn_color');

	$cyber_security_services_pro_choose_us_btn_font = get_theme_mod('cyber_security_services_pro_choose_us_btn_font');
	$cyber_security_services_pro_choose_us_btn_bgcolor = get_theme_mod('cyber_security_services_pro_choose_us_btn_bgcolor');

	$cyber_security_services_pro_choose_us_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_choose_us_btn_hover_bgcolor');
	$cyber_security_services_pro_choose_us_box_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_choose_us_box_btn_text_hover_color');


	// PRICING PLAN COLOR SETTING

	$cyber_security_services_pro_pricing_plan_inner_text_color = get_theme_mod('cyber_security_services_pro_pricing_plan_inner_text_color');
	$cyber_security_services_pro_pricing_plan_inner_text_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_inner_text_font_family');

	$cyber_security_services_pro_pricing_plan_tick_icon_color = get_theme_mod('cyber_security_services_pro_pricing_plan_tick_icon_color');
	$cyber_security_services_pro_pricing_plan_tick_icon_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_tick_icon_bgcolor');

	$cyber_security_services_pro_pricing_plan_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_small_head_bgcolor');

	$cyber_security_services_pro_pricing_plan_small_heading_color = get_theme_mod('cyber_security_services_pro_pricing_plan_small_heading_color');
	$cyber_security_services_pro_pricing_plan_small_heading_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_small_heading_font_family');

	$cyber_security_services_pro_pricing_plan_tab_title_color = get_theme_mod('cyber_security_services_pro_pricing_plan_tab_title_color');
	$cyber_security_services_pro_pricing_plan_tab_title_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_tab_title_font_family');

	$cyber_security_services_pro_pricing_plan_main_heading_color = get_theme_mod('cyber_security_services_pro_pricing_plan_main_heading_color');
	$cyber_security_services_pro_pricing_plan_main_heading_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_main_heading_font_family');

	$cyber_security_services_pro_pricing_plan_price_color = get_theme_mod('cyber_security_services_pro_pricing_plan_price_color');

	$cyber_security_services_pro_pricing_plan_price_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_price_font_family');
	$cyber_security_services_pro_pricing_plan_pack_option_title_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_pack_option_title_font_family');

	$cyber_security_services_pro_pricing_plan_pack_option_title_color = get_theme_mod('cyber_security_services_pro_pricing_plan_pack_option_title_color');	

	$cyber_security_services_pro_pricing_plan_box_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_box_bgcolor');

	$cyber_security_services_pro_pricing_plan_feature_color = get_theme_mod('cyber_security_services_pro_pricing_plan_feature_color');

	$cyber_security_services_pro_pricing_plan_features_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_features_font_family');

	$cyber_security_services_pro_pricing_plan_button_color = get_theme_mod('cyber_security_services_pro_pricing_plan_button_color');

	$cyber_security_services_pro_pricing_plan_button_font_family = get_theme_mod('cyber_security_services_pro_pricing_plan_button_font_family');

	$cyber_security_services_pro_pricing_plan_button_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_button_bgcolor');

	$cyber_security_services_pro_pricing_plan_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_btn_hover_bgcolor');
	$cyber_security_services_pro_pricing_plan_box_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_pricing_plan_box_btn_text_hover_color');
	

	$cyber_security_services_pro_pricing_plan_hover_bgcolor = get_theme_mod('cyber_security_services_pro_pricing_plan_hover_bgcolor');

	// Testimonials COLOR SETTINGS

  $cyber_security_services_pro_testimonials_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_testimonials_small_head_bgcolor');

	$cyber_security_services_pro_testimonials_designation_color = get_theme_mod('cyber_security_services_pro_testimonials_designation_color');
	$cyber_security_services_pro_testimonials_designation_font = get_theme_mod('cyber_security_services_pro_testimonials_designation_font');

	$cyber_security_services_pro_testimonials_heading_color = get_theme_mod('cyber_security_services_pro_testimonials_heading_color');
	$cyber_security_services_pro_testimonials_heading_font = get_theme_mod('cyber_security_services_pro_testimonials_heading_font');

	$cyber_security_services_pro_testimonials_content_bgcolor = get_theme_mod('cyber_security_services_pro_testimonials_content_bgcolor');

	$cyber_security_services_pro_testimonials_name_color = get_theme_mod('cyber_security_services_pro_testimonials_name_color');
	$cyber_security_services_pro_testimonials_name_font = get_theme_mod('cyber_security_services_pro_testimonials_name_font');

	$cyber_security_services_pro_testimonials_small_head_color = get_theme_mod('cyber_security_services_pro_testimonials_small_head_color');
	$cyber_security_services_pro_testimonials_small_head_font = get_theme_mod('cyber_security_services_pro_testimonials_small_head_font');

	$cyber_security_services_pro_testimonials_inner_text_color = get_theme_mod('cyber_security_services_pro_testimonials_inner_text_color');
	$cyber_security_services_pro_testimonials_inner_text_font = get_theme_mod('cyber_security_services_pro_testimonials_inner_text_font');

	$cyber_security_services_pro_testimonials_quote_icon_color = get_theme_mod('cyber_security_services_pro_testimonials_quote_icon_color');


	// OUR EXPERTS COLOR SETTINGS
	
	$cyber_security_services_pro_our_experts_hr_color = get_theme_mod('cyber_security_services_pro_our_experts_hr_color');

	$cyber_security_services_pro_our_experts_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_our_experts_small_head_bgcolor');

	$cyber_security_services_pro_our_experts_small_head_color = get_theme_mod('cyber_security_services_pro_our_experts_small_head_color');
	$cyber_security_services_pro_our_experts_small_head_font = get_theme_mod('cyber_security_services_pro_our_experts_small_head_font');

	$cyber_security_services_pro_our_experts_heading_color = get_theme_mod('cyber_security_services_pro_our_experts_heading_color');
	$cyber_security_services_pro_our_experts_heading_font = get_theme_mod('cyber_security_services_pro_our_experts_heading_font');

	$cyber_security_services_pro_our_experts_name_color = get_theme_mod('cyber_security_services_pro_our_experts_name_color');
	$cyber_security_services_pro_our_experts_name_font = get_theme_mod('cyber_security_services_pro_our_experts_name_font');

	$cyber_security_services_pro_our_experts_designation_color = get_theme_mod('cyber_security_services_pro_our_experts_designation_color');
	$cyber_security_services_pro_our_experts_designation_font = get_theme_mod('cyber_security_services_pro_our_experts_designation_font');

	$cyber_security_services_pro_our_experts_social_icon_bgcolor = get_theme_mod('cyber_security_services_pro_our_experts_social_icon_bgcolor');
	$cyber_security_services_pro_our_experts_social_icon_color = get_theme_mod('cyber_security_services_pro_our_experts_social_icon_color');	

$cyber_security_services_pro_our_experts_outer_btn_color = get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_color');
	$cyber_security_services_pro_our_experts_outer_btn_font = get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_font');

	$cyber_security_services_pro_our_experts_outer_btn_bgcolor = get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_bgcolor');
	$cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor');

	$cyber_security_services_pro_our_experts_outer_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_our_experts_outer_btn_text_hover_color');

	// SPONSOR COLOR SETTING

	$cyber_security_services_pro_sponsors_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_sponsors_small_head_bgcolor');

	$cyber_security_services_pro_sponsors_small_head_color = get_theme_mod('cyber_security_services_pro_sponsors_small_head_color');

	$cyber_security_services_pro_sponsors_small_head_font_family = get_theme_mod('cyber_security_services_pro_sponsors_small_head_font_family');

	$cyber_security_services_pro_sponsors_main_heading_color = get_theme_mod('cyber_security_services_pro_sponsors_main_heading_color');
	$cyber_security_services_pro_sponsors_main_heading_font_family = get_theme_mod('cyber_security_services_pro_sponsors_main_heading_font_family');

	$cyber_security_services_pro_sponsors_nav_icon_color = get_theme_mod('cyber_security_services_pro_sponsors_nav_icon_color');
	$cyber_security_services_pro_sponsors_nav_icon_bgcolor = get_theme_mod('cyber_security_services_pro_sponsors_nav_icon_bgcolor');

	// Our Services COLOR SETTING

	$cyber_security_services_pro_our_services_small_head_color = get_theme_mod('cyber_security_services_pro_our_services_small_head_color');

	$cyber_security_services_pro_our_services_small_head_bgcolor = get_theme_mod('cyber_security_services_pro_our_services_small_head_bgcolor');

	$cyber_security_services_pro_our_services_small_head_font = get_theme_mod('cyber_security_services_pro_our_services_small_head_font');

	$cyber_security_services_pro_our_services_button_text_color = get_theme_mod('cyber_security_services_pro_our_services_button_text_color');
	$cyber_security_services_pro_our_services_button_text_font = get_theme_mod('cyber_security_services_pro_our_services_button_text_font');	

	$cyber_security_services_pro_our_services_heading_color = get_theme_mod('cyber_security_services_pro_our_services_heading_color');
	$cyber_security_services_pro_our_services_heading_font = get_theme_mod('cyber_security_services_pro_our_services_heading_font');

	
	$cyber_security_services_pro_our_services_inner_heading_color = get_theme_mod('cyber_security_services_pro_our_services_inner_heading_color');

	$cyber_security_services_pro_our_services_inner_heading_font = get_theme_mod('cyber_security_services_pro_our_services_inner_heading_font');
	$cyber_security_services_pro_our_services_inner_text_color = get_theme_mod('cyber_security_services_pro_our_services_inner_text_color');

	$cyber_security_services_pro_our_services_inner_text_font = get_theme_mod('cyber_security_services_pro_our_services_inner_text_font');
		
	$cyber_security_services_pro_services_outer_btn_color = get_theme_mod('cyber_security_services_pro_services_outer_btn_color');
	$cyber_security_services_pro_services_outer_btn_font = get_theme_mod('cyber_security_services_pro_services_outer_btn_font');

	$cyber_security_services_pro_services_outer_btn_bgcolor = get_theme_mod('cyber_security_services_pro_services_outer_btn_bgcolor');
	$cyber_security_services_pro_services_outer_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_services_outer_btn_hover_bgcolor');

	$cyber_security_services_pro_services_outer_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_services_outer_btn_text_hover_color');	

	$cyber_security_services_pro_services_read_button_arrow_icon_color = get_theme_mod('cyber_security_services_pro_services_read_button_arrow_icon_color');

	$cyber_security_services_pro_services_read_button_arrow_icon_bgcolor = get_theme_mod('cyber_security_services_pro_services_read_button_arrow_icon_bgcolor');

	// --------------Experience--------------
	
	$cyber_security_services_pro_experience_head_color = get_theme_mod('cyber_security_services_pro_experience_head_color');

	$cyber_security_services_pro_experience_head_font = get_theme_mod('cyber_security_services_pro_experience_head_font');
	$cyber_security_services_pro_experience_button_color = get_theme_mod('cyber_security_services_pro_experience_button_color');

	$cyber_security_services_pro_experience_button_font = get_theme_mod('cyber_security_services_pro_experience_button_font');

	$cyber_security_services_pro_experience_button_bgcolor = get_theme_mod('cyber_security_services_pro_experience_button_bgcolor');
	$cyber_security_services_pro_experience_btn_hover_bgcolor = get_theme_mod('cyber_security_services_pro_experience_btn_hover_bgcolor');

	$cyber_security_services_pro_experience_btn_text_hover_color = get_theme_mod('cyber_security_services_pro_experience_btn_text_hover_color');

	$cyber_security_services_pro_experience_text_color = get_theme_mod('cyber_security_services_pro_experience_text_color');

	$cyber_security_services_pro_experience_text_font = get_theme_mod('cyber_security_services_pro_experience_text_font');
	

	// CONTACT COLOR SETTINGS
	$cyber_security_services_pro_contact_title_color = get_theme_mod('cyber_security_services_pro_contact_title_color');
	$cyber_security_services_pro_contact_title_font = get_theme_mod('cyber_security_services_pro_contact_title_font');

	$cyber_security_services_pro_contact_text_color = get_theme_mod('cyber_security_services_pro_contact_text_color');
	$cyber_security_services_pro_contact_text_font = get_theme_mod('cyber_security_services_pro_contact_text_font');

	$cyber_security_services_pro_contact_border_color = get_theme_mod('cyber_security_services_pro_contact_border_color');

	$cyber_security_services_pro_contact_info_title_color = get_theme_mod('cyber_security_services_pro_contact_info_title_color');
	$cyber_security_services_pro_contact_info_title_font = get_theme_mod('cyber_security_services_pro_contact_info_title_font');	

	$cyber_security_services_pro_contact_info_icon_color = get_theme_mod('cyber_security_services_pro_contact_info_icon_color');

	// Footer Widgets
	$cyber_security_services_pro_footer_widget_heading_color = get_theme_mod('cyber_security_services_pro_footer_widget_heading_color');
	$cyber_security_services_pro_footer_widget_heading_font_family = get_theme_mod('cyber_security_services_pro_footer_widget_heading_font_family');
	
	$cyber_security_services_pro_footer_widget_content_color = get_theme_mod('cyber_security_services_pro_footer_widget_content_color');
	$cyber_security_services_pro_footer_widget_content_font_family = get_theme_mod('cyber_security_services_pro_footer_widget_content_font_family');

	// Footer Copyright
	$cyber_security_services_pro_footer_copy_content_color = get_theme_mod('cyber_security_services_pro_footer_copy_content_color');
	$cyber_security_services_pro_footer_copy_content_font_family = get_theme_mod('cyber_security_services_pro_footer_copy_content_font_family');
	
	$cyber_security_services_pro_footer_social_icon_color = get_theme_mod('cyber_security_services_pro_footer_social_icon_color');

	$cyber_security_services_pro_footer_social_icon_bgcolor = get_theme_mod('cyber_security_services_pro_footer_social_icon_bgcolor');

    $custom_css ='';

	// SECTION SPACING

	if($cyber_security_services_pro_spacing_slider_top != false) {
		$custom_css .='#slider{';
			if($cyber_security_services_pro_spacing_slider_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_slider_top).'px !important;';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_spacing_about_top != false) {
		$custom_css .='section#about{';
			if($cyber_security_services_pro_spacing_about_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_about_top).'px;';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_spacing_our_video_top != false) {
		$custom_css .='#our_video{';
			if($cyber_security_services_pro_spacing_our_video_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_our_video_top).'px;';
	   	$custom_css .='}';
   	}	

	if($cyber_security_services_pro_spacing_latest_news_top != false) {
		$custom_css .='#latest_news{';
			if($cyber_security_services_pro_spacing_latest_news_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_latest_news_top).'px;';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_spacing_choose_us_top != false) {
		$custom_css .='#choose_us{';
			if($cyber_security_services_pro_spacing_choose_us_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_choose_us_top).'px;';
	   	$custom_css .='}';
   	}


   	if($cyber_security_services_pro_spacing_pricing_plan_top != false) {
		$custom_css .='#pricing-plan .pricing-tables,section#pricing-plan{';
			if($cyber_security_services_pro_spacing_pricing_plan_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_pricing_plan_top).'px;';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_spacing_achievement_top != false) {
		$custom_css .='#achievement{';
			if($cyber_security_services_pro_spacing_achievement_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_achievement_top).'px;';
	   	$custom_css .='}';
   	} 

	if($cyber_security_services_pro_spacing_sponsors_top != false) {
		$custom_css .='#sponsors{';
			if($cyber_security_services_pro_spacing_sponsors_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_sponsors_top).'px;';
	   	$custom_css .='}';
   	}  	


   if($cyber_security_services_pro_spacing_testimonials_top != false) {
		$custom_css .='#testimonials{';
			if($cyber_security_services_pro_spacing_testimonials_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_testimonials_top).'px;';
	   	$custom_css .='}';
   	} 

	if($cyber_security_services_pro_spacing_our_experts_top != false) {
		$custom_css .='#our_experts{';
			if($cyber_security_services_pro_spacing_our_experts_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_our_experts_top).'px;';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_spacing_new_project_top != false) {
		$custom_css .='#new_project{';
			if($cyber_security_services_pro_spacing_new_project_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_new_project_top).'px;';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_spacing_our_services_top != false) {
		$custom_css .='#our_services{';
			if($cyber_security_services_pro_spacing_our_services_top != false)
				$custom_css .='margin-top: '.esc_html($cyber_security_services_pro_spacing_our_services_top).'px;';
	   	$custom_css .='}';
   	}

   	// TOPBAR-COLOR SETTING
	
	if($cyber_security_services_pro_topbar_social_icon_color != false) {
 		$custom_css .='nav.socialbox i{';
 			if($cyber_security_services_pro_topbar_social_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_social_icon_color).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_topbar_mail_icon_color != false) {
 		$custom_css .='p.mail-det i{';
 			if($cyber_security_services_pro_topbar_mail_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_mail_icon_color).';';
		$custom_css .='}';
	}	

	if($cyber_security_services_pro_topbar_email_id_color != false || $cyber_security_services_pro_topbar_email_id_font != false) {
 		$custom_css .='a.top-mail {';
 			if($cyber_security_services_pro_topbar_email_id_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_email_id_color).';';
			if($cyber_security_services_pro_topbar_email_id_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_topbar_email_id_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_topbar_map_icon_color != false) {
 		$custom_css .=' p.add-det i{';
 			if($cyber_security_services_pro_topbar_map_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_map_icon_color).';';
		$custom_css .='}';
	}	

	if($cyber_security_services_pro_topbar_address_color != false || $cyber_security_services_pro_topbar_address_font != false) {
 		$custom_css .='a.top-address {';
 			if($cyber_security_services_pro_topbar_address_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_address_color).';';
			if($cyber_security_services_pro_topbar_address_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_topbar_address_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_topbar_call_icon_color != false) {
 		$custom_css .='p.call-det i{';
 			if($cyber_security_services_pro_topbar_call_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_call_icon_color).';';
		$custom_css .='}';
	}	

	if($cyber_security_services_pro_topbar_call_number_color != false || $cyber_security_services_pro_topbar_call_number_font != false) {
 		$custom_css .='a.top-call {';
 			if($cyber_security_services_pro_topbar_call_number_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_call_number_color).';';
			if($cyber_security_services_pro_topbar_call_number_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_topbar_call_number_font).';';
		$custom_css .='}';
	}


	if($cyber_security_services_pro_topbar_searchbtn_text_color != false || $cyber_security_services_pro_topbar_searchbtn_text_font != false || $cyber_security_services_pro_topbar_searchbtn_bgcolor != false) {
		$custom_css .='.header-search-wrapper .search-form-main .search-submit{';
			if($cyber_security_services_pro_topbar_searchbtn_text_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_topbar_searchbtn_text_color).';';
		  	if($cyber_security_services_pro_topbar_searchbtn_text_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_topbar_searchbtn_text_font).';
			   ';
			if($cyber_security_services_pro_topbar_searchbtn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_topbar_searchbtn_bgcolor).';';
	   	$custom_css .='}';
   	}
	



	
	//CONTENT-HEADER COLOR SETTINGS

	if($cyber_security_services_pro_header_search_icon_color != false || $cyber_security_services_pro_header_search_icon_bgcolor != false) {
 		$custom_css .='.search-main {';
 			if($cyber_security_services_pro_header_search_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_header_search_icon_color).';';
			if($cyber_security_services_pro_header_search_icon_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_header_search_icon_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_search_placeholder_color != false) {
 		$custom_css .='.serach-page [type="search"]::placeholder, input[type="search"]{';
 			if($cyber_security_services_pro_search_placeholder_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_search_placeholder_color).';';
		$custom_css .='}';
	}

	// LOGO & MENUS COLOR SETTINGS

	if($cyber_security_services_pro_logo_title_bgcolor != false ) {
 		$custom_css .='.logo{';
 			if($cyber_security_services_pro_logo_title_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_logo_title_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_logo_title_color != false || $cyber_security_services_pro_logo_title_font != false) {
 		$custom_css .='.logo h2 a{';
 			if($cyber_security_services_pro_logo_title_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_logo_title_color).';';
		    if($cyber_security_services_pro_logo_title_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_logo_title_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_logo_text_color != false || $cyber_security_services_pro_logo_text_font != false) {
 		$custom_css .='.logo p{';
 			if($cyber_security_services_pro_logo_text_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_logo_text_color).';';
		    if($cyber_security_services_pro_logo_text_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_logo_text_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_menu_text_color != false || $cyber_security_services_pro_menu_text_font != false) {
 		$custom_css .='.main-navigation a{';
 			if($cyber_security_services_pro_menu_text_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_menu_text_color).';';
		    if($cyber_security_services_pro_menu_text_font != false)
		    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_menu_text_font).';';
		$custom_css .='}';
	}
	
	if($cyber_security_services_pro_menu_text_font != false || $cyber_security_services_pro_menu_text_color != false || $cyber_security_services_pro_headermenu_font_size != false){
			$custom_css .='.menubar .nav ul li a{';
				if($cyber_security_services_pro_menu_text_font != false)
			    	$custom_css .='font-family: '.esc_html($cyber_security_services_pro_menu_text_font).';';
				if($cyber_security_services_pro_menu_text_color != false)
			    	$custom_css .='color: '.esc_html($cyber_security_services_pro_menu_text_color).';';
				if($cyber_security_services_pro_headermenu_font_size != false)
			    	$custom_css .='font-size: '.esc_html($cyber_security_services_pro_headermenu_font_size).'px;';
			$custom_css .='}';
	}

	if($cyber_security_services_pro_header_menuhovercolor != false){
			$custom_css .='.menubar .nav ul li a:hover{
				color: '.esc_html($cyber_security_services_pro_header_menuhovercolor).';
			}';
		}
		if($cyber_security_services_pro_dropdownbg_color != false){
			$custom_css .='.menubar .nav ul li:hover > ul{
				background: '.esc_html($cyber_security_services_pro_dropdownbg_color).';
			}';
		}
		if($cyber_security_services_pro_dropdownbg_itemcolor != false){
			$custom_css .='.menubar .nav ul li > ul > li a{
				color: '.esc_html($cyber_security_services_pro_dropdownbg_itemcolor).';
			}';
		}
		if($cyber_security_services_pro_dropdownbg_font_family != false){
			$custom_css .='.menubar .nav ul li > ul > li a{
				font-family: '.esc_html($cyber_security_services_pro_dropdownbg_font_family).';
			}';
		}
		if($cyber_security_services_pro_dropdownbg_font_size != false){
			$custom_css .='.menubar .nav ul li > ul > li a{
				font-size: '.esc_html($cyber_security_services_pro_dropdownbg_font_size).'px;
			}';
		}
		if($cyber_security_services_pro_dropdownbg_item_hovercolor != false){
			$custom_css .='.menubar .nav ul.sub-menu li:hover a{
				color: '.esc_html($cyber_security_services_pro_dropdownbg_item_hovercolor).';
			}';
		}
		if($cyber_security_services_pro_header_menu_active_color != false){
			$custom_css .='.header-wrap .current_page_item{
				background-color: '.esc_html($cyber_security_services_pro_header_menu_active_color).';
			}';
		}

	// SLIDER COLOR SETTINGS

	if($cyber_security_services_pro_slider_bgcolor != false) {
		$custom_css .='#slider{';
			if($cyber_security_services_pro_slider_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_slider_bgcolor).';';
	   	$custom_css .='}';
  	}

	if($cyber_security_services_pro_slider_opacity != false) {
		$custom_css .='#slider img{';
			if($cyber_security_services_pro_slider_opacity != false)
			   $custom_css .='opacity: '.esc_html($cyber_security_services_pro_slider_opacity).';';
	   	$custom_css .='}';
  	}
  	
	if($cyber_security_services_pro_slider_small_head_color != false || $cyber_security_services_pro_slider_small_head_font != false) {
		$custom_css .='h6.slide-sm-head{';
			if($cyber_security_services_pro_slider_small_head_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_small_head_color).';';
		   if($cyber_security_services_pro_slider_small_head_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_slider_small_head_font).';';
	   	$custom_css .='}';
   	}   

   	if($cyber_security_services_pro_slider_small_head_bgcolor != false ) {
		$custom_css .='h6.slide-sm-head{';
		if($cyber_security_services_pro_slider_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_slider_small_head_bgcolor).';';
		$custom_css .='}';
	}

  	if($cyber_security_services_pro_slider_title_color != false || $cyber_security_services_pro_slider_title_font != false) {
		$custom_css .='h1.slide-head{';
			if($cyber_security_services_pro_slider_title_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_title_color).';';
		   if($cyber_security_services_pro_slider_title_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_slider_title_font).';';
	   	$custom_css .='}';
   	}   	

	if($cyber_security_services_pro_slider_text_color != false || $cyber_security_services_pro_slider_text_font != false) {
		$custom_css .='p.slide-txt{';
			if($cyber_security_services_pro_slider_text_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_text_color).';';
		   if($cyber_security_services_pro_slider_text_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_slider_text_font).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_slider_quotebtn_text_color != false || $cyber_security_services_pro_slider_quotebtn_text_font != false || $cyber_security_services_pro_slider_quotebtn_bgcolor != false) {
		$custom_css .='a.slid-quote-btn{';
			if($cyber_security_services_pro_slider_quotebtn_text_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_quotebtn_text_color).';';
		  	if($cyber_security_services_pro_slider_quotebtn_text_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_slider_quotebtn_text_font).';
			   ';
			if($cyber_security_services_pro_slider_quotebtn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_slider_quotebtn_bgcolor).';';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_slider_read_btn_text_color != false || $cyber_security_services_pro_slider_read_btn_text_font != false || $cyber_security_services_pro_slider_read_btn_bgcolor != false) {
		$custom_css .='a.slid-start-btn{';
			if($cyber_security_services_pro_slider_read_btn_text_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_read_btn_text_color).';';
		  	if($cyber_security_services_pro_slider_read_btn_text_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_slider_read_btn_text_font).';
			   ';
			if($cyber_security_services_pro_slider_read_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_slider_read_btn_bgcolor).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_slider_btn_hover_bgcolor != false || $cyber_security_services_pro_slider_btn_texthover_color != false) {
		$custom_css .='.slide_btn a:hover{';
			if($cyber_security_services_pro_slider_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_slider_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_slider_btn_texthover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_slider_btn_texthover_color).';';
	   	$custom_css .='}';
   	}

   	// About COLOR SETTINGS

	if($cyber_security_services_pro_about_small_head_color != false || $cyber_security_services_pro_about_small_head_font != false) {
		$custom_css .='h6.abt-sm-head{';
			if($cyber_security_services_pro_about_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_about_small_head_color).';';
			if($cyber_security_services_pro_about_small_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_about_small_head_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_about_heading_color != false || $cyber_security_services_pro_about_heading_font != false) {
		$custom_css .='h2.abt-main-head{';
			if($cyber_security_services_pro_about_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_about_heading_color).';';
			if($cyber_security_services_pro_about_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_about_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_about_text_color != false || $cyber_security_services_pro_about_text_font != false) {
		$custom_css .='p.abt-para{';
			if($cyber_security_services_pro_about_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_about_text_color).';';
			if($cyber_security_services_pro_about_text_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_about_text_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_about_btn_color != false || $cyber_security_services_pro_about_btn_font != false || $cyber_security_services_pro_about_btn_bgcolor != false) {
		$custom_css .='a.abt-read-btn{';
			if($cyber_security_services_pro_about_btn_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_about_btn_color).';';
		  	if($cyber_security_services_pro_about_btn_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_about_btn_font).';
			   ';
			if($cyber_security_services_pro_about_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_about_btn_bgcolor).';';
	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_about_btn_hover_bgcolor != false || $cyber_security_services_pro_about_box_btn_text_hover_color != false) {
		$custom_css .='a.abt-read-btn:hover{';
			if($cyber_security_services_pro_about_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_about_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_about_box_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_about_box_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}

	if($cyber_security_services_pro_about_small_head_bgcolor != false ) {
		$custom_css .='h6.abt-sm-head{';
		if($cyber_security_services_pro_about_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_about_small_head_bgcolor).';';
		$custom_css .='}';
	}

		// -------------ACHIEVEMENT--------------


	if($cyber_security_services_pro_achievement_main_head_color != false || $cyber_security_services_pro_achievement_main_head_font != false) {
		$custom_css .='h3.achieve-head{';
			if($cyber_security_services_pro_achievement_main_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_achievement_main_head_color).';';
			if($cyber_security_services_pro_achievement_main_head_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_achievement_main_head_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_achievement_text_color != false || $cyber_security_services_pro_achievement_text_font != false) {
		$custom_css .='h4.achieve-left-txt{';
			if($cyber_security_services_pro_achievement_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_achievement_text_color).';';
			if($cyber_security_services_pro_achievement_text_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_achievement_text_font).';';
		$custom_css .='}';
	}


	if($cyber_security_services_pro_achievement_count_color != false || $cyber_security_services_pro_achievement_count_font != false) {
		$custom_css .='h3.achieve-count{';
			if($cyber_security_services_pro_achievement_count_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_achievement_count_color).';';
			if($cyber_security_services_pro_achievement_count_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_achievement_count_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_achievement_inner_heading_color != false || $cyber_security_services_pro_achievement_inner_heading_font != false) {
		$custom_css .='p.achieve-inner-head{';
			if($cyber_security_services_pro_achievement_inner_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_achievement_inner_heading_color).';';
			if($cyber_security_services_pro_achievement_inner_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_achievement_inner_heading_font).';';
		$custom_css .='}';
	}


	// Our Services COLOR SETTING

	if($cyber_security_services_pro_our_services_button_text_color != false || $cyber_security_services_pro_our_services_button_text_font != false) {
		$custom_css .='a.serv-inn-btn{';
			if($cyber_security_services_pro_our_services_button_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_services_button_text_color).';';
			if($cyber_security_services_pro_our_services_button_text_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_services_button_text_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_services_heading_color != false || $cyber_security_services_pro_our_services_heading_font != false) {
		$custom_css .='h2.service-main-head{';
			if($cyber_security_services_pro_our_services_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_services_heading_color).';';
			if($cyber_security_services_pro_our_services_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_services_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_services_small_head_color != false || $cyber_security_services_pro_our_services_small_head_font != false) {
		$custom_css .='h6.service-sm-head{';
			if($cyber_security_services_pro_our_services_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_services_small_head_color).';';
			if($cyber_security_services_pro_our_services_small_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_services_small_head_font).';';
		$custom_css .='}';
	}


   	if($cyber_security_services_pro_our_services_small_head_bgcolor != false ) {
		$custom_css .='h6.service-sm-head{';
		if($cyber_security_services_pro_our_services_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_our_services_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_services_inner_heading_color != false || $cyber_security_services_pro_our_services_inner_heading_font != false) {
		$custom_css .='h5.serv-name a{';
			if($cyber_security_services_pro_our_services_inner_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_services_inner_heading_color).';';
			if($cyber_security_services_pro_our_services_inner_heading_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_services_inner_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_services_inner_text_color != false || $cyber_security_services_pro_our_services_inner_text_font != false) {
		$custom_css .='p.serv-inn-txt{';
			if($cyber_security_services_pro_our_services_inner_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_services_inner_text_color).';';
			if($cyber_security_services_pro_our_services_inner_text_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_services_inner_text_font).';';
		$custom_css .='}';
	}
	

	if($cyber_security_services_pro_services_outer_btn_color != false || $cyber_security_services_pro_services_outer_btn_font != false || $cyber_security_services_pro_services_outer_btn_bgcolor != false) {
		$custom_css .='a.serv-outr-btn{';
			if($cyber_security_services_pro_services_outer_btn_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_services_outer_btn_color).';';
		  	if($cyber_security_services_pro_services_outer_btn_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_services_outer_btn_font).';
			   ';
			if($cyber_security_services_pro_services_outer_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_services_outer_btn_bgcolor).';';
	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_services_outer_btn_hover_bgcolor != false || $cyber_security_services_pro_services_outer_btn_text_hover_color != false) {
		$custom_css .='a.serv-outr-btn:hover{';
			if($cyber_security_services_pro_services_outer_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_services_outer_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_services_outer_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_services_outer_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}  	

   	if($cyber_security_services_pro_services_read_button_arrow_icon_color != false) {
 		$custom_css .='a.serv-inn-btn i{';
 			if($cyber_security_services_pro_services_read_button_arrow_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_services_read_button_arrow_icon_color).';';
		$custom_css .='}';
	}

   	if($cyber_security_services_pro_services_read_button_arrow_icon_bgcolor != false){
		$custom_css .='a.serv-inn-btn i{';
			if($cyber_security_services_pro_services_read_button_arrow_icon_bgcolor != false)
				$custom_css .='background: '.esc_html($cyber_security_services_pro_services_read_button_arrow_icon_bgcolor).';';
		$custom_css .='}';
	}

	// ------------- Choose Us --------------

	if($cyber_security_services_pro_choose_us_small_heading_color != false || $cyber_security_services_pro_choose_us_small_heading_font_family != false){
		$custom_css .='h6.choose-sm-head{';
			if($cyber_security_services_pro_choose_us_small_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_small_heading_color).';';
			if($cyber_security_services_pro_choose_us_small_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_choose_us_small_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_small_head_bgcolor != false ) {
		$custom_css .='h6.choose-sm-head{';
		if($cyber_security_services_pro_choose_us_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_choose_us_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_main_heading_color != false || $cyber_security_services_pro_choose_us_main_heading_font_family != false){
		$custom_css .='h2.choose-head{';
			if($cyber_security_services_pro_choose_us_main_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_main_heading_color).';';
			if($cyber_security_services_pro_choose_us_main_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_choose_us_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_text_color != false || $cyber_security_services_pro_choose_us_text_font_family != false){
		$custom_css .='p.choose-text{';
			if($cyber_security_services_pro_choose_us_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_text_color).';';
			if($cyber_security_services_pro_choose_us_text_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_choose_us_text_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_right_head_color != false || $cyber_security_services_pro_choose_us_right_head_font_family != false){
		$custom_css .='h6.choose-right-head{';
			if($cyber_security_services_pro_choose_us_right_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_right_head_color).';';
			if($cyber_security_services_pro_choose_us_right_head_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_choose_us_right_head_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_inner_smhead_color != false || $cyber_security_services_pro_choose_us_inner_smhead_font_family != false){
		$custom_css .='h6.choslist-item1{';
			if($cyber_security_services_pro_choose_us_inner_smhead_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_inner_smhead_color).';';
			if($cyber_security_services_pro_choose_us_inner_smhead_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_choose_us_inner_smhead_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_choose_us_right_list_color != false || $cyber_security_services_pro_choose_us_right_list_font_family != false) {
		$custom_css .='h6.choslist1{';
			if($cyber_security_services_pro_choose_us_right_list_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_right_list_color).';';
			if($cyber_security_services_pro_choose_us_right_list_font_family != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_choose_us_right_list_font_family).';';
		$custom_css .='}';
	}

if($cyber_security_services_pro_choose_us_btn_color != false || $cyber_security_services_pro_choose_us_btn_font != false || $cyber_security_services_pro_choose_us_btn_bgcolor != false) {
		$custom_css .='a.choose-read-btn{';
			if($cyber_security_services_pro_choose_us_btn_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_btn_color).';';
		  	if($cyber_security_services_pro_choose_us_btn_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_choose_us_btn_font).';
			   ';
			if($cyber_security_services_pro_choose_us_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_choose_us_btn_bgcolor).';';
	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_choose_us_btn_hover_bgcolor != false || $cyber_security_services_pro_choose_us_box_btn_text_hover_color != false) {
		$custom_css .='a.choose-read-btn:hover{';
			if($cyber_security_services_pro_choose_us_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_choose_us_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_choose_us_box_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_choose_us_box_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}

   	// PRICING PLAN COLOR SETTING

  
	if($cyber_security_services_pro_pricing_plan_small_head_bgcolor != false ) {
		$custom_css .='h6.plan-sm-head{';
		if($cyber_security_services_pro_pricing_plan_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_pricing_plan_small_heading_color != false || $cyber_security_services_pro_pricing_plan_small_heading_font_family != false) {
		$custom_css .='h6.plan-sm-head{';
			if($cyber_security_services_pro_pricing_plan_small_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_small_heading_color).';';
			if($cyber_security_services_pro_pricing_plan_small_heading_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_small_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_pricing_plan_main_heading_color != false || $cyber_security_services_pro_pricing_plan_main_heading_font_family != false) {
		$custom_css .='h2.plan-main-head{';
			if($cyber_security_services_pro_pricing_plan_main_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_main_heading_color).';';
			if($cyber_security_services_pro_pricing_plan_main_heading_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_pricing_plan_tab_title_color != false || $cyber_security_services_pro_pricing_plan_tab_title_font_family != false) {
		$custom_css .='.plan-tabs span,.pricing-tables .switch span{';
			if($cyber_security_services_pro_pricing_plan_tab_title_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_tab_title_color).';';
			if($cyber_security_services_pro_pricing_plan_tab_title_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_tab_title_font_family).';';
		$custom_css .='}';
	}

if($cyber_security_services_pro_pricing_plan_box_bgcolor != false) {
	$custom_css .='.inner-plan-box{';

	if($cyber_security_services_pro_pricing_plan_box_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_box_bgcolor).';';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_pricing_plan_price_color != false || $cyber_security_services_pro_pricing_plan_price_font_family != false) {
		$custom_css .='h2.plans-price,span.price-per,.pricing-tables .plans .plan .plan__head .plan__price .price .plan__type{';
			if($cyber_security_services_pro_pricing_plan_price_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_price_color).';';
			if($cyber_security_services_pro_pricing_plan_price_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_price_font_family).';';
		$custom_css .='}';
	}	

   	if($cyber_security_services_pro_pricing_plan_pack_option_title_color != false || $cyber_security_services_pro_pricing_plan_pack_option_title_font_family != false) {
		$custom_css .='h6.pack-option{';
			if($cyber_security_services_pro_pricing_plan_pack_option_title_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_pack_option_title_color).';';
			if($cyber_security_services_pro_pricing_plan_pack_option_title_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_pack_option_title_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_pricing_plan_inner_text_color != false || $cyber_security_services_pro_pricing_plan_inner_text_font_family != false) {
		$custom_css .='p.pack-txt{';
			if($cyber_security_services_pro_pricing_plan_inner_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_inner_text_color).';';
			if($cyber_security_services_pro_pricing_plan_inner_text_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_inner_text_font_family).';';
		$custom_css .='}';
	}	

if($cyber_security_services_pro_pricing_plan_feature_color != false || $cyber_security_services_pro_pricing_plan_features_font_family != false) {
		$custom_css .='#pricing-plan ul.plan-list li,p.planlist-item{';
			if($cyber_security_services_pro_pricing_plan_feature_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_feature_color).';';
			if($cyber_security_services_pro_pricing_plan_features_font_family != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_features_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_pricing_plan_tick_icon_color != false || $cyber_security_services_pro_pricing_plan_tick_icon_bgcolor != false) {
 		$custom_css .='p.planlist-item i{';
 			if($cyber_security_services_pro_pricing_plan_tick_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_tick_icon_color).';';
			if($cyber_security_services_pro_pricing_plan_tick_icon_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_tick_icon_bgcolor).';';
		$custom_css .='}';
	}


   	if($cyber_security_services_pro_pricing_plan_button_color != false || $cyber_security_services_pro_pricing_plan_button_font_family != false || $cyber_security_services_pro_pricing_plan_button_bgcolor != false) {
		$custom_css .='a.plan-btn{';
			if($cyber_security_services_pro_pricing_plan_button_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_button_color).';';
		  	if($cyber_security_services_pro_pricing_plan_button_font_family != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_pricing_plan_button_font_family).';
			   ';
			if($cyber_security_services_pro_pricing_plan_button_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_button_bgcolor).';';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_pricing_plan_btn_hover_bgcolor != false || $cyber_security_services_pro_pricing_plan_box_btn_text_hover_color != false) {
		$custom_css .='a.plan-btn:hover{';
			if($cyber_security_services_pro_pricing_plan_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_btn_hover_bgcolor).' !important;';
			if($cyber_security_services_pro_pricing_plan_box_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_pricing_plan_box_btn_text_hover_color).' !important;';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_pricing_plan_hover_bgcolor != false) {
	$custom_css .='.inner-plan-box:hover{';

	if($cyber_security_services_pro_pricing_plan_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_pricing_plan_hover_bgcolor).';';
	   	$custom_css .='}';
   	}

	 	//-------------- OUR VIDEO COLOR SETTING--------

	if($cyber_security_services_pro_our_video_small_head_color != false || $cyber_security_services_pro_our_video_small_head_font_family != false) {
		$custom_css .='h6.video-sm-head{';
			if($cyber_security_services_pro_our_video_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_small_head_color).';';
			if($cyber_security_services_pro_our_video_small_head_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_video_small_head_font_family).';';
		$custom_css .='}';
	}
  
	if($cyber_security_services_pro_our_video_small_head_bgcolor != false ) {
		$custom_css .='h6.video-sm-head{';
		if($cyber_security_services_pro_our_video_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_our_video_small_head_bgcolor).';';
		$custom_css .='}';
	}


	if($cyber_security_services_pro_our_video_main_heading_color != false || $cyber_security_services_pro_our_video_main_heading_font_family != false) {
		$custom_css .='h2.video-main-head{';
			if($cyber_security_services_pro_our_video_main_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_main_heading_color).';';
			if($cyber_security_services_pro_our_video_main_heading_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_video_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_video_text_color != false || $cyber_security_services_pro_our_video_text_font_family != false) {
		$custom_css .='p.video-text{';
			if($cyber_security_services_pro_our_video_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_text_color).';';
			if($cyber_security_services_pro_our_video_text_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_video_text_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_video_nav_text_color != false || $cyber_security_services_pro_our_video_nav_text_font_family != false) {
		$custom_css .='h6.video-nav-text{';
			if($cyber_security_services_pro_our_video_nav_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_nav_text_color).';';
			if($cyber_security_services_pro_our_video_nav_text_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_video_nav_text_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_video_btn_icon_color != false || $cyber_security_services_pro_our_video_btn_icon_bgcolor != false) {
 		$custom_css .='section#our_video a.popup-youtube,a.popup-youtube{';
 			if($cyber_security_services_pro_our_video_btn_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_btn_icon_color).';';
			if($cyber_security_services_pro_our_video_btn_icon_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_our_video_btn_icon_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_video_nav_icon_color != false || $cyber_security_services_pro_our_video_nav_icon_bgcolor != false) {
 		$custom_css .='section#our_video button.owl-prev i, section#our_video button.owl-next i,section#our_video button.owl-prev, section#our_video button.owl-next{';
 			if($cyber_security_services_pro_our_video_nav_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_our_video_nav_icon_color).';';
			if($cyber_security_services_pro_our_video_nav_icon_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_our_video_nav_icon_bgcolor).';';
		$custom_css .='}';
	}


	// LATEST NEWS COLOR SETTINGS

	if($cyber_security_services_pro_latest_news_comment_icon_color != false ) {
		$custom_css .='span.entry-comments i{';
			if($cyber_security_services_pro_latest_news_comment_icon_color != false)
			$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_comment_icon_color).';';
		$custom_css .='}';
	}


	if($cyber_security_services_pro_latest_news_outer_btn_color != false || $cyber_security_services_pro_latest_news_outer_btn_font != false || $cyber_security_services_pro_latest_news_outer_btn_bgcolor != false) {
		$custom_css .='a.blog-outr-btn{';
			if($cyber_security_services_pro_latest_news_outer_btn_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_outer_btn_color).';';
		  	if($cyber_security_services_pro_latest_news_outer_btn_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_outer_btn_font).';
			   ';
			if($cyber_security_services_pro_latest_news_outer_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_outer_btn_bgcolor).';';
	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor != false || $cyber_security_services_pro_latest_news_outer_btn_text_hover_color != false) {
		$custom_css .='a.blog-outr-btn:hover{';
			if($cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_outer_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_latest_news_outer_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_outer_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}


	if($cyber_security_services_pro_latest_news_comment_color != false || $cyber_security_services_pro_latest_news_comment_font != false) {
		$custom_css .='span.entry-comments{';
			if($cyber_security_services_pro_latest_news_comment_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_comment_color).';';
			if($cyber_security_services_pro_latest_news_comment_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_comment_font).';';
		$custom_css .='}';
	}
	

	if($cyber_security_services_pro_latest_news_heading_color != false || $cyber_security_services_pro_latest_news_heading_font != false) {
		$custom_css .='h2.news-main-head{';
			if($cyber_security_services_pro_latest_news_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_heading_color).';';
			if($cyber_security_services_pro_latest_news_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_latest_news_heading_font != false) {
		$custom_css .='h2.news-main-head{';
		if($cyber_security_services_pro_latest_news_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_heading_font).';';
		$custom_css .='}';

	}

	if($cyber_security_services_pro_latest_news_small_head_color != false || $cyber_security_services_pro_latest_news_small_head_font != false) {
		$custom_css .='h6.news-sm-head{';
			if($cyber_security_services_pro_latest_news_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_small_head_color).';';
			if($cyber_security_services_pro_latest_news_small_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_small_head_font).';';
		$custom_css .='}';
	}
  
	if($cyber_security_services_pro_latest_news_small_head_bgcolor != false ) {
		$custom_css .='h6.news-sm-head{';
		if($cyber_security_services_pro_latest_news_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_latest_news_post_admin_color != false || $cyber_security_services_pro_latest_news_post_admin_font != false) {
		$custom_css .='span.entry-author,span.entry-author a{';
			if($cyber_security_services_pro_latest_news_post_admin_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_post_admin_color).';';
			if($cyber_security_services_pro_latest_news_post_admin_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_post_admin_font).';';
		$custom_css .='}';
	}
	
	if($cyber_security_services_pro_latest_news_post_heading_color != false || $cyber_security_services_pro_latest_news_post_heading_font != false) {
		$custom_css .='h5.post-title a,.news-inn-title,h3.post-title a,h3.post-title{';
			if($cyber_security_services_pro_latest_news_post_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_post_heading_color).';';
			if($cyber_security_services_pro_latest_news_post_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_post_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_latest_news_post_text_color != false || $cyber_security_services_pro_latest_news_post_text_font != false) {
		$custom_css .='p.news-post-content,p.news-post-txt,p.news-post-txt{';
			if($cyber_security_services_pro_latest_news_post_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_post_text_color).';';
			if($cyber_security_services_pro_latest_news_post_text_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_post_text_font).';';
		$custom_css .='}';
	}

	
	// if($cyber_security_services_pro_latest_news_date_color != false || $cyber_security_services_pro_latest_news_date_font != false) {
	// 	$custom_css .='span.post-date,.date-admin,.blog-date h3{';
	// 		if($cyber_security_services_pro_latest_news_date_color != false)
	// 			$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_date_color).' !important;';
	// 		if($cyber_security_services_pro_latest_news_date_font != false)
	// 		$custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_date_font).';';
	// 	$custom_css .='}';
	// }

	// if($cyber_security_services_pro_latest_news_box_bgcolor != false) {
	// 	$custom_css .='.lower-new-box{';
	// 		if($cyber_security_services_pro_latest_news_box_bgcolor != false)
	// 			$custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_box_bgcolor).';';
	// 	$custom_css .='}';
	// }

	if($cyber_security_services_pro_latest_news_read_button_color != false || $cyber_security_services_pro_latest_news_read_button_font_family != false || $cyber_security_services_pro_latest_news_read_button_bgcolor != false) {
		$custom_css .='.news-button a,a.news-btn{';
			if($cyber_security_services_pro_latest_news_read_button_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_read_button_color).';';
		  	if($cyber_security_services_pro_latest_news_read_button_font_family != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_latest_news_read_button_font_family).';
			   ';
			if($cyber_security_services_pro_latest_news_read_button_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_read_button_bgcolor).';';
	   	$custom_css .='}';
   	}

   	if($cyber_security_services_pro_latest_news_read_button_arrow_icon_color != false) {
 		$custom_css .='a.news-btn i{';
 			if($cyber_security_services_pro_latest_news_read_button_arrow_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_latest_news_read_button_arrow_icon_color).';';
		$custom_css .='}';
	}

   	if($cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor != false){
		$custom_css .='a.news-btn i {';
			if($cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor != false)
				$custom_css .='background: '.esc_html($cyber_security_services_pro_latest_news_read_button_arrow_icon_bgcolor).';';
		$custom_css .='}';
	}
	
	// TESTIMONIALS COLOR SETTING

	if($cyber_security_services_pro_testimonials_designation_color != false || $cyber_security_services_pro_testimonials_designation_font != false) {
		$custom_css .='h6.testi-desig{';
			if($cyber_security_services_pro_testimonials_designation_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_designation_color).';';
			if($cyber_security_services_pro_testimonials_designation_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_testimonials_designation_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_testimonials_heading_color != false || $cyber_security_services_pro_testimonials_heading_font != false) {
		$custom_css .='h2.testi-main-head{';
			if($cyber_security_services_pro_testimonials_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_heading_color).';';
			if($cyber_security_services_pro_testimonials_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_testimonials_heading_font).';';
		$custom_css .='}';
	}
	
	if($cyber_security_services_pro_testimonials_content_bgcolor != false ) {
		$custom_css .='.testi-box{';
		if($cyber_security_services_pro_testimonials_content_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_testimonials_content_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_testimonials_small_head_color != false || $cyber_security_services_pro_testimonials_small_head_font != false) {
		$custom_css .='h6.testi-sm-head{';
			if($cyber_security_services_pro_testimonials_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_small_head_color).';';
			if($cyber_security_services_pro_testimonials_small_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_testimonials_small_head_font).';';
		$custom_css .='}';
	}
  
	if($cyber_security_services_pro_testimonials_small_head_bgcolor != false ) {
		$custom_css .='h6.testi-sm-head{';
		if($cyber_security_services_pro_testimonials_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_testimonials_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_testimonials_inner_text_color != false || $cyber_security_services_pro_testimonials_inner_text_font != false) {
		$custom_css .='p.testi-text{';
			if($cyber_security_services_pro_testimonials_inner_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_inner_text_color).';';
			if($cyber_security_services_pro_testimonials_inner_text_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_testimonials_inner_text_font).';';
		$custom_css .='}';
	}
	
	if($cyber_security_services_pro_testimonials_name_color != false || $cyber_security_services_pro_testimonials_name_font != false) {
		$custom_css .='h3.testi-name{';
			if($cyber_security_services_pro_testimonials_name_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_name_color).' !important;';
			if($cyber_security_services_pro_testimonials_name_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_testimonials_name_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_testimonials_quote_icon_color != false ) {
		$custom_css .='.test-quote1{';
			if($cyber_security_services_pro_testimonials_quote_icon_color != false)
			$custom_css .='color: '.esc_html($cyber_security_services_pro_testimonials_quote_icon_color).';';
		$custom_css .='}';
	}

	// OUR EXPERTS Color Setting

	if($cyber_security_services_pro_our_experts_hr_color != false ) {
		$custom_css .='hr.exper-hr,hr.exper-hr:before{';
		if($cyber_security_services_pro_our_experts_hr_color != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_our_experts_hr_color).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_small_head_color != false || $cyber_security_services_pro_our_experts_small_head_font != false) {
		$custom_css .='h6.staff-sm-head{';
			if($cyber_security_services_pro_our_experts_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_small_head_color).';';
			if($cyber_security_services_pro_our_experts_small_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_experts_small_head_font).';';
		$custom_css .='}';
	}  
  
	if($cyber_security_services_pro_our_experts_small_head_bgcolor != false ) {
		$custom_css .='h6.staff-sm-head{';
		if($cyber_security_services_pro_our_experts_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_our_experts_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_heading_color != false || $cyber_security_services_pro_our_experts_heading_font != false) {
		$custom_css .='h2.staff-main-head{';
			if($cyber_security_services_pro_our_experts_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_heading_color).';';
			if($cyber_security_services_pro_our_experts_heading_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_experts_heading_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_social_icon_color != false) {
 		$custom_css .='.staff-social-icon a i{';
 			if($cyber_security_services_pro_our_experts_social_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_social_icon_color).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_social_icon_bgcolor != false){
		$custom_css .='.staff-social-icon a {';
			if($cyber_security_services_pro_our_experts_social_icon_bgcolor != false)
				$custom_css .='background: '.esc_html($cyber_security_services_pro_our_experts_social_icon_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_name_color != false || $cyber_security_services_pro_our_experts_name_font != false) {
		$custom_css .='h5.staff-name a{';
			if($cyber_security_services_pro_our_experts_name_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_name_color).';';
			if($cyber_security_services_pro_our_experts_name_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_experts_name_font).';';
		$custom_css .='}';
	}
	
	if($cyber_security_services_pro_our_experts_designation_color != false || $cyber_security_services_pro_our_experts_designation_font != false) {
		$custom_css .='p.staff-desig{';
			if($cyber_security_services_pro_our_experts_designation_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_designation_color).';';
			if($cyber_security_services_pro_our_experts_designation_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_experts_designation_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_our_experts_outer_btn_color != false || $cyber_security_services_pro_our_experts_outer_btn_font != false || $cyber_security_services_pro_our_experts_outer_btn_bgcolor != false) {
		$custom_css .='a.exper-outr-btn{';
			if($cyber_security_services_pro_our_experts_outer_btn_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_outer_btn_color).';';
		  	if($cyber_security_services_pro_our_experts_outer_btn_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_our_experts_outer_btn_font).';
			   ';
			if($cyber_security_services_pro_our_experts_outer_btn_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_our_experts_outer_btn_bgcolor).'!important;';
				$custom_css .='z-index:unset';

	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor != false || $cyber_security_services_pro_our_experts_outer_btn_text_hover_color != false) {
		$custom_css .='a.exper-outr-btn:hover{';
			if($cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_our_experts_outer_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_our_experts_outer_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_our_experts_outer_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}  	

	// SPONSERS COLOR SETTING

	if($cyber_security_services_pro_sponsors_small_head_color != false || $cyber_security_services_pro_sponsors_small_head_font_family != false) {
		$custom_css .='h6.sponsor-sm-head{';
			if($cyber_security_services_pro_sponsors_small_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_sponsors_small_head_color).';';
			if($cyber_security_services_pro_sponsors_small_head_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_sponsors_small_head_font_family).';';
		$custom_css .='}';
	}
  
	if($cyber_security_services_pro_sponsors_small_head_bgcolor != false ) {
		$custom_css .='h6.sponsor-sm-head{';
		if($cyber_security_services_pro_sponsors_small_head_bgcolor != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_sponsors_small_head_bgcolor).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_sponsors_main_heading_color != false || $cyber_security_services_pro_sponsors_main_heading_font_family != false) {
		$custom_css .='h2.sponsor-head{';
			if($cyber_security_services_pro_sponsors_main_heading_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_sponsors_main_heading_color).';';
			if($cyber_security_services_pro_sponsors_main_heading_font_family != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_sponsors_main_heading_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_sponsors_nav_icon_color != false || $cyber_security_services_pro_sponsors_nav_icon_bgcolor != false) {
 		$custom_css .='section#sponsors button.owl-prev i, section#sponsors button.owl-next i,section#sponsors button.owl-prev,section#sponsors button.owl-next{';
 			if($cyber_security_services_pro_sponsors_nav_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_sponsors_nav_icon_color).';';
			if($cyber_security_services_pro_sponsors_nav_icon_bgcolor != false)
		    	$custom_css .='background: '.esc_html($cyber_security_services_pro_sponsors_nav_icon_bgcolor).';';
		$custom_css .='}';
	}

	// -------------INTRO------------------

	if($cyber_security_services_pro_experience_head_color != false || $cyber_security_services_pro_experience_head_font != false) {
		$custom_css .='h2.intro-main-head{';
			if($cyber_security_services_pro_experience_head_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_experience_head_color).' !important;';
			if($cyber_security_services_pro_experience_head_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_experience_head_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_experience_text_color != false || $cyber_security_services_pro_experience_text_font != false) {
		$custom_css .='h6.intro-para{';
			if($cyber_security_services_pro_experience_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_experience_text_color).' !important;';
			if($cyber_security_services_pro_experience_text_font != false)
			$custom_css .='font-family: '.esc_html($cyber_security_services_pro_experience_text_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_experience_button_color != false || $cyber_security_services_pro_experience_button_font != false || $cyber_security_services_pro_experience_button_bgcolor != false) {
		$custom_css .='a.intro-btn{';
			if($cyber_security_services_pro_experience_button_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_experience_button_color).';';
		  	if($cyber_security_services_pro_experience_button_font != false)
			   $custom_css .='font-family: '.esc_html($cyber_security_services_pro_experience_button_font).';
			   ';
			if($cyber_security_services_pro_experience_button_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_experience_button_bgcolor).';';
	   	$custom_css .='}';
   	}
	
	if($cyber_security_services_pro_experience_btn_hover_bgcolor != false || $cyber_security_services_pro_experience_btn_text_hover_color != false) {
		$custom_css .='a.intro-btn:hover{';
			if($cyber_security_services_pro_experience_btn_hover_bgcolor != false)
			   $custom_css .='background: '.esc_html($cyber_security_services_pro_experience_btn_hover_bgcolor).';';
			if($cyber_security_services_pro_experience_btn_text_hover_color != false)
			   $custom_css .='color: '.esc_html($cyber_security_services_pro_experience_btn_text_hover_color).';';
	   	$custom_css .='}';
   	}

	
	// CONTACT COLOR SETTINGS

	if($cyber_security_services_pro_contact_title_color != false || $cyber_security_services_pro_contact_title_font != false) {
		$custom_css .='.contact-info h3{';
			if($cyber_security_services_pro_contact_title_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_contact_title_color).';';
			if($cyber_security_services_pro_contact_title_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_contact_title_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_contact_text_color != false || $cyber_security_services_pro_contact_text_font != false) {
		$custom_css .='.contact-info p{';
			if($cyber_security_services_pro_contact_text_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_contact_text_color).';';
			if($cyber_security_services_pro_contact_text_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_contact_text_font).';';
		$custom_css .='}';
	}

	// if($cyber_security_services_pro_contact_border_color != false ) {
	// 	$custom_css .='.contact-info hr.first,.contact-info hr.second{';
	// 		if($cyber_security_services_pro_contact_border_color != false)
	// 			$custom_css .='background: '.esc_html($cyber_security_services_pro_contact_border_color).';';
	// 	$custom_css .='}';
	// }
	if($cyber_security_services_pro_contact_border_color != false ) {
		$custom_css .='.contact-info h3:after{';
		if($cyber_security_services_pro_contact_border_color != false)
			$custom_css .='background: '.esc_html($cyber_security_services_pro_contact_border_color).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_contact_info_title_color != false || $cyber_security_services_pro_contact_info_title_font != false) {
		$custom_css .='.call0 h6,.contact-info h6 span{';
			if($cyber_security_services_pro_contact_info_title_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_contact_info_title_color).';';
			if($cyber_security_services_pro_contact_info_title_font != false)
				$custom_css .='font-family: '.esc_html($cyber_security_services_pro_contact_info_title_font).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_contact_info_icon_color != false) {
 		$custom_css .='i.contactpage-phone-icon, i.contactpage-email-icon, i.contactpage-add-icon{';
 			if($cyber_security_services_pro_contact_info_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_contact_info_icon_color).';';
		$custom_css .='}';
	}

	// FOOTER WIDGETS

	if($cyber_security_services_pro_footer_widget_heading_color != false || $cyber_security_services_pro_footer_widget_heading_font_family != false){
		$custom_css .='h2.ft1-head, h3.widget-title, h2.ft4-head,.footer4 h3{';
			if($cyber_security_services_pro_footer_widget_heading_color != false)
				$custom_css .='color:'.esc_html($cyber_security_services_pro_footer_widget_heading_color).';';
			if($cyber_security_services_pro_footer_widget_heading_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_footer_widget_heading_font_family).';';
		$custom_css .='}';
	}
	if($cyber_security_services_pro_footer_widget_content_color != false || $cyber_security_services_pro_footer_widget_content_font_family != false){
		$custom_css .='p.ft1-para, ul#menu-ot_legal_menu li a, ul#menu-ot_link_menu li a, p.ftr4-para,p.ftr1-call,p.ftr1-mail,ul#menu-ot_info_menu li a,p.ftr-follow,.ftr-note{';
			if($cyber_security_services_pro_footer_widget_content_color != false)
				$custom_css .='color:'.esc_html($cyber_security_services_pro_footer_widget_content_color).';';
			if($cyber_security_services_pro_footer_widget_content_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_footer_widget_content_font_family).';';
		$custom_css .='}';
	}

	// FOOTER COPYRIGHT

	if($cyber_security_services_pro_footer_copy_content_color != false || $cyber_security_services_pro_footer_copy_content_font_family != false){
		$custom_css .='#footer .copyright p , #footer .copyright p a {';
			if($cyber_security_services_pro_footer_copy_content_color != false)
				$custom_css .='color: '.esc_html($cyber_security_services_pro_footer_copy_content_color).';';
			if($cyber_security_services_pro_footer_copy_content_font_family != false)
				$custom_css .='font-family:'.esc_html($cyber_security_services_pro_footer_copy_content_font_family).';';
		$custom_css .='}';
	}

	if($cyber_security_services_pro_footer_social_icon_color != false) {
 		$custom_css .='.ftr-social-icons a i{';
 			if($cyber_security_services_pro_footer_social_icon_color != false)
		    	$custom_css .='color: '.esc_html($cyber_security_services_pro_footer_social_icon_color).';';
		$custom_css .='}';
	}	

	if($cyber_security_services_pro_footer_social_icon_bgcolor != false){
		$custom_css .='.ftr-social-icons a {';
			if($cyber_security_services_pro_footer_social_icon_bgcolor != false)
				$custom_css .='background: '.esc_html($cyber_security_services_pro_footer_social_icon_bgcolor).';';
		$custom_css .='}';
	}

	// THEME LAYOUT OPTION.

	$layout_option = get_theme_mod( 'cyber_security_services_pro_layout_option','full-width');
    if($layout_option == 'conatiner-width'){
		$custom_css .='body{';
			$custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$custom_css .='}';
		$custom_css .='#slider .slider-box{';
			$custom_css .='left:10%; right:50%;';
		$custom_css .='}';
		$custom_css .='#brands button.owl-prev, #counter button.owl-prev{';
			$custom_css .='left:0;';
		$custom_css .='}';
		$custom_css .='#brands button.owl-next, #counter button.owl-next{';
			$custom_css .='right:0;';
		$custom_css .='}';
		$custom_css .='.sticky{';
			$custom_css .='width:auto;';
		$custom_css .='}';
	}else if($layout_option == 'conatiner-fluid-width'){
		$custom_css .='body{';
			$custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$custom_css .='}';
		$custom_css .='.sticky{';
			$custom_css .='right:0; left:0;';
		$custom_css .='}';
	}else if($layout_option == 'full-width'){
		$custom_css .='body{';
			$custom_css .='max-width: 100%;';
		$custom_css .='}';
	}
