<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package cyber-security-services-pro
 */

$page_title_style="";
if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Center'){
    $page_title_style='text-align:center;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Left')
{
	$page_title_style='text-align:left;';
}else if(get_theme_mod('cyber_security_services_pro_page_title_content_option')=='Right')
{
	$page_title_style='text-align:right;';
}else{
	$page_title_style='';
}

get_header(); ?>

<div class="container">
	<div class="middle-align mt-5">
		<h1 style="<?php echo esc_attr($page_title_style); ?>" class="entry-title"><?php printf( __( 'Results For: %s', 'cyber-security-services-pro' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
		<div class="row m-0">
			<div class="col-lg-8 col-md-9">
				<div class="row">
					<?php if ( have_posts() ) : ?>
						<?php while ( have_posts() ) : the_post();
							get_template_part( 'template-parts/post/post-content' );
						endwhile; ?>
						<div class="navigation">
							<?php // Previous/next page navigation.
							  the_posts_pagination( array(
								  'prev_text'          => __( 'Previous page', 'cyber-security-services-pro' ),
								  'next_text'          => __( 'Next page', 'cyber-security-services-pro' ),
								  'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'cyber-security-services-pro' ) . ' </span>',
							  )); ?>
						</div>
					<?php else : ?>
						<?php get_template_part( 'no-results', 'search' ); ?>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-3">
				<?php get_sidebar('page'); ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<?php get_footer(); ?>